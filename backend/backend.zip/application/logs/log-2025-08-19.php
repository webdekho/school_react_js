<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-08-19 06:25:35 --> Config Class Initialized
INFO - 2025-08-19 06:25:35 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:25:35 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:25:35 --> Utf8 Class Initialized
INFO - 2025-08-19 06:25:35 --> URI Class Initialized
INFO - 2025-08-19 06:25:35 --> Router Class Initialized
INFO - 2025-08-19 06:25:35 --> Output Class Initialized
INFO - 2025-08-19 06:25:35 --> Security Class Initialized
DEBUG - 2025-08-19 06:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:25:35 --> Input Class Initialized
INFO - 2025-08-19 06:25:35 --> Language Class Initialized
ERROR - 2025-08-19 06:25:35 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:25:55 --> Config Class Initialized
INFO - 2025-08-19 06:25:55 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:25:55 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:25:55 --> Utf8 Class Initialized
INFO - 2025-08-19 06:25:55 --> URI Class Initialized
INFO - 2025-08-19 06:25:55 --> Router Class Initialized
INFO - 2025-08-19 06:25:55 --> Output Class Initialized
INFO - 2025-08-19 06:25:55 --> Security Class Initialized
DEBUG - 2025-08-19 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:25:55 --> Input Class Initialized
INFO - 2025-08-19 06:25:55 --> Language Class Initialized
ERROR - 2025-08-19 06:25:55 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:26:11 --> Config Class Initialized
INFO - 2025-08-19 06:26:11 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:26:11 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:26:11 --> Utf8 Class Initialized
INFO - 2025-08-19 06:26:11 --> URI Class Initialized
INFO - 2025-08-19 06:26:11 --> Router Class Initialized
INFO - 2025-08-19 06:26:11 --> Output Class Initialized
INFO - 2025-08-19 06:26:11 --> Security Class Initialized
DEBUG - 2025-08-19 06:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:26:11 --> Input Class Initialized
INFO - 2025-08-19 06:26:11 --> Language Class Initialized
ERROR - 2025-08-19 06:26:11 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:26:27 --> Config Class Initialized
INFO - 2025-08-19 06:26:27 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:26:27 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:26:27 --> Utf8 Class Initialized
INFO - 2025-08-19 06:26:27 --> URI Class Initialized
DEBUG - 2025-08-19 06:26:27 --> No URI present. Default controller set.
INFO - 2025-08-19 06:26:27 --> Router Class Initialized
INFO - 2025-08-19 06:26:27 --> Output Class Initialized
INFO - 2025-08-19 06:26:27 --> Security Class Initialized
DEBUG - 2025-08-19 06:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:26:27 --> Input Class Initialized
INFO - 2025-08-19 06:26:27 --> Language Class Initialized
INFO - 2025-08-19 06:26:27 --> Loader Class Initialized
INFO - 2025-08-19 06:26:27 --> Helper loaded: url_helper
INFO - 2025-08-19 06:26:27 --> Helper loaded: security_helper
INFO - 2025-08-19 06:26:27 --> Helper loaded: string_helper
ERROR - 2025-08-19 06:26:27 --> Severity: 8192 --> Creation of dynamic property Welcome::$db is deprecated C:\xampp\htdocs\School\backend\system\core\Loader.php 488
INFO - 2025-08-19 06:26:27 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:26:27 --> Session: Class initialized using 'files' driver.
ERROR - 2025-08-19 06:26:27 --> Severity: 8192 --> Creation of dynamic property Welcome::$session is deprecated C:\xampp\htdocs\School\backend\system\core\Loader.php 1375
INFO - 2025-08-19 06:26:27 --> Helper loaded: form_helper
INFO - 2025-08-19 06:26:27 --> Form Validation Class Initialized
ERROR - 2025-08-19 06:26:27 --> Severity: 8192 --> Creation of dynamic property Welcome::$form_validation is deprecated C:\xampp\htdocs\School\backend\system\core\Loader.php 1375
INFO - 2025-08-19 06:26:27 --> Controller Class Initialized
INFO - 2025-08-19 06:26:27 --> Final output sent to browser
DEBUG - 2025-08-19 06:26:27 --> Total execution time: 0.0952
INFO - 2025-08-19 06:26:44 --> Config Class Initialized
INFO - 2025-08-19 06:26:44 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:26:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:26:44 --> Utf8 Class Initialized
INFO - 2025-08-19 06:26:44 --> URI Class Initialized
INFO - 2025-08-19 06:26:44 --> Router Class Initialized
INFO - 2025-08-19 06:26:44 --> Output Class Initialized
INFO - 2025-08-19 06:26:44 --> Security Class Initialized
DEBUG - 2025-08-19 06:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:26:44 --> Input Class Initialized
INFO - 2025-08-19 06:26:44 --> Language Class Initialized
ERROR - 2025-08-19 06:26:44 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:27:04 --> Config Class Initialized
INFO - 2025-08-19 06:27:04 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:27:04 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:27:04 --> Utf8 Class Initialized
INFO - 2025-08-19 06:27:04 --> URI Class Initialized
DEBUG - 2025-08-19 06:27:04 --> No URI present. Default controller set.
INFO - 2025-08-19 06:27:04 --> Router Class Initialized
INFO - 2025-08-19 06:27:04 --> Output Class Initialized
INFO - 2025-08-19 06:27:04 --> Security Class Initialized
DEBUG - 2025-08-19 06:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:27:04 --> Input Class Initialized
INFO - 2025-08-19 06:27:04 --> Language Class Initialized
INFO - 2025-08-19 06:27:04 --> Loader Class Initialized
INFO - 2025-08-19 06:27:04 --> Helper loaded: url_helper
INFO - 2025-08-19 06:27:04 --> Helper loaded: security_helper
INFO - 2025-08-19 06:27:04 --> Helper loaded: string_helper
ERROR - 2025-08-19 06:27:04 --> Severity: 8192 --> Creation of dynamic property Welcome::$db is deprecated C:\xampp\htdocs\School\backend\system\core\Loader.php 488
INFO - 2025-08-19 06:27:04 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:27:04 --> Session: Class initialized using 'files' driver.
ERROR - 2025-08-19 06:27:04 --> Severity: 8192 --> Creation of dynamic property Welcome::$session is deprecated C:\xampp\htdocs\School\backend\system\core\Loader.php 1375
INFO - 2025-08-19 06:27:04 --> Helper loaded: form_helper
INFO - 2025-08-19 06:27:04 --> Form Validation Class Initialized
ERROR - 2025-08-19 06:27:04 --> Severity: 8192 --> Creation of dynamic property Welcome::$form_validation is deprecated C:\xampp\htdocs\School\backend\system\core\Loader.php 1375
INFO - 2025-08-19 06:27:04 --> Controller Class Initialized
INFO - 2025-08-19 06:27:04 --> Final output sent to browser
DEBUG - 2025-08-19 06:27:04 --> Total execution time: 0.0766
INFO - 2025-08-19 06:28:14 --> Config Class Initialized
INFO - 2025-08-19 06:28:14 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:28:14 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:28:14 --> Utf8 Class Initialized
INFO - 2025-08-19 06:28:14 --> URI Class Initialized
DEBUG - 2025-08-19 06:28:14 --> No URI present. Default controller set.
INFO - 2025-08-19 06:28:14 --> Router Class Initialized
INFO - 2025-08-19 06:28:14 --> Output Class Initialized
INFO - 2025-08-19 06:28:14 --> Security Class Initialized
DEBUG - 2025-08-19 06:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:28:14 --> Input Class Initialized
INFO - 2025-08-19 06:28:14 --> Language Class Initialized
INFO - 2025-08-19 06:28:14 --> Loader Class Initialized
INFO - 2025-08-19 06:28:14 --> Helper loaded: url_helper
INFO - 2025-08-19 06:28:14 --> Helper loaded: security_helper
INFO - 2025-08-19 06:28:14 --> Helper loaded: string_helper
ERROR - 2025-08-19 06:28:14 --> Severity: error --> Exception: Cannot access protected property Welcome::$db C:\xampp\htdocs\School\backend\system\core\Loader.php 488
INFO - 2025-08-19 06:28:44 --> Config Class Initialized
INFO - 2025-08-19 06:28:44 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:28:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:28:44 --> Utf8 Class Initialized
INFO - 2025-08-19 06:28:44 --> URI Class Initialized
DEBUG - 2025-08-19 06:28:44 --> No URI present. Default controller set.
INFO - 2025-08-19 06:28:44 --> Router Class Initialized
INFO - 2025-08-19 06:28:44 --> Output Class Initialized
INFO - 2025-08-19 06:28:44 --> Security Class Initialized
DEBUG - 2025-08-19 06:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:28:44 --> Input Class Initialized
INFO - 2025-08-19 06:28:44 --> Language Class Initialized
INFO - 2025-08-19 06:28:44 --> Loader Class Initialized
INFO - 2025-08-19 06:28:44 --> Helper loaded: url_helper
INFO - 2025-08-19 06:28:44 --> Helper loaded: security_helper
INFO - 2025-08-19 06:28:44 --> Helper loaded: string_helper
INFO - 2025-08-19 06:28:44 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:28:44 --> Helper loaded: form_helper
INFO - 2025-08-19 06:28:44 --> Form Validation Class Initialized
INFO - 2025-08-19 06:28:44 --> Controller Class Initialized
INFO - 2025-08-19 06:28:44 --> Final output sent to browser
DEBUG - 2025-08-19 06:28:44 --> Total execution time: 0.0497
INFO - 2025-08-19 06:28:50 --> Config Class Initialized
INFO - 2025-08-19 06:28:50 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:28:50 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:28:50 --> Utf8 Class Initialized
INFO - 2025-08-19 06:28:50 --> URI Class Initialized
INFO - 2025-08-19 06:28:50 --> Router Class Initialized
INFO - 2025-08-19 06:28:50 --> Output Class Initialized
INFO - 2025-08-19 06:28:50 --> Security Class Initialized
DEBUG - 2025-08-19 06:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:28:50 --> Input Class Initialized
INFO - 2025-08-19 06:28:50 --> Language Class Initialized
ERROR - 2025-08-19 06:28:50 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:29:00 --> Config Class Initialized
INFO - 2025-08-19 06:29:00 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:29:00 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:29:00 --> Utf8 Class Initialized
INFO - 2025-08-19 06:29:00 --> URI Class Initialized
INFO - 2025-08-19 06:29:00 --> Router Class Initialized
INFO - 2025-08-19 06:29:00 --> Output Class Initialized
INFO - 2025-08-19 06:29:00 --> Security Class Initialized
DEBUG - 2025-08-19 06:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:29:00 --> Input Class Initialized
INFO - 2025-08-19 06:29:00 --> Language Class Initialized
ERROR - 2025-08-19 06:29:00 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:30:20 --> Config Class Initialized
INFO - 2025-08-19 06:30:20 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:30:20 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:30:20 --> Utf8 Class Initialized
INFO - 2025-08-19 06:30:20 --> URI Class Initialized
INFO - 2025-08-19 06:30:20 --> Router Class Initialized
INFO - 2025-08-19 06:30:20 --> Output Class Initialized
INFO - 2025-08-19 06:30:20 --> Security Class Initialized
DEBUG - 2025-08-19 06:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:30:20 --> Input Class Initialized
INFO - 2025-08-19 06:30:20 --> Language Class Initialized
ERROR - 2025-08-19 06:30:20 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:30:24 --> Config Class Initialized
INFO - 2025-08-19 06:30:24 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:30:24 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:30:24 --> Utf8 Class Initialized
INFO - 2025-08-19 06:30:24 --> URI Class Initialized
INFO - 2025-08-19 06:30:24 --> Router Class Initialized
INFO - 2025-08-19 06:30:24 --> Output Class Initialized
INFO - 2025-08-19 06:30:24 --> Security Class Initialized
DEBUG - 2025-08-19 06:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:30:24 --> Input Class Initialized
INFO - 2025-08-19 06:30:24 --> Language Class Initialized
ERROR - 2025-08-19 06:30:24 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:30:27 --> Config Class Initialized
INFO - 2025-08-19 06:30:27 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:30:27 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:30:27 --> Utf8 Class Initialized
INFO - 2025-08-19 06:30:27 --> URI Class Initialized
INFO - 2025-08-19 06:30:27 --> Router Class Initialized
INFO - 2025-08-19 06:30:27 --> Output Class Initialized
INFO - 2025-08-19 06:30:27 --> Security Class Initialized
DEBUG - 2025-08-19 06:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:30:27 --> Input Class Initialized
INFO - 2025-08-19 06:30:27 --> Language Class Initialized
ERROR - 2025-08-19 06:30:27 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:30:43 --> Config Class Initialized
INFO - 2025-08-19 06:30:43 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:30:43 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:30:43 --> Utf8 Class Initialized
INFO - 2025-08-19 06:30:43 --> URI Class Initialized
INFO - 2025-08-19 06:30:43 --> Router Class Initialized
INFO - 2025-08-19 06:30:43 --> Output Class Initialized
INFO - 2025-08-19 06:30:43 --> Security Class Initialized
DEBUG - 2025-08-19 06:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:30:43 --> Input Class Initialized
INFO - 2025-08-19 06:30:43 --> Language Class Initialized
ERROR - 2025-08-19 06:30:43 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:30:48 --> Config Class Initialized
INFO - 2025-08-19 06:30:48 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:30:48 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:30:48 --> Utf8 Class Initialized
INFO - 2025-08-19 06:30:48 --> URI Class Initialized
INFO - 2025-08-19 06:30:48 --> Router Class Initialized
INFO - 2025-08-19 06:30:48 --> Output Class Initialized
INFO - 2025-08-19 06:30:48 --> Security Class Initialized
DEBUG - 2025-08-19 06:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:30:48 --> Input Class Initialized
INFO - 2025-08-19 06:30:48 --> Language Class Initialized
ERROR - 2025-08-19 06:30:48 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:31:20 --> Config Class Initialized
INFO - 2025-08-19 06:31:20 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:31:20 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:31:20 --> Utf8 Class Initialized
INFO - 2025-08-19 06:31:20 --> URI Class Initialized
DEBUG - 2025-08-19 06:31:20 --> No URI present. Default controller set.
INFO - 2025-08-19 06:31:20 --> Router Class Initialized
INFO - 2025-08-19 06:31:20 --> Output Class Initialized
INFO - 2025-08-19 06:31:20 --> Security Class Initialized
DEBUG - 2025-08-19 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:31:20 --> Input Class Initialized
INFO - 2025-08-19 06:31:20 --> Language Class Initialized
INFO - 2025-08-19 06:31:20 --> Loader Class Initialized
INFO - 2025-08-19 06:31:20 --> Helper loaded: url_helper
INFO - 2025-08-19 06:31:20 --> Helper loaded: security_helper
INFO - 2025-08-19 06:31:20 --> Helper loaded: string_helper
INFO - 2025-08-19 06:31:20 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:31:20 --> Helper loaded: form_helper
INFO - 2025-08-19 06:31:20 --> Form Validation Class Initialized
INFO - 2025-08-19 06:31:20 --> Controller Class Initialized
INFO - 2025-08-19 06:31:20 --> Final output sent to browser
DEBUG - 2025-08-19 06:31:20 --> Total execution time: 0.0523
INFO - 2025-08-19 06:31:27 --> Config Class Initialized
INFO - 2025-08-19 06:31:27 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:31:27 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:31:27 --> Utf8 Class Initialized
INFO - 2025-08-19 06:31:27 --> URI Class Initialized
INFO - 2025-08-19 06:31:27 --> Router Class Initialized
INFO - 2025-08-19 06:31:27 --> Output Class Initialized
INFO - 2025-08-19 06:31:27 --> Security Class Initialized
DEBUG - 2025-08-19 06:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:31:27 --> Input Class Initialized
INFO - 2025-08-19 06:31:27 --> Language Class Initialized
INFO - 2025-08-19 06:31:27 --> Loader Class Initialized
INFO - 2025-08-19 06:31:27 --> Helper loaded: url_helper
INFO - 2025-08-19 06:31:27 --> Helper loaded: security_helper
INFO - 2025-08-19 06:31:27 --> Helper loaded: string_helper
INFO - 2025-08-19 06:31:27 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:31:27 --> Helper loaded: form_helper
INFO - 2025-08-19 06:31:27 --> Form Validation Class Initialized
INFO - 2025-08-19 06:31:27 --> Controller Class Initialized
INFO - 2025-08-19 06:31:27 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:31:27 --> Final output sent to browser
DEBUG - 2025-08-19 06:31:27 --> Total execution time: 0.0514
INFO - 2025-08-19 06:31:43 --> Config Class Initialized
INFO - 2025-08-19 06:31:43 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:31:43 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:31:43 --> Utf8 Class Initialized
INFO - 2025-08-19 06:31:43 --> URI Class Initialized
INFO - 2025-08-19 06:31:43 --> Router Class Initialized
INFO - 2025-08-19 06:31:43 --> Output Class Initialized
INFO - 2025-08-19 06:31:43 --> Security Class Initialized
DEBUG - 2025-08-19 06:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:31:43 --> Input Class Initialized
INFO - 2025-08-19 06:31:43 --> Language Class Initialized
ERROR - 2025-08-19 06:31:43 --> 404 Page Not Found: School/backend
INFO - 2025-08-19 06:38:23 --> Config Class Initialized
INFO - 2025-08-19 06:38:23 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:38:23 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:38:23 --> Utf8 Class Initialized
INFO - 2025-08-19 06:38:23 --> URI Class Initialized
INFO - 2025-08-19 06:38:23 --> Router Class Initialized
INFO - 2025-08-19 06:38:23 --> Output Class Initialized
INFO - 2025-08-19 06:38:23 --> Security Class Initialized
DEBUG - 2025-08-19 06:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:38:23 --> Input Class Initialized
INFO - 2025-08-19 06:38:23 --> Language Class Initialized
INFO - 2025-08-19 06:38:23 --> Loader Class Initialized
INFO - 2025-08-19 06:38:23 --> Helper loaded: url_helper
INFO - 2025-08-19 06:38:23 --> Helper loaded: security_helper
INFO - 2025-08-19 06:38:23 --> Helper loaded: string_helper
INFO - 2025-08-19 06:38:23 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:38:23 --> Helper loaded: form_helper
INFO - 2025-08-19 06:38:23 --> Form Validation Class Initialized
INFO - 2025-08-19 06:38:23 --> Controller Class Initialized
INFO - 2025-08-19 06:38:23 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:38:23 --> Final output sent to browser
DEBUG - 2025-08-19 06:38:23 --> Total execution time: 0.1523
INFO - 2025-08-19 06:38:23 --> Config Class Initialized
INFO - 2025-08-19 06:38:23 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:38:23 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:38:23 --> Utf8 Class Initialized
INFO - 2025-08-19 06:38:23 --> URI Class Initialized
INFO - 2025-08-19 06:38:23 --> Router Class Initialized
INFO - 2025-08-19 06:38:23 --> Output Class Initialized
INFO - 2025-08-19 06:38:23 --> Security Class Initialized
DEBUG - 2025-08-19 06:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:38:23 --> Input Class Initialized
INFO - 2025-08-19 06:38:23 --> Language Class Initialized
INFO - 2025-08-19 06:38:23 --> Loader Class Initialized
INFO - 2025-08-19 06:38:23 --> Helper loaded: url_helper
INFO - 2025-08-19 06:38:23 --> Helper loaded: security_helper
INFO - 2025-08-19 06:38:23 --> Helper loaded: string_helper
INFO - 2025-08-19 06:38:24 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:38:24 --> Helper loaded: form_helper
INFO - 2025-08-19 06:38:24 --> Form Validation Class Initialized
INFO - 2025-08-19 06:38:24 --> Controller Class Initialized
INFO - 2025-08-19 06:38:24 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:38:24 --> Final output sent to browser
DEBUG - 2025-08-19 06:38:24 --> Total execution time: 0.0674
INFO - 2025-08-19 06:38:24 --> Config Class Initialized
INFO - 2025-08-19 06:38:24 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:38:24 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:38:24 --> Utf8 Class Initialized
INFO - 2025-08-19 06:38:24 --> URI Class Initialized
INFO - 2025-08-19 06:38:24 --> Router Class Initialized
INFO - 2025-08-19 06:38:24 --> Output Class Initialized
INFO - 2025-08-19 06:38:24 --> Security Class Initialized
DEBUG - 2025-08-19 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:38:24 --> Input Class Initialized
INFO - 2025-08-19 06:38:24 --> Language Class Initialized
INFO - 2025-08-19 06:38:24 --> Loader Class Initialized
INFO - 2025-08-19 06:38:24 --> Helper loaded: url_helper
INFO - 2025-08-19 06:38:24 --> Helper loaded: security_helper
INFO - 2025-08-19 06:38:24 --> Helper loaded: string_helper
INFO - 2025-08-19 06:38:24 --> Config Class Initialized
INFO - 2025-08-19 06:38:24 --> Hooks Class Initialized
INFO - 2025-08-19 06:38:24 --> Config Class Initialized
INFO - 2025-08-19 06:38:24 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:38:24 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:38:24 --> Utf8 Class Initialized
INFO - 2025-08-19 06:38:24 --> URI Class Initialized
INFO - 2025-08-19 06:38:24 --> Router Class Initialized
DEBUG - 2025-08-19 06:38:24 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:38:24 --> Utf8 Class Initialized
INFO - 2025-08-19 06:38:24 --> Output Class Initialized
INFO - 2025-08-19 06:38:24 --> URI Class Initialized
INFO - 2025-08-19 06:38:24 --> Database Driver Class Initialized
INFO - 2025-08-19 06:38:24 --> Security Class Initialized
INFO - 2025-08-19 06:38:24 --> Router Class Initialized
DEBUG - 2025-08-19 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:38:24 --> Input Class Initialized
INFO - 2025-08-19 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:38:24 --> Output Class Initialized
INFO - 2025-08-19 06:38:24 --> Language Class Initialized
INFO - 2025-08-19 06:38:24 --> Security Class Initialized
DEBUG - 2025-08-19 06:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:38:24 --> Input Class Initialized
INFO - 2025-08-19 06:38:24 --> Language Class Initialized
INFO - 2025-08-19 06:38:24 --> Helper loaded: form_helper
INFO - 2025-08-19 06:38:24 --> Form Validation Class Initialized
INFO - 2025-08-19 06:38:24 --> Controller Class Initialized
INFO - 2025-08-19 06:38:24 --> Loader Class Initialized
INFO - 2025-08-19 06:38:24 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:38:24 --> Helper loaded: url_helper
INFO - 2025-08-19 06:38:24 --> Helper loaded: security_helper
INFO - 2025-08-19 06:38:24 --> Helper loaded: string_helper
INFO - 2025-08-19 06:38:24 --> Loader Class Initialized
INFO - 2025-08-19 06:38:24 --> Database Driver Class Initialized
INFO - 2025-08-19 06:38:24 --> Helper loaded: url_helper
INFO - 2025-08-19 06:38:24 --> Helper loaded: security_helper
DEBUG - 2025-08-19 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:38:24 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Division_model" initialized
INFO - 2025-08-19 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:38:24 --> Helper loaded: string_helper
INFO - 2025-08-19 06:38:24 --> Model "Student_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:38:24 --> Helper loaded: form_helper
INFO - 2025-08-19 06:38:24 --> Form Validation Class Initialized
INFO - 2025-08-19 06:38:24 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:38:24 --> Controller Class Initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:38:24 --> Database Driver Class Initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Division_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Student_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_collection_model" initialized
DEBUG - 2025-08-19 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:38:24 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:38:24 --> Helper loaded: form_helper
INFO - 2025-08-19 06:38:24 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:38:24 --> Form Validation Class Initialized
INFO - 2025-08-19 06:38:24 --> Controller Class Initialized
INFO - 2025-08-19 06:38:24 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Report_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Role_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Report_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Role_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:38:24 --> Final output sent to browser
DEBUG - 2025-08-19 06:38:24 --> Total execution time: 0.1732
INFO - 2025-08-19 06:38:24 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Division_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Student_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:38:24 --> Final output sent to browser
DEBUG - 2025-08-19 06:38:24 --> Total execution time: 0.2402
INFO - 2025-08-19 06:38:24 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Report_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Role_model" initialized
INFO - 2025-08-19 06:38:24 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Pending fees count = 126
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Pending fees amount = 279750
DEBUG - 2025-08-19 06:38:24 --> Dashboard: audit_logs table exists, fetching activities
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Raw activities count: 10
DEBUG - 2025-08-19 06:38:24 --> Dashboard: First activity: {"action":"login","user_type":"admin","user_id":"1","table_name":"staff","record_id":"1","created_at":"2025-08-19 06:38:23"}
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Processing activity - user_type: admin, user_id: 1
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Admin user found: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Final user_name: System Administrator
DEBUG - 2025-08-19 06:38:24 --> Dashboard: Found 10 recent activities from audit_logs
INFO - 2025-08-19 06:38:24 --> Final output sent to browser
DEBUG - 2025-08-19 06:38:24 --> Total execution time: 0.2612
INFO - 2025-08-19 06:38:26 --> Config Class Initialized
INFO - 2025-08-19 06:38:26 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:38:26 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:38:26 --> Utf8 Class Initialized
INFO - 2025-08-19 06:38:26 --> URI Class Initialized
INFO - 2025-08-19 06:38:26 --> Router Class Initialized
INFO - 2025-08-19 06:38:26 --> Output Class Initialized
INFO - 2025-08-19 06:38:26 --> Security Class Initialized
DEBUG - 2025-08-19 06:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:38:26 --> Input Class Initialized
INFO - 2025-08-19 06:38:26 --> Language Class Initialized
INFO - 2025-08-19 06:38:26 --> Loader Class Initialized
INFO - 2025-08-19 06:38:26 --> Helper loaded: url_helper
INFO - 2025-08-19 06:38:26 --> Helper loaded: security_helper
INFO - 2025-08-19 06:38:26 --> Helper loaded: string_helper
INFO - 2025-08-19 06:38:26 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:38:26 --> Helper loaded: form_helper
INFO - 2025-08-19 06:38:26 --> Form Validation Class Initialized
INFO - 2025-08-19 06:38:26 --> Controller Class Initialized
INFO - 2025-08-19 06:38:26 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Division_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Student_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Report_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Role_model" initialized
INFO - 2025-08-19 06:38:26 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:38:26 --> Final output sent to browser
DEBUG - 2025-08-19 06:38:26 --> Total execution time: 0.0873
INFO - 2025-08-19 06:38:27 --> Config Class Initialized
INFO - 2025-08-19 06:38:27 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:38:27 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:38:27 --> Utf8 Class Initialized
INFO - 2025-08-19 06:38:27 --> URI Class Initialized
INFO - 2025-08-19 06:38:27 --> Router Class Initialized
INFO - 2025-08-19 06:38:27 --> Output Class Initialized
INFO - 2025-08-19 06:38:27 --> Security Class Initialized
DEBUG - 2025-08-19 06:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:38:27 --> Input Class Initialized
INFO - 2025-08-19 06:38:27 --> Language Class Initialized
INFO - 2025-08-19 06:38:27 --> Loader Class Initialized
INFO - 2025-08-19 06:38:27 --> Helper loaded: url_helper
INFO - 2025-08-19 06:38:27 --> Helper loaded: security_helper
INFO - 2025-08-19 06:38:27 --> Helper loaded: string_helper
INFO - 2025-08-19 06:38:27 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:38:27 --> Helper loaded: form_helper
INFO - 2025-08-19 06:38:27 --> Form Validation Class Initialized
INFO - 2025-08-19 06:38:27 --> Controller Class Initialized
INFO - 2025-08-19 06:38:27 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Division_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Student_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Report_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Role_model" initialized
INFO - 2025-08-19 06:38:27 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:38:27 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:38:27 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:38:27 --> Grades API - Total count: 13
INFO - 2025-08-19 06:38:27 --> Final output sent to browser
DEBUG - 2025-08-19 06:38:27 --> Total execution time: 0.1056
INFO - 2025-08-19 06:40:15 --> Config Class Initialized
INFO - 2025-08-19 06:40:15 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:15 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:15 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:15 --> URI Class Initialized
INFO - 2025-08-19 06:40:15 --> Router Class Initialized
INFO - 2025-08-19 06:40:15 --> Output Class Initialized
INFO - 2025-08-19 06:40:15 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:15 --> Input Class Initialized
INFO - 2025-08-19 06:40:15 --> Language Class Initialized
INFO - 2025-08-19 06:40:15 --> Loader Class Initialized
INFO - 2025-08-19 06:40:15 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:15 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:15 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:15 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:15 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:15 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:15 --> Controller Class Initialized
INFO - 2025-08-19 06:40:15 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:15 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:40:15 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:15 --> Total execution time: 0.0827
INFO - 2025-08-19 06:40:16 --> Config Class Initialized
INFO - 2025-08-19 06:40:16 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:16 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:16 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:16 --> URI Class Initialized
INFO - 2025-08-19 06:40:16 --> Router Class Initialized
INFO - 2025-08-19 06:40:16 --> Output Class Initialized
INFO - 2025-08-19 06:40:16 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:16 --> Input Class Initialized
INFO - 2025-08-19 06:40:16 --> Language Class Initialized
INFO - 2025-08-19 06:40:16 --> Loader Class Initialized
INFO - 2025-08-19 06:40:16 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:16 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:16 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:16 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:16 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:16 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:16 --> Controller Class Initialized
INFO - 2025-08-19 06:40:16 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:16 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:40:16 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:40:16 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:40:16 --> Grades API - Total count: 13
INFO - 2025-08-19 06:40:16 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:16 --> Total execution time: 0.0962
INFO - 2025-08-19 06:40:17 --> Config Class Initialized
INFO - 2025-08-19 06:40:17 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:17 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:17 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:17 --> URI Class Initialized
INFO - 2025-08-19 06:40:17 --> Config Class Initialized
INFO - 2025-08-19 06:40:17 --> Hooks Class Initialized
INFO - 2025-08-19 06:40:17 --> Router Class Initialized
INFO - 2025-08-19 06:40:17 --> Output Class Initialized
DEBUG - 2025-08-19 06:40:17 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:17 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:17 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:17 --> Input Class Initialized
INFO - 2025-08-19 06:40:17 --> URI Class Initialized
INFO - 2025-08-19 06:40:17 --> Language Class Initialized
INFO - 2025-08-19 06:40:17 --> Router Class Initialized
INFO - 2025-08-19 06:40:17 --> Output Class Initialized
INFO - 2025-08-19 06:40:17 --> Security Class Initialized
INFO - 2025-08-19 06:40:17 --> Loader Class Initialized
DEBUG - 2025-08-19 06:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:17 --> Input Class Initialized
INFO - 2025-08-19 06:40:17 --> Language Class Initialized
INFO - 2025-08-19 06:40:17 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:17 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:17 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:17 --> Loader Class Initialized
INFO - 2025-08-19 06:40:17 --> Database Driver Class Initialized
INFO - 2025-08-19 06:40:17 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:17 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:17 --> Helper loaded: string_helper
DEBUG - 2025-08-19 06:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:17 --> Database Driver Class Initialized
INFO - 2025-08-19 06:40:17 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:17 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:17 --> Controller Class Initialized
INFO - 2025-08-19 06:40:17 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 06:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:17 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:17 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:17 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:17 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:17 --> Controller Class Initialized
INFO - 2025-08-19 06:40:17 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:17 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:17 --> Total execution time: 0.0886
INFO - 2025-08-19 06:40:17 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:17 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:40:17 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:17 --> Total execution time: 0.0944
INFO - 2025-08-19 06:40:17 --> Config Class Initialized
INFO - 2025-08-19 06:40:17 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:17 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:17 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:17 --> URI Class Initialized
INFO - 2025-08-19 06:40:17 --> Router Class Initialized
INFO - 2025-08-19 06:40:17 --> Output Class Initialized
INFO - 2025-08-19 06:40:17 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:17 --> Input Class Initialized
INFO - 2025-08-19 06:40:17 --> Language Class Initialized
INFO - 2025-08-19 06:40:17 --> Loader Class Initialized
INFO - 2025-08-19 06:40:17 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:17 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:17 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:17 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:18 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:18 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:18 --> Controller Class Initialized
INFO - 2025-08-19 06:40:18 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:40:18 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:40:18 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:40:18 --> Grades API - Total count: 13
INFO - 2025-08-19 06:40:18 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:18 --> Total execution time: 0.0963
INFO - 2025-08-19 06:40:18 --> Config Class Initialized
INFO - 2025-08-19 06:40:18 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:18 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:18 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:18 --> URI Class Initialized
INFO - 2025-08-19 06:40:18 --> Router Class Initialized
INFO - 2025-08-19 06:40:18 --> Output Class Initialized
INFO - 2025-08-19 06:40:18 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:18 --> Input Class Initialized
INFO - 2025-08-19 06:40:18 --> Language Class Initialized
INFO - 2025-08-19 06:40:18 --> Loader Class Initialized
INFO - 2025-08-19 06:40:18 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:18 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:18 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:18 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:18 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:18 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:18 --> Controller Class Initialized
INFO - 2025-08-19 06:40:18 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:18 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:40:18 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:18 --> Total execution time: 0.0843
INFO - 2025-08-19 06:40:20 --> Config Class Initialized
INFO - 2025-08-19 06:40:20 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:20 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:20 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:20 --> URI Class Initialized
INFO - 2025-08-19 06:40:20 --> Router Class Initialized
INFO - 2025-08-19 06:40:20 --> Output Class Initialized
INFO - 2025-08-19 06:40:20 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:20 --> Input Class Initialized
INFO - 2025-08-19 06:40:20 --> Language Class Initialized
INFO - 2025-08-19 06:40:20 --> Loader Class Initialized
INFO - 2025-08-19 06:40:20 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:20 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:20 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:20 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:20 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:20 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:20 --> Controller Class Initialized
INFO - 2025-08-19 06:40:20 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:20 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:40:20 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:20 --> Total execution time: 0.0974
INFO - 2025-08-19 06:40:45 --> Config Class Initialized
INFO - 2025-08-19 06:40:45 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:45 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:45 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:45 --> URI Class Initialized
INFO - 2025-08-19 06:40:45 --> Router Class Initialized
INFO - 2025-08-19 06:40:45 --> Output Class Initialized
INFO - 2025-08-19 06:40:45 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:45 --> Input Class Initialized
INFO - 2025-08-19 06:40:45 --> Language Class Initialized
INFO - 2025-08-19 06:40:45 --> Loader Class Initialized
INFO - 2025-08-19 06:40:45 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:45 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:45 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:45 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:45 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:45 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:45 --> Controller Class Initialized
INFO - 2025-08-19 06:40:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:40:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 06:40:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 06:40:45 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:45 --> Total execution time: 0.1106
INFO - 2025-08-19 06:40:45 --> Config Class Initialized
INFO - 2025-08-19 06:40:45 --> Hooks Class Initialized
INFO - 2025-08-19 06:40:45 --> Config Class Initialized
INFO - 2025-08-19 06:40:45 --> Hooks Class Initialized
INFO - 2025-08-19 06:40:45 --> Config Class Initialized
INFO - 2025-08-19 06:40:45 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:45 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:45 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:45 --> URI Class Initialized
DEBUG - 2025-08-19 06:40:45 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:45 --> Router Class Initialized
INFO - 2025-08-19 06:40:45 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:45 --> Output Class Initialized
INFO - 2025-08-19 06:40:45 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:45 --> URI Class Initialized
INFO - 2025-08-19 06:40:45 --> Input Class Initialized
INFO - 2025-08-19 06:40:45 --> Language Class Initialized
INFO - 2025-08-19 06:40:45 --> Router Class Initialized
DEBUG - 2025-08-19 06:40:45 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:45 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:45 --> Output Class Initialized
INFO - 2025-08-19 06:40:45 --> URI Class Initialized
INFO - 2025-08-19 06:40:45 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:45 --> Input Class Initialized
INFO - 2025-08-19 06:40:45 --> Router Class Initialized
INFO - 2025-08-19 06:40:45 --> Language Class Initialized
INFO - 2025-08-19 06:40:45 --> Output Class Initialized
INFO - 2025-08-19 06:40:45 --> Security Class Initialized
INFO - 2025-08-19 06:40:45 --> Loader Class Initialized
DEBUG - 2025-08-19 06:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:45 --> Input Class Initialized
INFO - 2025-08-19 06:40:45 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:45 --> Language Class Initialized
INFO - 2025-08-19 06:40:45 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:45 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:45 --> Loader Class Initialized
INFO - 2025-08-19 06:40:45 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:45 --> Database Driver Class Initialized
INFO - 2025-08-19 06:40:45 --> Loader Class Initialized
INFO - 2025-08-19 06:40:45 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:45 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:45 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:45 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:45 --> Helper loaded: string_helper
DEBUG - 2025-08-19 06:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:45 --> Database Driver Class Initialized
INFO - 2025-08-19 06:40:45 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:45 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:45 --> Controller Class Initialized
INFO - 2025-08-19 06:40:45 --> Database Driver Class Initialized
INFO - 2025-08-19 06:40:45 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 06:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:45 --> Model "Grade_model" initialized
DEBUG - 2025-08-19 06:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:45 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:45 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:45 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:45 --> Controller Class Initialized
INFO - 2025-08-19 06:40:45 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:45 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:45 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:45 --> Controller Class Initialized
INFO - 2025-08-19 06:40:45 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:45 --> Final output sent to browser
INFO - 2025-08-19 06:40:45 --> Model "Academic_year_model" initialized
DEBUG - 2025-08-19 06:40:45 --> Total execution time: 0.0941
INFO - 2025-08-19 06:40:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:40:45 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:45 --> Final output sent to browser
INFO - 2025-08-19 06:40:45 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:40:45 --> Total execution time: 0.1067
INFO - 2025-08-19 06:40:45 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:45 --> Total execution time: 0.1079
INFO - 2025-08-19 06:40:53 --> Config Class Initialized
INFO - 2025-08-19 06:40:53 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:40:53 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:40:53 --> Utf8 Class Initialized
INFO - 2025-08-19 06:40:53 --> URI Class Initialized
INFO - 2025-08-19 06:40:53 --> Router Class Initialized
INFO - 2025-08-19 06:40:53 --> Output Class Initialized
INFO - 2025-08-19 06:40:53 --> Security Class Initialized
DEBUG - 2025-08-19 06:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:40:53 --> Input Class Initialized
INFO - 2025-08-19 06:40:53 --> Language Class Initialized
INFO - 2025-08-19 06:40:53 --> Loader Class Initialized
INFO - 2025-08-19 06:40:53 --> Helper loaded: url_helper
INFO - 2025-08-19 06:40:53 --> Helper loaded: security_helper
INFO - 2025-08-19 06:40:53 --> Helper loaded: string_helper
INFO - 2025-08-19 06:40:53 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:40:53 --> Helper loaded: form_helper
INFO - 2025-08-19 06:40:53 --> Form Validation Class Initialized
INFO - 2025-08-19 06:40:53 --> Controller Class Initialized
INFO - 2025-08-19 06:40:53 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Division_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Student_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Report_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Role_model" initialized
INFO - 2025-08-19 06:40:53 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:40:53 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:40:53 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:40:53 --> Grades API - Total count: 13
INFO - 2025-08-19 06:40:53 --> Final output sent to browser
DEBUG - 2025-08-19 06:40:53 --> Total execution time: 0.1023
INFO - 2025-08-19 06:41:12 --> Config Class Initialized
INFO - 2025-08-19 06:41:12 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:41:12 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:12 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:12 --> URI Class Initialized
INFO - 2025-08-19 06:41:12 --> Router Class Initialized
INFO - 2025-08-19 06:41:12 --> Output Class Initialized
INFO - 2025-08-19 06:41:12 --> Security Class Initialized
DEBUG - 2025-08-19 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:12 --> Input Class Initialized
INFO - 2025-08-19 06:41:12 --> Language Class Initialized
INFO - 2025-08-19 06:41:12 --> Loader Class Initialized
INFO - 2025-08-19 06:41:12 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:12 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:12 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:12 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:12 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:12 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:12 --> Controller Class Initialized
INFO - 2025-08-19 06:41:12 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:41:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 06:41:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 06:41:12 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:12 --> Total execution time: 0.1039
INFO - 2025-08-19 06:41:12 --> Config Class Initialized
INFO - 2025-08-19 06:41:12 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:41:12 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:12 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:12 --> Config Class Initialized
INFO - 2025-08-19 06:41:12 --> URI Class Initialized
INFO - 2025-08-19 06:41:12 --> Hooks Class Initialized
INFO - 2025-08-19 06:41:12 --> Router Class Initialized
INFO - 2025-08-19 06:41:12 --> Config Class Initialized
INFO - 2025-08-19 06:41:12 --> Hooks Class Initialized
INFO - 2025-08-19 06:41:12 --> Output Class Initialized
INFO - 2025-08-19 06:41:12 --> Security Class Initialized
DEBUG - 2025-08-19 06:41:12 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:12 --> Utf8 Class Initialized
DEBUG - 2025-08-19 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:12 --> Input Class Initialized
INFO - 2025-08-19 06:41:12 --> Language Class Initialized
DEBUG - 2025-08-19 06:41:12 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:12 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:12 --> URI Class Initialized
INFO - 2025-08-19 06:41:12 --> URI Class Initialized
INFO - 2025-08-19 06:41:12 --> Router Class Initialized
INFO - 2025-08-19 06:41:12 --> Output Class Initialized
INFO - 2025-08-19 06:41:12 --> Security Class Initialized
INFO - 2025-08-19 06:41:12 --> Loader Class Initialized
INFO - 2025-08-19 06:41:12 --> Router Class Initialized
DEBUG - 2025-08-19 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:12 --> Input Class Initialized
INFO - 2025-08-19 06:41:12 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:12 --> Output Class Initialized
INFO - 2025-08-19 06:41:12 --> Language Class Initialized
INFO - 2025-08-19 06:41:12 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:12 --> Security Class Initialized
INFO - 2025-08-19 06:41:12 --> Helper loaded: string_helper
DEBUG - 2025-08-19 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:12 --> Input Class Initialized
INFO - 2025-08-19 06:41:12 --> Language Class Initialized
INFO - 2025-08-19 06:41:12 --> Database Driver Class Initialized
INFO - 2025-08-19 06:41:12 --> Loader Class Initialized
INFO - 2025-08-19 06:41:12 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:12 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:12 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:12 --> Loader Class Initialized
DEBUG - 2025-08-19 06:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:12 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:12 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:12 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:12 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:12 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:12 --> Controller Class Initialized
INFO - 2025-08-19 06:41:12 --> Database Driver Class Initialized
INFO - 2025-08-19 06:41:12 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:12 --> Database Driver Class Initialized
INFO - 2025-08-19 06:41:12 --> Model "Grade_model" initialized
DEBUG - 2025-08-19 06:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:12 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:12 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Staff_model" initialized
DEBUG - 2025-08-19 06:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:12 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:12 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:12 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:12 --> Controller Class Initialized
INFO - 2025-08-19 06:41:12 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:12 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:12 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:12 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:41:12 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:12 --> Controller Class Initialized
INFO - 2025-08-19 06:41:12 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:12 --> Final output sent to browser
INFO - 2025-08-19 06:41:12 --> Model "Grade_model" initialized
DEBUG - 2025-08-19 06:41:12 --> Total execution time: 0.0872
INFO - 2025-08-19 06:41:12 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Fee_collection_model" initialized
DEBUG - 2025-08-19 06:41:12 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
INFO - 2025-08-19 06:41:12 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:12 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:41:12 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:12 --> Total execution time: 0.1028
DEBUG - 2025-08-19 06:41:12 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:41:12 --> Grades API - Total count: 14
INFO - 2025-08-19 06:41:12 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:12 --> Total execution time: 0.1046
INFO - 2025-08-19 06:41:56 --> Config Class Initialized
INFO - 2025-08-19 06:41:56 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:41:56 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:56 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:56 --> URI Class Initialized
INFO - 2025-08-19 06:41:56 --> Router Class Initialized
INFO - 2025-08-19 06:41:56 --> Output Class Initialized
INFO - 2025-08-19 06:41:56 --> Security Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:56 --> Input Class Initialized
INFO - 2025-08-19 06:41:56 --> Language Class Initialized
INFO - 2025-08-19 06:41:56 --> Loader Class Initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:56 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:56 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:56 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:56 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:56 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:56 --> Controller Class Initialized
INFO - 2025-08-19 06:41:56 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:56 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:56 --> Total execution time: 0.0605
INFO - 2025-08-19 06:41:56 --> Config Class Initialized
INFO - 2025-08-19 06:41:56 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:41:56 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:56 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:56 --> URI Class Initialized
INFO - 2025-08-19 06:41:56 --> Router Class Initialized
INFO - 2025-08-19 06:41:56 --> Output Class Initialized
INFO - 2025-08-19 06:41:56 --> Security Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:56 --> Input Class Initialized
INFO - 2025-08-19 06:41:56 --> Language Class Initialized
INFO - 2025-08-19 06:41:56 --> Loader Class Initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:56 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:56 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:56 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:56 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:56 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:56 --> Controller Class Initialized
INFO - 2025-08-19 06:41:56 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:56 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:56 --> Total execution time: 0.0603
INFO - 2025-08-19 06:41:56 --> Config Class Initialized
INFO - 2025-08-19 06:41:56 --> Hooks Class Initialized
INFO - 2025-08-19 06:41:56 --> Config Class Initialized
INFO - 2025-08-19 06:41:56 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:41:56 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:56 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:56 --> URI Class Initialized
INFO - 2025-08-19 06:41:56 --> Router Class Initialized
DEBUG - 2025-08-19 06:41:56 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:56 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:56 --> Output Class Initialized
INFO - 2025-08-19 06:41:56 --> URI Class Initialized
INFO - 2025-08-19 06:41:56 --> Security Class Initialized
INFO - 2025-08-19 06:41:56 --> Router Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:56 --> Input Class Initialized
INFO - 2025-08-19 06:41:56 --> Output Class Initialized
INFO - 2025-08-19 06:41:56 --> Language Class Initialized
INFO - 2025-08-19 06:41:56 --> Security Class Initialized
INFO - 2025-08-19 06:41:56 --> Config Class Initialized
INFO - 2025-08-19 06:41:56 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 06:41:56 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:56 --> Input Class Initialized
INFO - 2025-08-19 06:41:56 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:56 --> Language Class Initialized
INFO - 2025-08-19 06:41:56 --> URI Class Initialized
INFO - 2025-08-19 06:41:56 --> Loader Class Initialized
INFO - 2025-08-19 06:41:56 --> Router Class Initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:56 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:56 --> Output Class Initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:56 --> Security Class Initialized
INFO - 2025-08-19 06:41:56 --> Loader Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:56 --> Input Class Initialized
INFO - 2025-08-19 06:41:56 --> Language Class Initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:56 --> Database Driver Class Initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:56 --> Helper loaded: string_helper
DEBUG - 2025-08-19 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:56 --> Database Driver Class Initialized
INFO - 2025-08-19 06:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:56 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:56 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:56 --> Controller Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:56 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:56 --> Loader Class Initialized
INFO - 2025-08-19 06:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:56 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:56 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:56 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:56 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:56 --> Controller Class Initialized
INFO - 2025-08-19 06:41:56 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:56 --> Database Driver Class Initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_model" initialized
DEBUG - 2025-08-19 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:56 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:56 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:41:56 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
INFO - 2025-08-19 06:41:56 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:56 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:56 --> Controller Class Initialized
INFO - 2025-08-19 06:41:56 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:41:56 --> Grades API - Got grades: 10
INFO - 2025-08-19 06:41:56 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:56 --> Total execution time: 0.1237
DEBUG - 2025-08-19 06:41:56 --> Grades API - Total count: 14
INFO - 2025-08-19 06:41:56 --> Final output sent to browser
INFO - 2025-08-19 06:41:56 --> Model "Grade_model" initialized
DEBUG - 2025-08-19 06:41:56 --> Total execution time: 0.1185
INFO - 2025-08-19 06:41:56 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:56 --> Config Class Initialized
INFO - 2025-08-19 06:41:56 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:56 --> Hooks Class Initialized
INFO - 2025-08-19 06:41:56 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:56 --> Model "Role_model" initialized
DEBUG - 2025-08-19 06:41:56 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:56 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:56 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:41:56 --> URI Class Initialized
INFO - 2025-08-19 06:41:56 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:56 --> Total execution time: 0.1174
INFO - 2025-08-19 06:41:56 --> Router Class Initialized
INFO - 2025-08-19 06:41:56 --> Output Class Initialized
INFO - 2025-08-19 06:41:56 --> Security Class Initialized
DEBUG - 2025-08-19 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:56 --> Input Class Initialized
INFO - 2025-08-19 06:41:56 --> Language Class Initialized
INFO - 2025-08-19 06:41:56 --> Loader Class Initialized
INFO - 2025-08-19 06:41:56 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:56 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:56 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:56 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:57 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:57 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:57 --> Controller Class Initialized
INFO - 2025-08-19 06:41:57 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:57 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:41:57 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:41:57 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:41:57 --> Grades API - Total count: 14
INFO - 2025-08-19 06:41:57 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:57 --> Total execution time: 0.1048
INFO - 2025-08-19 06:41:58 --> Config Class Initialized
INFO - 2025-08-19 06:41:58 --> Hooks Class Initialized
INFO - 2025-08-19 06:41:58 --> Config Class Initialized
INFO - 2025-08-19 06:41:58 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:41:58 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:58 --> Utf8 Class Initialized
DEBUG - 2025-08-19 06:41:58 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:58 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:58 --> URI Class Initialized
INFO - 2025-08-19 06:41:58 --> URI Class Initialized
INFO - 2025-08-19 06:41:58 --> Router Class Initialized
INFO - 2025-08-19 06:41:58 --> Router Class Initialized
INFO - 2025-08-19 06:41:58 --> Output Class Initialized
INFO - 2025-08-19 06:41:58 --> Output Class Initialized
INFO - 2025-08-19 06:41:58 --> Security Class Initialized
INFO - 2025-08-19 06:41:58 --> Security Class Initialized
DEBUG - 2025-08-19 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:58 --> Input Class Initialized
DEBUG - 2025-08-19 06:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:58 --> Input Class Initialized
INFO - 2025-08-19 06:41:58 --> Language Class Initialized
INFO - 2025-08-19 06:41:58 --> Language Class Initialized
INFO - 2025-08-19 06:41:58 --> Loader Class Initialized
INFO - 2025-08-19 06:41:58 --> Loader Class Initialized
INFO - 2025-08-19 06:41:58 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:58 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:58 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:58 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:58 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:58 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:58 --> Database Driver Class Initialized
INFO - 2025-08-19 06:41:58 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 06:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:58 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:58 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:58 --> Controller Class Initialized
INFO - 2025-08-19 06:41:58 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:58 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:58 --> Controller Class Initialized
INFO - 2025-08-19 06:41:58 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:41:58 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:41:58 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:58 --> Total execution time: 0.0861
INFO - 2025-08-19 06:41:58 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:58 --> Total execution time: 0.0889
INFO - 2025-08-19 06:41:59 --> Config Class Initialized
INFO - 2025-08-19 06:41:59 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:41:59 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:41:59 --> Utf8 Class Initialized
INFO - 2025-08-19 06:41:59 --> URI Class Initialized
INFO - 2025-08-19 06:41:59 --> Router Class Initialized
INFO - 2025-08-19 06:41:59 --> Output Class Initialized
INFO - 2025-08-19 06:41:59 --> Security Class Initialized
DEBUG - 2025-08-19 06:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:41:59 --> Input Class Initialized
INFO - 2025-08-19 06:41:59 --> Language Class Initialized
INFO - 2025-08-19 06:41:59 --> Loader Class Initialized
INFO - 2025-08-19 06:41:59 --> Helper loaded: url_helper
INFO - 2025-08-19 06:41:59 --> Helper loaded: security_helper
INFO - 2025-08-19 06:41:59 --> Helper loaded: string_helper
INFO - 2025-08-19 06:41:59 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:41:59 --> Helper loaded: form_helper
INFO - 2025-08-19 06:41:59 --> Form Validation Class Initialized
INFO - 2025-08-19 06:41:59 --> Controller Class Initialized
INFO - 2025-08-19 06:41:59 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Division_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Student_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Report_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Role_model" initialized
INFO - 2025-08-19 06:41:59 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:41:59 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:41:59 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:41:59 --> Grades API - Total count: 14
INFO - 2025-08-19 06:41:59 --> Final output sent to browser
DEBUG - 2025-08-19 06:41:59 --> Total execution time: 0.0906
INFO - 2025-08-19 06:42:03 --> Config Class Initialized
INFO - 2025-08-19 06:42:03 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:42:03 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:03 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:03 --> URI Class Initialized
INFO - 2025-08-19 06:42:03 --> Router Class Initialized
INFO - 2025-08-19 06:42:03 --> Output Class Initialized
INFO - 2025-08-19 06:42:03 --> Security Class Initialized
DEBUG - 2025-08-19 06:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:03 --> Input Class Initialized
INFO - 2025-08-19 06:42:03 --> Language Class Initialized
INFO - 2025-08-19 06:42:03 --> Loader Class Initialized
INFO - 2025-08-19 06:42:03 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:03 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:03 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:03 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:03 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:03 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:03 --> Controller Class Initialized
INFO - 2025-08-19 06:42:03 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:03 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:42:03 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":"10"}
DEBUG - 2025-08-19 06:42:03 --> Grades API - Got grades: 4
DEBUG - 2025-08-19 06:42:03 --> Grades API - Total count: 14
INFO - 2025-08-19 06:42:03 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:03 --> Total execution time: 0.0884
INFO - 2025-08-19 06:42:08 --> Config Class Initialized
INFO - 2025-08-19 06:42:08 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:42:08 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:08 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:08 --> URI Class Initialized
INFO - 2025-08-19 06:42:08 --> Router Class Initialized
INFO - 2025-08-19 06:42:08 --> Output Class Initialized
INFO - 2025-08-19 06:42:08 --> Security Class Initialized
DEBUG - 2025-08-19 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:08 --> Input Class Initialized
INFO - 2025-08-19 06:42:08 --> Language Class Initialized
INFO - 2025-08-19 06:42:08 --> Loader Class Initialized
INFO - 2025-08-19 06:42:08 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:08 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:08 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:08 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:08 --> Controller Class Initialized
INFO - 2025-08-19 06:42:08 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:42:08 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:08 --> Total execution time: 0.0887
INFO - 2025-08-19 06:42:08 --> Config Class Initialized
INFO - 2025-08-19 06:42:08 --> Config Class Initialized
INFO - 2025-08-19 06:42:08 --> Hooks Class Initialized
INFO - 2025-08-19 06:42:08 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:42:08 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:08 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:08 --> Config Class Initialized
INFO - 2025-08-19 06:42:08 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:42:08 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:08 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:08 --> URI Class Initialized
INFO - 2025-08-19 06:42:08 --> URI Class Initialized
DEBUG - 2025-08-19 06:42:08 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:08 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:08 --> Router Class Initialized
INFO - 2025-08-19 06:42:08 --> URI Class Initialized
INFO - 2025-08-19 06:42:08 --> Output Class Initialized
INFO - 2025-08-19 06:42:08 --> Router Class Initialized
INFO - 2025-08-19 06:42:08 --> Router Class Initialized
INFO - 2025-08-19 06:42:08 --> Security Class Initialized
INFO - 2025-08-19 06:42:08 --> Output Class Initialized
INFO - 2025-08-19 06:42:08 --> Output Class Initialized
DEBUG - 2025-08-19 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:08 --> Input Class Initialized
INFO - 2025-08-19 06:42:08 --> Security Class Initialized
INFO - 2025-08-19 06:42:08 --> Language Class Initialized
INFO - 2025-08-19 06:42:08 --> Security Class Initialized
DEBUG - 2025-08-19 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:08 --> Input Class Initialized
DEBUG - 2025-08-19 06:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:08 --> Input Class Initialized
INFO - 2025-08-19 06:42:08 --> Language Class Initialized
INFO - 2025-08-19 06:42:08 --> Language Class Initialized
INFO - 2025-08-19 06:42:08 --> Loader Class Initialized
INFO - 2025-08-19 06:42:08 --> Loader Class Initialized
INFO - 2025-08-19 06:42:08 --> Loader Class Initialized
INFO - 2025-08-19 06:42:08 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:08 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:08 --> Database Driver Class Initialized
INFO - 2025-08-19 06:42:08 --> Database Driver Class Initialized
INFO - 2025-08-19 06:42:08 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 06:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:08 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:08 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:08 --> Controller Class Initialized
INFO - 2025-08-19 06:42:08 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:08 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:08 --> Controller Class Initialized
INFO - 2025-08-19 06:42:08 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:08 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:08 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:08 --> Controller Class Initialized
INFO - 2025-08-19 06:42:08 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:42:08 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:08 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":"10"}
DEBUG - 2025-08-19 06:42:08 --> Total execution time: 0.0894
INFO - 2025-08-19 06:42:08 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:08 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:42:08 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:08 --> Total execution time: 0.0906
DEBUG - 2025-08-19 06:42:08 --> Grades API - Got grades: 3
DEBUG - 2025-08-19 06:42:08 --> Grades API - Total count: 13
INFO - 2025-08-19 06:42:08 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:08 --> Total execution time: 0.1013
INFO - 2025-08-19 06:42:11 --> Config Class Initialized
INFO - 2025-08-19 06:42:11 --> Hooks Class Initialized
INFO - 2025-08-19 06:42:11 --> Config Class Initialized
INFO - 2025-08-19 06:42:11 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:42:11 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 06:42:11 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:11 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:11 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:11 --> URI Class Initialized
INFO - 2025-08-19 06:42:11 --> URI Class Initialized
INFO - 2025-08-19 06:42:11 --> Router Class Initialized
INFO - 2025-08-19 06:42:11 --> Router Class Initialized
INFO - 2025-08-19 06:42:11 --> Output Class Initialized
INFO - 2025-08-19 06:42:11 --> Security Class Initialized
INFO - 2025-08-19 06:42:11 --> Output Class Initialized
DEBUG - 2025-08-19 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:11 --> Input Class Initialized
INFO - 2025-08-19 06:42:11 --> Security Class Initialized
INFO - 2025-08-19 06:42:11 --> Language Class Initialized
DEBUG - 2025-08-19 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:11 --> Input Class Initialized
INFO - 2025-08-19 06:42:11 --> Language Class Initialized
INFO - 2025-08-19 06:42:11 --> Loader Class Initialized
INFO - 2025-08-19 06:42:11 --> Loader Class Initialized
INFO - 2025-08-19 06:42:11 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:11 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:11 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:11 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:11 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:11 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:11 --> Database Driver Class Initialized
INFO - 2025-08-19 06:42:11 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 06:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:11 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:11 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:11 --> Controller Class Initialized
INFO - 2025-08-19 06:42:11 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:11 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:11 --> Controller Class Initialized
INFO - 2025-08-19 06:42:11 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:42:11 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:11 --> Total execution time: 0.0945
INFO - 2025-08-19 06:42:11 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:11 --> Total execution time: 0.0979
INFO - 2025-08-19 06:42:11 --> Config Class Initialized
INFO - 2025-08-19 06:42:11 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:42:11 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:11 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:11 --> URI Class Initialized
INFO - 2025-08-19 06:42:11 --> Router Class Initialized
INFO - 2025-08-19 06:42:11 --> Output Class Initialized
INFO - 2025-08-19 06:42:11 --> Security Class Initialized
DEBUG - 2025-08-19 06:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:11 --> Input Class Initialized
INFO - 2025-08-19 06:42:11 --> Language Class Initialized
INFO - 2025-08-19 06:42:11 --> Loader Class Initialized
INFO - 2025-08-19 06:42:11 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:11 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:11 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:11 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:11 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:11 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:11 --> Controller Class Initialized
INFO - 2025-08-19 06:42:11 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:11 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:42:11 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:42:11 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:42:11 --> Grades API - Total count: 13
INFO - 2025-08-19 06:42:11 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:11 --> Total execution time: 0.1069
INFO - 2025-08-19 06:42:21 --> Config Class Initialized
INFO - 2025-08-19 06:42:21 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:42:21 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:21 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:21 --> URI Class Initialized
INFO - 2025-08-19 06:42:21 --> Router Class Initialized
INFO - 2025-08-19 06:42:21 --> Output Class Initialized
INFO - 2025-08-19 06:42:21 --> Security Class Initialized
DEBUG - 2025-08-19 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:21 --> Input Class Initialized
INFO - 2025-08-19 06:42:21 --> Language Class Initialized
INFO - 2025-08-19 06:42:21 --> Loader Class Initialized
INFO - 2025-08-19 06:42:21 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:21 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:21 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:21 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:21 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:21 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:21 --> Controller Class Initialized
INFO - 2025-08-19 06:42:21 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:42:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 06:42:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 06:42:21 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:21 --> Total execution time: 0.0965
INFO - 2025-08-19 06:42:21 --> Config Class Initialized
INFO - 2025-08-19 06:42:21 --> Hooks Class Initialized
INFO - 2025-08-19 06:42:21 --> Config Class Initialized
INFO - 2025-08-19 06:42:21 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:42:21 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:21 --> Utf8 Class Initialized
DEBUG - 2025-08-19 06:42:21 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:21 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:21 --> URI Class Initialized
INFO - 2025-08-19 06:42:21 --> URI Class Initialized
INFO - 2025-08-19 06:42:21 --> Router Class Initialized
INFO - 2025-08-19 06:42:21 --> Router Class Initialized
INFO - 2025-08-19 06:42:21 --> Output Class Initialized
INFO - 2025-08-19 06:42:21 --> Output Class Initialized
INFO - 2025-08-19 06:42:21 --> Security Class Initialized
INFO - 2025-08-19 06:42:21 --> Security Class Initialized
DEBUG - 2025-08-19 06:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:21 --> Input Class Initialized
INFO - 2025-08-19 06:42:21 --> Input Class Initialized
INFO - 2025-08-19 06:42:21 --> Language Class Initialized
INFO - 2025-08-19 06:42:21 --> Language Class Initialized
INFO - 2025-08-19 06:42:21 --> Loader Class Initialized
INFO - 2025-08-19 06:42:21 --> Loader Class Initialized
INFO - 2025-08-19 06:42:21 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:21 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:21 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:21 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:21 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:21 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:21 --> Database Driver Class Initialized
INFO - 2025-08-19 06:42:21 --> Config Class Initialized
INFO - 2025-08-19 06:42:21 --> Hooks Class Initialized
INFO - 2025-08-19 06:42:21 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:42:21 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:42:21 --> Utf8 Class Initialized
INFO - 2025-08-19 06:42:21 --> URI Class Initialized
DEBUG - 2025-08-19 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:21 --> Router Class Initialized
INFO - 2025-08-19 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:21 --> Output Class Initialized
INFO - 2025-08-19 06:42:21 --> Security Class Initialized
INFO - 2025-08-19 06:42:21 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:21 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:21 --> Controller Class Initialized
INFO - 2025-08-19 06:42:21 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:21 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:21 --> Controller Class Initialized
DEBUG - 2025-08-19 06:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:42:21 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:21 --> Input Class Initialized
INFO - 2025-08-19 06:42:21 --> Language Class Initialized
INFO - 2025-08-19 06:42:21 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:21 --> Loader Class Initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:21 --> Helper loaded: url_helper
INFO - 2025-08-19 06:42:21 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:21 --> Helper loaded: security_helper
INFO - 2025-08-19 06:42:21 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:21 --> Helper loaded: string_helper
INFO - 2025-08-19 06:42:21 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:21 --> Database Driver Class Initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:21 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:21 --> Total execution time: 0.0980
INFO - 2025-08-19 06:42:21 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Complaint_model" initialized
DEBUG - 2025-08-19 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:42:21 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:42:21 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:42:21 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:21 --> Total execution time: 0.1126
INFO - 2025-08-19 06:42:21 --> Helper loaded: form_helper
INFO - 2025-08-19 06:42:21 --> Form Validation Class Initialized
INFO - 2025-08-19 06:42:21 --> Controller Class Initialized
INFO - 2025-08-19 06:42:21 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Division_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Student_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Report_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Role_model" initialized
INFO - 2025-08-19 06:42:21 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:42:21 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:42:21 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:42:21 --> Grades API - Total count: 14
INFO - 2025-08-19 06:42:21 --> Final output sent to browser
DEBUG - 2025-08-19 06:42:21 --> Total execution time: 0.1284
INFO - 2025-08-19 06:52:03 --> Config Class Initialized
INFO - 2025-08-19 06:52:03 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:03 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:03 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:03 --> URI Class Initialized
INFO - 2025-08-19 06:52:03 --> Router Class Initialized
INFO - 2025-08-19 06:52:03 --> Output Class Initialized
INFO - 2025-08-19 06:52:03 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:03 --> Input Class Initialized
INFO - 2025-08-19 06:52:03 --> Language Class Initialized
INFO - 2025-08-19 06:52:03 --> Loader Class Initialized
INFO - 2025-08-19 06:52:03 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:03 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:03 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:03 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:03 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:03 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:03 --> Controller Class Initialized
INFO - 2025-08-19 06:52:03 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:03 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:03 --> Total execution time: 0.1048
INFO - 2025-08-19 06:52:03 --> Config Class Initialized
INFO - 2025-08-19 06:52:03 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:03 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:03 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:03 --> URI Class Initialized
INFO - 2025-08-19 06:52:03 --> Router Class Initialized
INFO - 2025-08-19 06:52:03 --> Output Class Initialized
INFO - 2025-08-19 06:52:03 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:03 --> Input Class Initialized
INFO - 2025-08-19 06:52:03 --> Language Class Initialized
INFO - 2025-08-19 06:52:03 --> Loader Class Initialized
INFO - 2025-08-19 06:52:03 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:03 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:03 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:03 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:03 --> Config Class Initialized
INFO - 2025-08-19 06:52:03 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 06:52:03 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:03 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:03 --> URI Class Initialized
INFO - 2025-08-19 06:52:03 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:03 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:03 --> Controller Class Initialized
INFO - 2025-08-19 06:52:03 --> Router Class Initialized
INFO - 2025-08-19 06:52:03 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:03 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:03 --> Total execution time: 0.1330
INFO - 2025-08-19 06:52:03 --> Output Class Initialized
INFO - 2025-08-19 06:52:03 --> Security Class Initialized
INFO - 2025-08-19 06:52:03 --> Config Class Initialized
INFO - 2025-08-19 06:52:03 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:03 --> Input Class Initialized
INFO - 2025-08-19 06:52:03 --> Language Class Initialized
INFO - 2025-08-19 06:52:03 --> Config Class Initialized
INFO - 2025-08-19 06:52:03 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:03 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:03 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:03 --> URI Class Initialized
INFO - 2025-08-19 06:52:03 --> Router Class Initialized
INFO - 2025-08-19 06:52:03 --> Output Class Initialized
INFO - 2025-08-19 06:52:03 --> Loader Class Initialized
INFO - 2025-08-19 06:52:04 --> Security Class Initialized
INFO - 2025-08-19 06:52:04 --> Helper loaded: url_helper
DEBUG - 2025-08-19 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:04 --> Input Class Initialized
INFO - 2025-08-19 06:52:04 --> Language Class Initialized
INFO - 2025-08-19 06:52:04 --> Helper loaded: security_helper
DEBUG - 2025-08-19 06:52:04 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:04 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:04 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:04 --> URI Class Initialized
INFO - 2025-08-19 06:52:04 --> Loader Class Initialized
INFO - 2025-08-19 06:52:04 --> Router Class Initialized
INFO - 2025-08-19 06:52:04 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:04 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:04 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:04 --> Output Class Initialized
INFO - 2025-08-19 06:52:04 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:04 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:04 --> Input Class Initialized
INFO - 2025-08-19 06:52:04 --> Language Class Initialized
INFO - 2025-08-19 06:52:04 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:04 --> Loader Class Initialized
DEBUG - 2025-08-19 06:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:04 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:04 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:04 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:04 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:04 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:04 --> Controller Class Initialized
INFO - 2025-08-19 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:04 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:04 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:04 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:04 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:04 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:04 --> Controller Class Initialized
INFO - 2025-08-19 06:52:04 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Academic_year_model" initialized
DEBUG - 2025-08-19 06:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:04 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:04 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:04 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:04 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:04 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:04 --> Controller Class Initialized
INFO - 2025-08-19 06:52:04 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:04 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
INFO - 2025-08-19 06:52:04 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:04 --> Final output sent to browser
INFO - 2025-08-19 06:52:04 --> Model "Division_model" initialized
DEBUG - 2025-08-19 06:52:04 --> Total execution time: 0.1416
INFO - 2025-08-19 06:52:04 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:04 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:52:04 --> Grades API - Total count: 14
INFO - 2025-08-19 06:52:04 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:04 --> Total execution time: 0.2275
INFO - 2025-08-19 06:52:04 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:04 --> Total execution time: 0.2108
INFO - 2025-08-19 06:52:04 --> Config Class Initialized
INFO - 2025-08-19 06:52:04 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:04 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:04 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:04 --> URI Class Initialized
INFO - 2025-08-19 06:52:04 --> Router Class Initialized
INFO - 2025-08-19 06:52:04 --> Output Class Initialized
INFO - 2025-08-19 06:52:04 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:04 --> Input Class Initialized
INFO - 2025-08-19 06:52:04 --> Language Class Initialized
INFO - 2025-08-19 06:52:04 --> Loader Class Initialized
INFO - 2025-08-19 06:52:04 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:04 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:04 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:04 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:04 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:04 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:04 --> Controller Class Initialized
INFO - 2025-08-19 06:52:04 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:04 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:04 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:52:04 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:52:04 --> Grades API - Total count: 14
INFO - 2025-08-19 06:52:04 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:04 --> Total execution time: 0.1273
INFO - 2025-08-19 06:52:05 --> Config Class Initialized
INFO - 2025-08-19 06:52:05 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:05 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:05 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:05 --> URI Class Initialized
INFO - 2025-08-19 06:52:05 --> Router Class Initialized
INFO - 2025-08-19 06:52:05 --> Output Class Initialized
INFO - 2025-08-19 06:52:05 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:05 --> Input Class Initialized
INFO - 2025-08-19 06:52:05 --> Language Class Initialized
INFO - 2025-08-19 06:52:05 --> Loader Class Initialized
INFO - 2025-08-19 06:52:05 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:05 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:05 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:05 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:05 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:05 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:05 --> Controller Class Initialized
INFO - 2025-08-19 06:52:05 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:05 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:05 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:05 --> Total execution time: 0.1019
INFO - 2025-08-19 06:52:06 --> Config Class Initialized
INFO - 2025-08-19 06:52:06 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:06 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:06 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:06 --> URI Class Initialized
INFO - 2025-08-19 06:52:06 --> Router Class Initialized
INFO - 2025-08-19 06:52:06 --> Output Class Initialized
INFO - 2025-08-19 06:52:06 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:06 --> Input Class Initialized
INFO - 2025-08-19 06:52:06 --> Language Class Initialized
INFO - 2025-08-19 06:52:06 --> Loader Class Initialized
INFO - 2025-08-19 06:52:06 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:06 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:06 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:06 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:06 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:06 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:06 --> Controller Class Initialized
INFO - 2025-08-19 06:52:06 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:06 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:06 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:52:06 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:52:06 --> Grades API - Total count: 14
INFO - 2025-08-19 06:52:06 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:06 --> Total execution time: 0.1380
INFO - 2025-08-19 06:52:10 --> Config Class Initialized
INFO - 2025-08-19 06:52:10 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:10 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:10 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:10 --> URI Class Initialized
INFO - 2025-08-19 06:52:10 --> Router Class Initialized
INFO - 2025-08-19 06:52:10 --> Output Class Initialized
INFO - 2025-08-19 06:52:10 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:10 --> Input Class Initialized
INFO - 2025-08-19 06:52:10 --> Language Class Initialized
INFO - 2025-08-19 06:52:10 --> Loader Class Initialized
INFO - 2025-08-19 06:52:10 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:10 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:10 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:10 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:10 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:10 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:10 --> Controller Class Initialized
INFO - 2025-08-19 06:52:10 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:10 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:10 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:10 --> Total execution time: 0.0891
INFO - 2025-08-19 06:52:10 --> Config Class Initialized
INFO - 2025-08-19 06:52:10 --> Hooks Class Initialized
INFO - 2025-08-19 06:52:10 --> Config Class Initialized
INFO - 2025-08-19 06:52:10 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:10 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:10 --> Utf8 Class Initialized
DEBUG - 2025-08-19 06:52:10 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:10 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:10 --> URI Class Initialized
INFO - 2025-08-19 06:52:10 --> URI Class Initialized
INFO - 2025-08-19 06:52:11 --> Config Class Initialized
INFO - 2025-08-19 06:52:11 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:11 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:11 --> Router Class Initialized
INFO - 2025-08-19 06:52:11 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:11 --> URI Class Initialized
INFO - 2025-08-19 06:52:11 --> Output Class Initialized
INFO - 2025-08-19 06:52:11 --> Router Class Initialized
INFO - 2025-08-19 06:52:11 --> Security Class Initialized
INFO - 2025-08-19 06:52:11 --> Router Class Initialized
DEBUG - 2025-08-19 06:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:11 --> Input Class Initialized
INFO - 2025-08-19 06:52:11 --> Output Class Initialized
INFO - 2025-08-19 06:52:11 --> Language Class Initialized
INFO - 2025-08-19 06:52:11 --> Output Class Initialized
INFO - 2025-08-19 06:52:11 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:11 --> Input Class Initialized
INFO - 2025-08-19 06:52:11 --> Security Class Initialized
INFO - 2025-08-19 06:52:11 --> Language Class Initialized
DEBUG - 2025-08-19 06:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:11 --> Input Class Initialized
INFO - 2025-08-19 06:52:11 --> Language Class Initialized
INFO - 2025-08-19 06:52:11 --> Loader Class Initialized
INFO - 2025-08-19 06:52:11 --> Loader Class Initialized
INFO - 2025-08-19 06:52:11 --> Loader Class Initialized
INFO - 2025-08-19 06:52:11 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:11 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:11 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:11 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:11 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:11 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:11 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:11 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:11 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 06:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:11 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:11 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:11 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:11 --> Controller Class Initialized
INFO - 2025-08-19 06:52:11 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:11 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:11 --> Controller Class Initialized
INFO - 2025-08-19 06:52:11 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:11 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:11 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:11 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
INFO - 2025-08-19 06:52:11 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:11 --> Grades API - Got grades: 10
INFO - 2025-08-19 06:52:11 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:11 --> Total execution time: 0.1183
DEBUG - 2025-08-19 06:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 06:52:11 --> Grades API - Total count: 13
INFO - 2025-08-19 06:52:11 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:11 --> Total execution time: 0.1239
INFO - 2025-08-19 06:52:11 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:11 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:11 --> Controller Class Initialized
INFO - 2025-08-19 06:52:11 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:11 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:11 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:11 --> Total execution time: 0.1674
INFO - 2025-08-19 06:52:25 --> Config Class Initialized
INFO - 2025-08-19 06:52:25 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:25 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:25 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:25 --> URI Class Initialized
INFO - 2025-08-19 06:52:25 --> Router Class Initialized
INFO - 2025-08-19 06:52:25 --> Output Class Initialized
INFO - 2025-08-19 06:52:25 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:25 --> Input Class Initialized
INFO - 2025-08-19 06:52:25 --> Language Class Initialized
INFO - 2025-08-19 06:52:25 --> Loader Class Initialized
INFO - 2025-08-19 06:52:25 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:25 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:25 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:25 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:25 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:25 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:25 --> Controller Class Initialized
INFO - 2025-08-19 06:52:25 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:25 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 06:52:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 06:52:25 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:25 --> Total execution time: 0.0996
INFO - 2025-08-19 06:52:25 --> Config Class Initialized
INFO - 2025-08-19 06:52:25 --> Hooks Class Initialized
INFO - 2025-08-19 06:52:25 --> Config Class Initialized
INFO - 2025-08-19 06:52:25 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:25 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:25 --> Config Class Initialized
INFO - 2025-08-19 06:52:25 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:25 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:25 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:25 --> URI Class Initialized
INFO - 2025-08-19 06:52:25 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:25 --> URI Class Initialized
INFO - 2025-08-19 06:52:25 --> Router Class Initialized
DEBUG - 2025-08-19 06:52:25 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:25 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:25 --> Router Class Initialized
INFO - 2025-08-19 06:52:25 --> Output Class Initialized
INFO - 2025-08-19 06:52:25 --> URI Class Initialized
INFO - 2025-08-19 06:52:25 --> Output Class Initialized
INFO - 2025-08-19 06:52:25 --> Security Class Initialized
INFO - 2025-08-19 06:52:25 --> Router Class Initialized
DEBUG - 2025-08-19 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:25 --> Security Class Initialized
INFO - 2025-08-19 06:52:25 --> Input Class Initialized
INFO - 2025-08-19 06:52:25 --> Output Class Initialized
DEBUG - 2025-08-19 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:25 --> Input Class Initialized
INFO - 2025-08-19 06:52:25 --> Language Class Initialized
INFO - 2025-08-19 06:52:25 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:25 --> Input Class Initialized
INFO - 2025-08-19 06:52:25 --> Language Class Initialized
INFO - 2025-08-19 06:52:25 --> Loader Class Initialized
INFO - 2025-08-19 06:52:25 --> Language Class Initialized
INFO - 2025-08-19 06:52:25 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:25 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:25 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:25 --> Loader Class Initialized
INFO - 2025-08-19 06:52:25 --> Loader Class Initialized
INFO - 2025-08-19 06:52:25 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:25 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:25 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:25 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:25 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:25 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:25 --> Helper loaded: string_helper
DEBUG - 2025-08-19 06:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:26 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:26 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:26 --> Controller Class Initialized
INFO - 2025-08-19 06:52:26 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:26 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:26 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 06:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:26 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:26 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:26 --> Controller Class Initialized
INFO - 2025-08-19 06:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:26 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:26 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:26 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:26 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:26 --> Controller Class Initialized
INFO - 2025-08-19 06:52:26 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:26 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
INFO - 2025-08-19 06:52:26 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:26 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:26 --> Total execution time: 0.1552
INFO - 2025-08-19 06:52:26 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:26 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:26 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:26 --> Total execution time: 0.1559
DEBUG - 2025-08-19 06:52:26 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:52:26 --> Grades API - Total count: 14
INFO - 2025-08-19 06:52:26 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:26 --> Total execution time: 0.1638
INFO - 2025-08-19 06:52:31 --> Config Class Initialized
INFO - 2025-08-19 06:52:31 --> Config Class Initialized
INFO - 2025-08-19 06:52:31 --> Hooks Class Initialized
INFO - 2025-08-19 06:52:31 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:31 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 06:52:31 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:31 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:31 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:31 --> URI Class Initialized
INFO - 2025-08-19 06:52:31 --> URI Class Initialized
INFO - 2025-08-19 06:52:31 --> Router Class Initialized
INFO - 2025-08-19 06:52:31 --> Router Class Initialized
INFO - 2025-08-19 06:52:31 --> Output Class Initialized
INFO - 2025-08-19 06:52:31 --> Output Class Initialized
INFO - 2025-08-19 06:52:31 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:31 --> Input Class Initialized
INFO - 2025-08-19 06:52:31 --> Security Class Initialized
INFO - 2025-08-19 06:52:31 --> Language Class Initialized
DEBUG - 2025-08-19 06:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:31 --> Input Class Initialized
INFO - 2025-08-19 06:52:31 --> Language Class Initialized
INFO - 2025-08-19 06:52:31 --> Loader Class Initialized
INFO - 2025-08-19 06:52:31 --> Loader Class Initialized
INFO - 2025-08-19 06:52:31 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:31 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:31 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:31 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:31 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:31 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:31 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:31 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 06:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:31 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:31 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:31 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:31 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:31 --> Controller Class Initialized
INFO - 2025-08-19 06:52:31 --> Controller Class Initialized
INFO - 2025-08-19 06:52:31 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:31 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:31 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:31 --> Total execution time: 0.1049
INFO - 2025-08-19 06:52:31 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:31 --> Total execution time: 0.1101
INFO - 2025-08-19 06:52:32 --> Config Class Initialized
INFO - 2025-08-19 06:52:32 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:32 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:32 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:32 --> URI Class Initialized
INFO - 2025-08-19 06:52:32 --> Router Class Initialized
INFO - 2025-08-19 06:52:32 --> Output Class Initialized
INFO - 2025-08-19 06:52:32 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:32 --> Input Class Initialized
INFO - 2025-08-19 06:52:32 --> Language Class Initialized
INFO - 2025-08-19 06:52:32 --> Loader Class Initialized
INFO - 2025-08-19 06:52:32 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:32 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:32 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:32 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:32 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:32 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:32 --> Controller Class Initialized
INFO - 2025-08-19 06:52:32 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:32 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:52:32 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 06:52:32 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 06:52:32 --> Grades API - Total count: 14
INFO - 2025-08-19 06:52:32 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:32 --> Total execution time: 0.1149
INFO - 2025-08-19 06:52:34 --> Config Class Initialized
INFO - 2025-08-19 06:52:34 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:52:34 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:34 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:34 --> URI Class Initialized
INFO - 2025-08-19 06:52:34 --> Config Class Initialized
INFO - 2025-08-19 06:52:34 --> Hooks Class Initialized
INFO - 2025-08-19 06:52:34 --> Router Class Initialized
INFO - 2025-08-19 06:52:34 --> Output Class Initialized
INFO - 2025-08-19 06:52:34 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:34 --> Input Class Initialized
INFO - 2025-08-19 06:52:34 --> Language Class Initialized
DEBUG - 2025-08-19 06:52:34 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:52:34 --> Utf8 Class Initialized
INFO - 2025-08-19 06:52:34 --> Loader Class Initialized
INFO - 2025-08-19 06:52:34 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:34 --> URI Class Initialized
INFO - 2025-08-19 06:52:34 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:34 --> Helper loaded: string_helper
INFO - 2025-08-19 06:52:34 --> Router Class Initialized
INFO - 2025-08-19 06:52:34 --> Output Class Initialized
INFO - 2025-08-19 06:52:34 --> Security Class Initialized
DEBUG - 2025-08-19 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:52:34 --> Input Class Initialized
INFO - 2025-08-19 06:52:34 --> Language Class Initialized
INFO - 2025-08-19 06:52:34 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:34 --> Loader Class Initialized
INFO - 2025-08-19 06:52:34 --> Helper loaded: url_helper
INFO - 2025-08-19 06:52:34 --> Helper loaded: security_helper
INFO - 2025-08-19 06:52:34 --> Helper loaded: string_helper
DEBUG - 2025-08-19 06:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:34 --> Database Driver Class Initialized
INFO - 2025-08-19 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:34 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:34 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:34 --> Controller Class Initialized
INFO - 2025-08-19 06:52:34 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 06:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:52:34 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:34 --> Helper loaded: form_helper
INFO - 2025-08-19 06:52:34 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:34 --> Form Validation Class Initialized
INFO - 2025-08-19 06:52:34 --> Controller Class Initialized
INFO - 2025-08-19 06:52:34 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Division_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Student_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:52:34 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:34 --> Total execution time: 0.1835
INFO - 2025-08-19 06:52:34 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Report_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Role_model" initialized
INFO - 2025-08-19 06:52:34 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:52:34 --> Final output sent to browser
DEBUG - 2025-08-19 06:52:34 --> Total execution time: 0.2050
INFO - 2025-08-19 06:53:31 --> Config Class Initialized
INFO - 2025-08-19 06:53:31 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:53:31 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:53:31 --> Utf8 Class Initialized
INFO - 2025-08-19 06:53:31 --> URI Class Initialized
INFO - 2025-08-19 06:53:31 --> Router Class Initialized
INFO - 2025-08-19 06:53:31 --> Output Class Initialized
INFO - 2025-08-19 06:53:31 --> Security Class Initialized
DEBUG - 2025-08-19 06:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:53:31 --> Input Class Initialized
INFO - 2025-08-19 06:53:31 --> Language Class Initialized
INFO - 2025-08-19 06:53:31 --> Loader Class Initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: url_helper
INFO - 2025-08-19 06:53:31 --> Helper loaded: security_helper
INFO - 2025-08-19 06:53:31 --> Helper loaded: string_helper
INFO - 2025-08-19 06:53:31 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:53:31 --> Helper loaded: form_helper
INFO - 2025-08-19 06:53:31 --> Form Validation Class Initialized
INFO - 2025-08-19 06:53:31 --> Controller Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Division_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Student_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Report_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Role_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:53:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 06:53:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 06:53:31 --> Final output sent to browser
DEBUG - 2025-08-19 06:53:31 --> Total execution time: 0.1673
INFO - 2025-08-19 06:53:31 --> Config Class Initialized
INFO - 2025-08-19 06:53:31 --> Hooks Class Initialized
INFO - 2025-08-19 06:53:31 --> Config Class Initialized
INFO - 2025-08-19 06:53:31 --> Hooks Class Initialized
INFO - 2025-08-19 06:53:31 --> Config Class Initialized
INFO - 2025-08-19 06:53:31 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:53:31 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:53:31 --> Utf8 Class Initialized
INFO - 2025-08-19 06:53:31 --> URI Class Initialized
DEBUG - 2025-08-19 06:53:31 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:53:31 --> Utf8 Class Initialized
INFO - 2025-08-19 06:53:31 --> Router Class Initialized
INFO - 2025-08-19 06:53:31 --> URI Class Initialized
INFO - 2025-08-19 06:53:31 --> Output Class Initialized
INFO - 2025-08-19 06:53:31 --> Router Class Initialized
INFO - 2025-08-19 06:53:31 --> Security Class Initialized
DEBUG - 2025-08-19 06:53:31 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:53:31 --> Utf8 Class Initialized
INFO - 2025-08-19 06:53:31 --> Output Class Initialized
DEBUG - 2025-08-19 06:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:53:31 --> Input Class Initialized
INFO - 2025-08-19 06:53:31 --> Language Class Initialized
INFO - 2025-08-19 06:53:31 --> Security Class Initialized
INFO - 2025-08-19 06:53:31 --> URI Class Initialized
DEBUG - 2025-08-19 06:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:53:31 --> Input Class Initialized
INFO - 2025-08-19 06:53:31 --> Language Class Initialized
INFO - 2025-08-19 06:53:31 --> Router Class Initialized
INFO - 2025-08-19 06:53:31 --> Output Class Initialized
INFO - 2025-08-19 06:53:31 --> Loader Class Initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: url_helper
INFO - 2025-08-19 06:53:31 --> Security Class Initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: security_helper
INFO - 2025-08-19 06:53:31 --> Loader Class Initialized
DEBUG - 2025-08-19 06:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:53:31 --> Input Class Initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: string_helper
INFO - 2025-08-19 06:53:31 --> Language Class Initialized
INFO - 2025-08-19 06:53:31 --> Database Driver Class Initialized
INFO - 2025-08-19 06:53:31 --> Loader Class Initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: url_helper
INFO - 2025-08-19 06:53:31 --> Config Class Initialized
INFO - 2025-08-19 06:53:31 --> Hooks Class Initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: url_helper
INFO - 2025-08-19 06:53:31 --> Helper loaded: security_helper
INFO - 2025-08-19 06:53:31 --> Helper loaded: string_helper
INFO - 2025-08-19 06:53:31 --> Helper loaded: security_helper
INFO - 2025-08-19 06:53:31 --> Helper loaded: string_helper
DEBUG - 2025-08-19 06:53:31 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 06:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:53:31 --> Utf8 Class Initialized
INFO - 2025-08-19 06:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:53:31 --> URI Class Initialized
INFO - 2025-08-19 06:53:31 --> Database Driver Class Initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: form_helper
INFO - 2025-08-19 06:53:31 --> Form Validation Class Initialized
INFO - 2025-08-19 06:53:31 --> Controller Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:53:31 --> Router Class Initialized
INFO - 2025-08-19 06:53:31 --> Output Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:53:31 --> Security Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Division_model" initialized
DEBUG - 2025-08-19 06:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:53:31 --> Input Class Initialized
DEBUG - 2025-08-19 06:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:53:31 --> Model "Student_model" initialized
INFO - 2025-08-19 06:53:31 --> Language Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:53:31 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: form_helper
INFO - 2025-08-19 06:53:31 --> Form Validation Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:53:31 --> Controller Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:53:31 --> Database Driver Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Complaint_model" initialized
DEBUG - 2025-08-19 06:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:53:31 --> Model "Report_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Role_model" initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: form_helper
INFO - 2025-08-19 06:53:31 --> Form Validation Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:53:31 --> Controller Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Division_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Division_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Student_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Student_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Report_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Role_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:53:31 --> Final output sent to browser
DEBUG - 2025-08-19 06:53:31 --> Total execution time: 0.1339
INFO - 2025-08-19 06:53:31 --> Model "Report_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Role_model" initialized
INFO - 2025-08-19 06:53:31 --> Final output sent to browser
DEBUG - 2025-08-19 06:53:31 --> Total execution time: 0.1441
INFO - 2025-08-19 06:53:31 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:53:31 --> Loader Class Initialized
INFO - 2025-08-19 06:53:31 --> Helper loaded: url_helper
INFO - 2025-08-19 06:53:31 --> Helper loaded: security_helper
INFO - 2025-08-19 06:53:31 --> Final output sent to browser
DEBUG - 2025-08-19 06:53:31 --> Total execution time: 0.1660
INFO - 2025-08-19 06:53:31 --> Helper loaded: string_helper
INFO - 2025-08-19 06:53:31 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:53:31 --> Helper loaded: form_helper
INFO - 2025-08-19 06:53:31 --> Form Validation Class Initialized
INFO - 2025-08-19 06:53:31 --> Controller Class Initialized
INFO - 2025-08-19 06:53:31 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Division_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Student_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Report_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Role_model" initialized
INFO - 2025-08-19 06:53:31 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:53:31 --> Final output sent to browser
DEBUG - 2025-08-19 06:53:31 --> Total execution time: 0.2663
INFO - 2025-08-19 06:53:59 --> Config Class Initialized
INFO - 2025-08-19 06:53:59 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:53:59 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:53:59 --> Utf8 Class Initialized
INFO - 2025-08-19 06:53:59 --> URI Class Initialized
INFO - 2025-08-19 06:53:59 --> Router Class Initialized
INFO - 2025-08-19 06:53:59 --> Output Class Initialized
INFO - 2025-08-19 06:53:59 --> Security Class Initialized
DEBUG - 2025-08-19 06:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:53:59 --> Input Class Initialized
INFO - 2025-08-19 06:53:59 --> Language Class Initialized
INFO - 2025-08-19 06:53:59 --> Loader Class Initialized
INFO - 2025-08-19 06:53:59 --> Helper loaded: url_helper
INFO - 2025-08-19 06:53:59 --> Helper loaded: security_helper
INFO - 2025-08-19 06:53:59 --> Helper loaded: string_helper
INFO - 2025-08-19 06:53:59 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:53:59 --> Helper loaded: form_helper
INFO - 2025-08-19 06:53:59 --> Form Validation Class Initialized
INFO - 2025-08-19 06:53:59 --> Controller Class Initialized
INFO - 2025-08-19 06:53:59 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Division_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Student_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Report_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Role_model" initialized
INFO - 2025-08-19 06:53:59 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:53:59 --> Final output sent to browser
DEBUG - 2025-08-19 06:53:59 --> Total execution time: 0.1727
INFO - 2025-08-19 06:54:15 --> Config Class Initialized
INFO - 2025-08-19 06:54:15 --> Config Class Initialized
INFO - 2025-08-19 06:54:15 --> Hooks Class Initialized
INFO - 2025-08-19 06:54:15 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:54:15 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 06:54:15 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:54:15 --> Utf8 Class Initialized
INFO - 2025-08-19 06:54:15 --> Utf8 Class Initialized
INFO - 2025-08-19 06:54:15 --> URI Class Initialized
INFO - 2025-08-19 06:54:15 --> Config Class Initialized
INFO - 2025-08-19 06:54:15 --> URI Class Initialized
INFO - 2025-08-19 06:54:15 --> Hooks Class Initialized
INFO - 2025-08-19 06:54:15 --> Router Class Initialized
INFO - 2025-08-19 06:54:15 --> Router Class Initialized
INFO - 2025-08-19 06:54:15 --> Output Class Initialized
INFO - 2025-08-19 06:54:15 --> Output Class Initialized
INFO - 2025-08-19 06:54:15 --> Security Class Initialized
INFO - 2025-08-19 06:54:15 --> Security Class Initialized
DEBUG - 2025-08-19 06:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 06:54:15 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:54:15 --> Input Class Initialized
DEBUG - 2025-08-19 06:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:54:15 --> Utf8 Class Initialized
INFO - 2025-08-19 06:54:15 --> Input Class Initialized
INFO - 2025-08-19 06:54:15 --> Language Class Initialized
INFO - 2025-08-19 06:54:15 --> Language Class Initialized
INFO - 2025-08-19 06:54:15 --> URI Class Initialized
INFO - 2025-08-19 06:54:15 --> Router Class Initialized
INFO - 2025-08-19 06:54:15 --> Output Class Initialized
INFO - 2025-08-19 06:54:15 --> Security Class Initialized
DEBUG - 2025-08-19 06:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:54:15 --> Loader Class Initialized
INFO - 2025-08-19 06:54:15 --> Loader Class Initialized
INFO - 2025-08-19 06:54:15 --> Input Class Initialized
INFO - 2025-08-19 06:54:15 --> Helper loaded: url_helper
INFO - 2025-08-19 06:54:15 --> Helper loaded: security_helper
INFO - 2025-08-19 06:54:15 --> Helper loaded: url_helper
INFO - 2025-08-19 06:54:15 --> Helper loaded: string_helper
INFO - 2025-08-19 06:54:15 --> Language Class Initialized
INFO - 2025-08-19 06:54:15 --> Helper loaded: security_helper
INFO - 2025-08-19 06:54:15 --> Helper loaded: string_helper
INFO - 2025-08-19 06:54:15 --> Database Driver Class Initialized
INFO - 2025-08-19 06:54:15 --> Loader Class Initialized
INFO - 2025-08-19 06:54:15 --> Helper loaded: url_helper
INFO - 2025-08-19 06:54:15 --> Database Driver Class Initialized
INFO - 2025-08-19 06:54:15 --> Helper loaded: security_helper
DEBUG - 2025-08-19 06:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:54:15 --> Helper loaded: string_helper
INFO - 2025-08-19 06:54:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 06:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:54:15 --> Helper loaded: form_helper
INFO - 2025-08-19 06:54:15 --> Form Validation Class Initialized
INFO - 2025-08-19 06:54:15 --> Controller Class Initialized
INFO - 2025-08-19 06:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:54:15 --> Database Driver Class Initialized
INFO - 2025-08-19 06:54:15 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:54:15 --> Helper loaded: form_helper
INFO - 2025-08-19 06:54:15 --> Form Validation Class Initialized
INFO - 2025-08-19 06:54:15 --> Controller Class Initialized
INFO - 2025-08-19 06:54:15 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Division_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 06:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:54:15 --> Model "Student_model" initialized
INFO - 2025-08-19 06:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:54:15 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Division_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:54:15 --> Helper loaded: form_helper
INFO - 2025-08-19 06:54:15 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:54:15 --> Form Validation Class Initialized
INFO - 2025-08-19 06:54:15 --> Model "Student_model" initialized
INFO - 2025-08-19 06:54:15 --> Controller Class Initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Division_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Student_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Report_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Role_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Report_model" initialized
DEBUG - 2025-08-19 06:54:15 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 06:54:15 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Role_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:54:15 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 06:54:15 --> Grades API - Total count: 14
INFO - 2025-08-19 06:54:15 --> Final output sent to browser
INFO - 2025-08-19 06:54:15 --> Model "Fee_collection_model" initialized
DEBUG - 2025-08-19 06:54:15 --> Total execution time: 0.1022
INFO - 2025-08-19 06:54:15 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:54:15 --> Final output sent to browser
DEBUG - 2025-08-19 06:54:15 --> Total execution time: 0.1128
INFO - 2025-08-19 06:54:15 --> Model "Report_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Role_model" initialized
INFO - 2025-08-19 06:54:15 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:54:15 --> Final output sent to browser
DEBUG - 2025-08-19 06:54:15 --> Total execution time: 0.1188
INFO - 2025-08-19 06:55:58 --> Config Class Initialized
INFO - 2025-08-19 06:55:58 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:55:58 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:55:58 --> Utf8 Class Initialized
INFO - 2025-08-19 06:55:58 --> URI Class Initialized
INFO - 2025-08-19 06:55:58 --> Router Class Initialized
INFO - 2025-08-19 06:55:58 --> Output Class Initialized
INFO - 2025-08-19 06:55:58 --> Config Class Initialized
INFO - 2025-08-19 06:55:58 --> Hooks Class Initialized
INFO - 2025-08-19 06:55:58 --> Security Class Initialized
DEBUG - 2025-08-19 06:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:55:58 --> Input Class Initialized
INFO - 2025-08-19 06:55:58 --> Language Class Initialized
DEBUG - 2025-08-19 06:55:58 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:55:58 --> Utf8 Class Initialized
INFO - 2025-08-19 06:55:58 --> URI Class Initialized
INFO - 2025-08-19 06:55:58 --> Router Class Initialized
INFO - 2025-08-19 06:55:58 --> Output Class Initialized
INFO - 2025-08-19 06:55:58 --> Security Class Initialized
INFO - 2025-08-19 06:55:58 --> Loader Class Initialized
DEBUG - 2025-08-19 06:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:55:58 --> Helper loaded: url_helper
INFO - 2025-08-19 06:55:58 --> Input Class Initialized
INFO - 2025-08-19 06:55:58 --> Helper loaded: security_helper
INFO - 2025-08-19 06:55:58 --> Language Class Initialized
INFO - 2025-08-19 06:55:58 --> Helper loaded: string_helper
INFO - 2025-08-19 06:55:58 --> Loader Class Initialized
INFO - 2025-08-19 06:55:58 --> Database Driver Class Initialized
INFO - 2025-08-19 06:55:58 --> Helper loaded: url_helper
INFO - 2025-08-19 06:55:59 --> Helper loaded: security_helper
INFO - 2025-08-19 06:55:59 --> Helper loaded: string_helper
DEBUG - 2025-08-19 06:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:55:59 --> Helper loaded: form_helper
INFO - 2025-08-19 06:55:59 --> Form Validation Class Initialized
INFO - 2025-08-19 06:55:59 --> Controller Class Initialized
INFO - 2025-08-19 06:55:59 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:55:59 --> Database Driver Class Initialized
INFO - 2025-08-19 06:55:59 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Division_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Student_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Fee_category_model" initialized
DEBUG - 2025-08-19 06:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:55:59 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:55:59 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Report_model" initialized
INFO - 2025-08-19 06:55:59 --> Helper loaded: form_helper
INFO - 2025-08-19 06:55:59 --> Model "Role_model" initialized
INFO - 2025-08-19 06:55:59 --> Form Validation Class Initialized
INFO - 2025-08-19 06:55:59 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:55:59 --> Controller Class Initialized
INFO - 2025-08-19 06:55:59 --> Final output sent to browser
DEBUG - 2025-08-19 06:55:59 --> Total execution time: 0.1088
INFO - 2025-08-19 06:55:59 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Division_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Student_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Report_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Role_model" initialized
INFO - 2025-08-19 06:55:59 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:55:59 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
DEBUG - 2025-08-19 06:55:59 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 06:55:59 --> Grades API - Total count: 14
INFO - 2025-08-19 06:55:59 --> Final output sent to browser
DEBUG - 2025-08-19 06:55:59 --> Total execution time: 0.1527
INFO - 2025-08-19 06:56:41 --> Config Class Initialized
INFO - 2025-08-19 06:56:41 --> Config Class Initialized
INFO - 2025-08-19 06:56:41 --> Hooks Class Initialized
INFO - 2025-08-19 06:56:41 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:56:41 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 06:56:41 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:56:41 --> Utf8 Class Initialized
INFO - 2025-08-19 06:56:41 --> Utf8 Class Initialized
INFO - 2025-08-19 06:56:41 --> URI Class Initialized
INFO - 2025-08-19 06:56:41 --> URI Class Initialized
INFO - 2025-08-19 06:56:41 --> Router Class Initialized
INFO - 2025-08-19 06:56:41 --> Router Class Initialized
INFO - 2025-08-19 06:56:41 --> Output Class Initialized
INFO - 2025-08-19 06:56:41 --> Output Class Initialized
INFO - 2025-08-19 06:56:41 --> Security Class Initialized
INFO - 2025-08-19 06:56:41 --> Security Class Initialized
DEBUG - 2025-08-19 06:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 06:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:56:41 --> Input Class Initialized
INFO - 2025-08-19 06:56:41 --> Input Class Initialized
INFO - 2025-08-19 06:56:41 --> Language Class Initialized
INFO - 2025-08-19 06:56:41 --> Language Class Initialized
INFO - 2025-08-19 06:56:41 --> Loader Class Initialized
INFO - 2025-08-19 06:56:41 --> Loader Class Initialized
INFO - 2025-08-19 06:56:41 --> Helper loaded: url_helper
INFO - 2025-08-19 06:56:41 --> Helper loaded: url_helper
INFO - 2025-08-19 06:56:41 --> Helper loaded: security_helper
INFO - 2025-08-19 06:56:41 --> Helper loaded: security_helper
INFO - 2025-08-19 06:56:41 --> Helper loaded: string_helper
INFO - 2025-08-19 06:56:41 --> Helper loaded: string_helper
INFO - 2025-08-19 06:56:41 --> Database Driver Class Initialized
INFO - 2025-08-19 06:56:41 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:56:41 --> Helper loaded: form_helper
INFO - 2025-08-19 06:56:41 --> Form Validation Class Initialized
INFO - 2025-08-19 06:56:41 --> Controller Class Initialized
INFO - 2025-08-19 06:56:41 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Division_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Student_model" initialized
DEBUG - 2025-08-19 06:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:56:41 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:56:41 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:56:41 --> Helper loaded: form_helper
INFO - 2025-08-19 06:56:41 --> Form Validation Class Initialized
INFO - 2025-08-19 06:56:41 --> Controller Class Initialized
INFO - 2025-08-19 06:56:41 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Report_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Role_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Division_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:56:41 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 06:56:41 --> Model "Student_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Fee_category_model" initialized
DEBUG - 2025-08-19 06:56:41 --> Grades API - Got grades: 14
INFO - 2025-08-19 06:56:41 --> Model "Fee_structure_model" initialized
DEBUG - 2025-08-19 06:56:41 --> Grades API - Total count: 14
INFO - 2025-08-19 06:56:41 --> Final output sent to browser
DEBUG - 2025-08-19 06:56:41 --> Total execution time: 0.1058
INFO - 2025-08-19 06:56:41 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Report_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Role_model" initialized
INFO - 2025-08-19 06:56:41 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:56:41 --> Final output sent to browser
DEBUG - 2025-08-19 06:56:41 --> Total execution time: 0.1222
INFO - 2025-08-19 06:57:00 --> Config Class Initialized
INFO - 2025-08-19 06:57:00 --> Config Class Initialized
INFO - 2025-08-19 06:57:00 --> Hooks Class Initialized
INFO - 2025-08-19 06:57:00 --> Hooks Class Initialized
DEBUG - 2025-08-19 06:57:00 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 06:57:00 --> UTF-8 Support Enabled
INFO - 2025-08-19 06:57:00 --> Utf8 Class Initialized
INFO - 2025-08-19 06:57:00 --> Utf8 Class Initialized
INFO - 2025-08-19 06:57:00 --> URI Class Initialized
INFO - 2025-08-19 06:57:00 --> URI Class Initialized
INFO - 2025-08-19 06:57:00 --> Router Class Initialized
INFO - 2025-08-19 06:57:00 --> Router Class Initialized
INFO - 2025-08-19 06:57:00 --> Output Class Initialized
INFO - 2025-08-19 06:57:00 --> Output Class Initialized
INFO - 2025-08-19 06:57:00 --> Security Class Initialized
INFO - 2025-08-19 06:57:00 --> Security Class Initialized
DEBUG - 2025-08-19 06:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 06:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 06:57:00 --> Input Class Initialized
INFO - 2025-08-19 06:57:00 --> Input Class Initialized
INFO - 2025-08-19 06:57:00 --> Language Class Initialized
INFO - 2025-08-19 06:57:00 --> Language Class Initialized
INFO - 2025-08-19 06:57:00 --> Loader Class Initialized
INFO - 2025-08-19 06:57:00 --> Helper loaded: url_helper
INFO - 2025-08-19 06:57:00 --> Loader Class Initialized
INFO - 2025-08-19 06:57:00 --> Helper loaded: security_helper
INFO - 2025-08-19 06:57:00 --> Helper loaded: string_helper
INFO - 2025-08-19 06:57:00 --> Helper loaded: url_helper
INFO - 2025-08-19 06:57:00 --> Helper loaded: security_helper
INFO - 2025-08-19 06:57:00 --> Helper loaded: string_helper
INFO - 2025-08-19 06:57:00 --> Database Driver Class Initialized
INFO - 2025-08-19 06:57:00 --> Database Driver Class Initialized
DEBUG - 2025-08-19 06:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:57:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 06:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 06:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 06:57:00 --> Helper loaded: form_helper
INFO - 2025-08-19 06:57:00 --> Form Validation Class Initialized
INFO - 2025-08-19 06:57:00 --> Controller Class Initialized
INFO - 2025-08-19 06:57:00 --> Helper loaded: form_helper
INFO - 2025-08-19 06:57:00 --> Form Validation Class Initialized
INFO - 2025-08-19 06:57:00 --> Controller Class Initialized
INFO - 2025-08-19 06:57:00 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Auth_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Division_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Grade_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Student_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Division_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Student_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Parent_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Staff_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Fee_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Announcement_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Report_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Complaint_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Role_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Report_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Role_model" initialized
INFO - 2025-08-19 06:57:00 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 06:57:00 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 06:57:00 --> Final output sent to browser
DEBUG - 2025-08-19 06:57:00 --> Total execution time: 0.0992
DEBUG - 2025-08-19 06:57:00 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 06:57:00 --> Grades API - Total count: 14
INFO - 2025-08-19 06:57:00 --> Final output sent to browser
DEBUG - 2025-08-19 06:57:00 --> Total execution time: 0.1015
INFO - 2025-08-19 07:02:27 --> Config Class Initialized
INFO - 2025-08-19 07:02:27 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:02:27 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:27 --> Utf8 Class Initialized
INFO - 2025-08-19 07:02:27 --> URI Class Initialized
INFO - 2025-08-19 07:02:27 --> Router Class Initialized
INFO - 2025-08-19 07:02:27 --> Output Class Initialized
INFO - 2025-08-19 07:02:27 --> Security Class Initialized
DEBUG - 2025-08-19 07:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:27 --> Input Class Initialized
INFO - 2025-08-19 07:02:27 --> Language Class Initialized
INFO - 2025-08-19 07:02:27 --> Loader Class Initialized
INFO - 2025-08-19 07:02:28 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:28 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:28 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:28 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:28 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:28 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:28 --> Controller Class Initialized
INFO - 2025-08-19 07:02:28 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:28 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:02:28 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 07:02:28 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 07:02:28 --> Grades API - Total count: 14
INFO - 2025-08-19 07:02:28 --> Final output sent to browser
DEBUG - 2025-08-19 07:02:28 --> Total execution time: 0.1341
INFO - 2025-08-19 07:02:29 --> Config Class Initialized
INFO - 2025-08-19 07:02:29 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:02:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:29 --> Utf8 Class Initialized
INFO - 2025-08-19 07:02:29 --> URI Class Initialized
INFO - 2025-08-19 07:02:29 --> Router Class Initialized
INFO - 2025-08-19 07:02:29 --> Output Class Initialized
INFO - 2025-08-19 07:02:29 --> Security Class Initialized
DEBUG - 2025-08-19 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:29 --> Input Class Initialized
INFO - 2025-08-19 07:02:29 --> Language Class Initialized
INFO - 2025-08-19 07:02:29 --> Loader Class Initialized
INFO - 2025-08-19 07:02:29 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:29 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:29 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:29 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:29 --> Controller Class Initialized
INFO - 2025-08-19 07:02:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:29 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:02:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:02:29 --> Total execution time: 0.1005
INFO - 2025-08-19 07:02:32 --> Config Class Initialized
INFO - 2025-08-19 07:02:32 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:02:32 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:32 --> Utf8 Class Initialized
INFO - 2025-08-19 07:02:32 --> URI Class Initialized
INFO - 2025-08-19 07:02:32 --> Config Class Initialized
INFO - 2025-08-19 07:02:32 --> Hooks Class Initialized
INFO - 2025-08-19 07:02:32 --> Config Class Initialized
INFO - 2025-08-19 07:02:32 --> Hooks Class Initialized
INFO - 2025-08-19 07:02:32 --> Router Class Initialized
INFO - 2025-08-19 07:02:32 --> Output Class Initialized
DEBUG - 2025-08-19 07:02:32 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:32 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:02:32 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:32 --> Utf8 Class Initialized
INFO - 2025-08-19 07:02:32 --> Security Class Initialized
INFO - 2025-08-19 07:02:32 --> URI Class Initialized
INFO - 2025-08-19 07:02:32 --> URI Class Initialized
DEBUG - 2025-08-19 07:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:32 --> Input Class Initialized
INFO - 2025-08-19 07:02:32 --> Router Class Initialized
INFO - 2025-08-19 07:02:32 --> Language Class Initialized
INFO - 2025-08-19 07:02:32 --> Router Class Initialized
INFO - 2025-08-19 07:02:32 --> Output Class Initialized
INFO - 2025-08-19 07:02:32 --> Output Class Initialized
INFO - 2025-08-19 07:02:32 --> Security Class Initialized
INFO - 2025-08-19 07:02:32 --> Security Class Initialized
DEBUG - 2025-08-19 07:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:32 --> Input Class Initialized
DEBUG - 2025-08-19 07:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:32 --> Language Class Initialized
INFO - 2025-08-19 07:02:32 --> Input Class Initialized
INFO - 2025-08-19 07:02:32 --> Language Class Initialized
INFO - 2025-08-19 07:02:32 --> Loader Class Initialized
INFO - 2025-08-19 07:02:32 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:32 --> Loader Class Initialized
INFO - 2025-08-19 07:02:32 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:32 --> Loader Class Initialized
INFO - 2025-08-19 07:02:32 --> Database Driver Class Initialized
INFO - 2025-08-19 07:02:32 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:32 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:32 --> Database Driver Class Initialized
INFO - 2025-08-19 07:02:32 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:32 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:32 --> Controller Class Initialized
DEBUG - 2025-08-19 07:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:32 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:32 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:32 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:32 --> Model "Grade_model" initialized
DEBUG - 2025-08-19 07:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:02:32 --> Controller Class Initialized
INFO - 2025-08-19 07:02:32 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:32 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:32 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:32 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:32 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:32 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:32 --> Controller Class Initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:32 --> Final output sent to browser
INFO - 2025-08-19 07:02:32 --> Model "Complaint_model" initialized
DEBUG - 2025-08-19 07:02:32 --> Total execution time: 0.0872
INFO - 2025-08-19 07:02:32 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:02:32 --> Final output sent to browser
DEBUG - 2025-08-19 07:02:32 --> Total execution time: 0.0940
INFO - 2025-08-19 07:02:32 --> Final output sent to browser
DEBUG - 2025-08-19 07:02:32 --> Total execution time: 0.0974
INFO - 2025-08-19 07:02:32 --> Config Class Initialized
INFO - 2025-08-19 07:02:32 --> Config Class Initialized
INFO - 2025-08-19 07:02:32 --> Hooks Class Initialized
INFO - 2025-08-19 07:02:32 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:02:32 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:32 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:02:32 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:32 --> Utf8 Class Initialized
INFO - 2025-08-19 07:02:32 --> URI Class Initialized
INFO - 2025-08-19 07:02:32 --> URI Class Initialized
INFO - 2025-08-19 07:02:32 --> Router Class Initialized
INFO - 2025-08-19 07:02:32 --> Router Class Initialized
INFO - 2025-08-19 07:02:32 --> Output Class Initialized
INFO - 2025-08-19 07:02:32 --> Output Class Initialized
INFO - 2025-08-19 07:02:32 --> Security Class Initialized
INFO - 2025-08-19 07:02:32 --> Security Class Initialized
DEBUG - 2025-08-19 07:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:32 --> Input Class Initialized
DEBUG - 2025-08-19 07:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:32 --> Input Class Initialized
INFO - 2025-08-19 07:02:32 --> Language Class Initialized
INFO - 2025-08-19 07:02:32 --> Language Class Initialized
INFO - 2025-08-19 07:02:32 --> Loader Class Initialized
INFO - 2025-08-19 07:02:32 --> Loader Class Initialized
INFO - 2025-08-19 07:02:32 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:32 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:32 --> Database Driver Class Initialized
INFO - 2025-08-19 07:02:32 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 07:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:32 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:32 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:32 --> Controller Class Initialized
INFO - 2025-08-19 07:02:32 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:32 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:32 --> Controller Class Initialized
INFO - 2025-08-19 07:02:32 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:32 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:02:32 --> Final output sent to browser
DEBUG - 2025-08-19 07:02:32 --> Total execution time: 0.1750
INFO - 2025-08-19 07:02:32 --> Final output sent to browser
DEBUG - 2025-08-19 07:02:32 --> Total execution time: 0.1765
INFO - 2025-08-19 07:02:42 --> Config Class Initialized
INFO - 2025-08-19 07:02:42 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:02:42 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:42 --> Utf8 Class Initialized
INFO - 2025-08-19 07:02:42 --> URI Class Initialized
INFO - 2025-08-19 07:02:42 --> Router Class Initialized
INFO - 2025-08-19 07:02:42 --> Output Class Initialized
INFO - 2025-08-19 07:02:42 --> Security Class Initialized
DEBUG - 2025-08-19 07:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:42 --> Input Class Initialized
INFO - 2025-08-19 07:02:42 --> Language Class Initialized
INFO - 2025-08-19 07:02:42 --> Loader Class Initialized
INFO - 2025-08-19 07:02:42 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:42 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:42 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:42 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:42 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:42 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:42 --> Controller Class Initialized
INFO - 2025-08-19 07:02:42 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:42 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:02:42 --> Final output sent to browser
DEBUG - 2025-08-19 07:02:42 --> Total execution time: 0.1079
INFO - 2025-08-19 07:02:44 --> Config Class Initialized
INFO - 2025-08-19 07:02:44 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:02:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:02:44 --> Utf8 Class Initialized
INFO - 2025-08-19 07:02:44 --> URI Class Initialized
INFO - 2025-08-19 07:02:44 --> Router Class Initialized
INFO - 2025-08-19 07:02:44 --> Output Class Initialized
INFO - 2025-08-19 07:02:44 --> Security Class Initialized
DEBUG - 2025-08-19 07:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:02:44 --> Input Class Initialized
INFO - 2025-08-19 07:02:44 --> Language Class Initialized
INFO - 2025-08-19 07:02:44 --> Loader Class Initialized
INFO - 2025-08-19 07:02:44 --> Helper loaded: url_helper
INFO - 2025-08-19 07:02:44 --> Helper loaded: security_helper
INFO - 2025-08-19 07:02:44 --> Helper loaded: string_helper
INFO - 2025-08-19 07:02:44 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:02:44 --> Helper loaded: form_helper
INFO - 2025-08-19 07:02:44 --> Form Validation Class Initialized
INFO - 2025-08-19 07:02:44 --> Controller Class Initialized
INFO - 2025-08-19 07:02:44 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Division_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Student_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Report_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Role_model" initialized
INFO - 2025-08-19 07:02:44 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:02:44 --> Semester fees request - grade_id: 1, division_id: 1, academic_year_id: 1
INFO - 2025-08-19 07:02:44 --> Final output sent to browser
DEBUG - 2025-08-19 07:02:44 --> Total execution time: 0.1199
INFO - 2025-08-19 07:03:28 --> Config Class Initialized
INFO - 2025-08-19 07:03:28 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:03:28 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:28 --> Utf8 Class Initialized
INFO - 2025-08-19 07:03:28 --> URI Class Initialized
INFO - 2025-08-19 07:03:28 --> Router Class Initialized
INFO - 2025-08-19 07:03:28 --> Output Class Initialized
INFO - 2025-08-19 07:03:28 --> Security Class Initialized
DEBUG - 2025-08-19 07:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:28 --> Input Class Initialized
INFO - 2025-08-19 07:03:28 --> Language Class Initialized
INFO - 2025-08-19 07:03:28 --> Loader Class Initialized
INFO - 2025-08-19 07:03:28 --> Helper loaded: url_helper
INFO - 2025-08-19 07:03:28 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:28 --> Helper loaded: string_helper
INFO - 2025-08-19 07:03:28 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:03:28 --> Helper loaded: form_helper
INFO - 2025-08-19 07:03:28 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:28 --> Controller Class Initialized
INFO - 2025-08-19 07:03:28 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:28 --> Final output sent to browser
DEBUG - 2025-08-19 07:03:28 --> Total execution time: 0.1241
INFO - 2025-08-19 07:03:28 --> Config Class Initialized
INFO - 2025-08-19 07:03:28 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:03:28 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:28 --> Utf8 Class Initialized
INFO - 2025-08-19 07:03:28 --> URI Class Initialized
INFO - 2025-08-19 07:03:28 --> Router Class Initialized
INFO - 2025-08-19 07:03:28 --> Output Class Initialized
INFO - 2025-08-19 07:03:28 --> Security Class Initialized
DEBUG - 2025-08-19 07:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:28 --> Input Class Initialized
INFO - 2025-08-19 07:03:28 --> Language Class Initialized
INFO - 2025-08-19 07:03:28 --> Loader Class Initialized
INFO - 2025-08-19 07:03:28 --> Helper loaded: url_helper
INFO - 2025-08-19 07:03:28 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:28 --> Helper loaded: string_helper
INFO - 2025-08-19 07:03:28 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:03:28 --> Helper loaded: form_helper
INFO - 2025-08-19 07:03:28 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:28 --> Controller Class Initialized
INFO - 2025-08-19 07:03:28 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:28 --> Final output sent to browser
DEBUG - 2025-08-19 07:03:28 --> Total execution time: 0.0654
INFO - 2025-08-19 07:03:29 --> Config Class Initialized
INFO - 2025-08-19 07:03:29 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:03:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:29 --> Utf8 Class Initialized
INFO - 2025-08-19 07:03:29 --> URI Class Initialized
INFO - 2025-08-19 07:03:29 --> Router Class Initialized
INFO - 2025-08-19 07:03:29 --> Output Class Initialized
INFO - 2025-08-19 07:03:29 --> Security Class Initialized
INFO - 2025-08-19 07:03:29 --> Config Class Initialized
DEBUG - 2025-08-19 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:29 --> Input Class Initialized
INFO - 2025-08-19 07:03:29 --> Language Class Initialized
INFO - 2025-08-19 07:03:29 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:03:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:29 --> Utf8 Class Initialized
INFO - 2025-08-19 07:03:29 --> URI Class Initialized
INFO - 2025-08-19 07:03:29 --> Router Class Initialized
INFO - 2025-08-19 07:03:29 --> Output Class Initialized
INFO - 2025-08-19 07:03:29 --> Loader Class Initialized
INFO - 2025-08-19 07:03:29 --> Security Class Initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: url_helper
DEBUG - 2025-08-19 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:29 --> Input Class Initialized
INFO - 2025-08-19 07:03:29 --> Language Class Initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: string_helper
INFO - 2025-08-19 07:03:29 --> Loader Class Initialized
INFO - 2025-08-19 07:03:29 --> Database Driver Class Initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: url_helper
INFO - 2025-08-19 07:03:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:29 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:03:29 --> Database Driver Class Initialized
INFO - 2025-08-19 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:03:29 --> Config Class Initialized
INFO - 2025-08-19 07:03:29 --> Hooks Class Initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: form_helper
DEBUG - 2025-08-19 07:03:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:29 --> Controller Class Initialized
INFO - 2025-08-19 07:03:29 --> Utf8 Class Initialized
INFO - 2025-08-19 07:03:29 --> URI Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:29 --> Router Class Initialized
INFO - 2025-08-19 07:03:29 --> Output Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Division_model" initialized
INFO - 2025-08-19 07:03:29 --> Security Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Student_model" initialized
DEBUG - 2025-08-19 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:29 --> Input Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:03:29 --> Language Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_model" initialized
DEBUG - 2025-08-19 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:03:29 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:03:29 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: form_helper
INFO - 2025-08-19 07:03:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Report_model" initialized
INFO - 2025-08-19 07:03:29 --> Controller Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Role_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:03:29 --> Total execution time: 0.1102
INFO - 2025-08-19 07:03:29 --> Loader Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Division_model" initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: url_helper
INFO - 2025-08-19 07:03:29 --> Model "Student_model" initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:29 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: string_helper
INFO - 2025-08-19 07:03:29 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:03:29 --> Database Driver Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Report_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Role_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:03:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 07:03:29 --> Total execution time: 0.1215
INFO - 2025-08-19 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:03:29 --> Helper loaded: form_helper
INFO - 2025-08-19 07:03:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:29 --> Controller Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Division_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Student_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Report_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Role_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:03:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:03:29 --> Total execution time: 0.1679
INFO - 2025-08-19 07:03:29 --> Config Class Initialized
INFO - 2025-08-19 07:03:29 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:03:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:29 --> Utf8 Class Initialized
INFO - 2025-08-19 07:03:29 --> URI Class Initialized
INFO - 2025-08-19 07:03:29 --> Router Class Initialized
INFO - 2025-08-19 07:03:29 --> Output Class Initialized
INFO - 2025-08-19 07:03:29 --> Security Class Initialized
DEBUG - 2025-08-19 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:29 --> Input Class Initialized
INFO - 2025-08-19 07:03:29 --> Language Class Initialized
INFO - 2025-08-19 07:03:29 --> Loader Class Initialized
INFO - 2025-08-19 07:03:29 --> Helper loaded: url_helper
INFO - 2025-08-19 07:03:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:29 --> Helper loaded: string_helper
INFO - 2025-08-19 07:03:29 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:03:29 --> Helper loaded: form_helper
INFO - 2025-08-19 07:03:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:29 --> Controller Class Initialized
INFO - 2025-08-19 07:03:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Division_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Student_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Report_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Role_model" initialized
INFO - 2025-08-19 07:03:29 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:03:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:03:29 --> Total execution time: 0.1013
INFO - 2025-08-19 07:03:42 --> Config Class Initialized
INFO - 2025-08-19 07:03:42 --> Hooks Class Initialized
INFO - 2025-08-19 07:03:42 --> Config Class Initialized
INFO - 2025-08-19 07:03:42 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:03:42 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:42 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:03:42 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:42 --> Utf8 Class Initialized
INFO - 2025-08-19 07:03:42 --> URI Class Initialized
INFO - 2025-08-19 07:03:42 --> URI Class Initialized
INFO - 2025-08-19 07:03:42 --> Router Class Initialized
INFO - 2025-08-19 07:03:42 --> Router Class Initialized
INFO - 2025-08-19 07:03:42 --> Output Class Initialized
INFO - 2025-08-19 07:03:42 --> Output Class Initialized
INFO - 2025-08-19 07:03:42 --> Security Class Initialized
INFO - 2025-08-19 07:03:42 --> Security Class Initialized
DEBUG - 2025-08-19 07:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:42 --> Input Class Initialized
DEBUG - 2025-08-19 07:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:42 --> Input Class Initialized
INFO - 2025-08-19 07:03:42 --> Language Class Initialized
INFO - 2025-08-19 07:03:42 --> Language Class Initialized
INFO - 2025-08-19 07:03:42 --> Config Class Initialized
INFO - 2025-08-19 07:03:42 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:03:42 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:03:42 --> Utf8 Class Initialized
INFO - 2025-08-19 07:03:42 --> URI Class Initialized
INFO - 2025-08-19 07:03:42 --> Router Class Initialized
INFO - 2025-08-19 07:03:42 --> Output Class Initialized
INFO - 2025-08-19 07:03:42 --> Security Class Initialized
DEBUG - 2025-08-19 07:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:03:42 --> Input Class Initialized
INFO - 2025-08-19 07:03:42 --> Language Class Initialized
INFO - 2025-08-19 07:03:42 --> Loader Class Initialized
INFO - 2025-08-19 07:03:42 --> Helper loaded: url_helper
INFO - 2025-08-19 07:03:42 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:42 --> Loader Class Initialized
INFO - 2025-08-19 07:03:42 --> Helper loaded: string_helper
INFO - 2025-08-19 07:03:42 --> Loader Class Initialized
INFO - 2025-08-19 07:03:42 --> Helper loaded: url_helper
INFO - 2025-08-19 07:03:42 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:42 --> Helper loaded: url_helper
INFO - 2025-08-19 07:03:42 --> Helper loaded: string_helper
INFO - 2025-08-19 07:03:42 --> Helper loaded: security_helper
INFO - 2025-08-19 07:03:42 --> Helper loaded: string_helper
INFO - 2025-08-19 07:03:42 --> Database Driver Class Initialized
INFO - 2025-08-19 07:03:42 --> Database Driver Class Initialized
INFO - 2025-08-19 07:03:42 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:03:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:03:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 07:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:03:42 --> Helper loaded: form_helper
INFO - 2025-08-19 07:03:42 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:42 --> Controller Class Initialized
INFO - 2025-08-19 07:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:03:42 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:42 --> Helper loaded: form_helper
INFO - 2025-08-19 07:03:42 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:42 --> Controller Class Initialized
INFO - 2025-08-19 07:03:42 --> Helper loaded: form_helper
INFO - 2025-08-19 07:03:42 --> Form Validation Class Initialized
INFO - 2025-08-19 07:03:42 --> Controller Class Initialized
INFO - 2025-08-19 07:03:42 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Division_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Student_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Division_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Student_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Division_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Report_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Role_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Student_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:03:42 --> Final output sent to browser
INFO - 2025-08-19 07:03:42 --> Model "Fee_collection_model" initialized
DEBUG - 2025-08-19 07:03:42 --> Total execution time: 0.1096
INFO - 2025-08-19 07:03:42 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Report_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Role_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Report_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Role_model" initialized
INFO - 2025-08-19 07:03:42 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:03:42 --> Final output sent to browser
DEBUG - 2025-08-19 07:03:42 --> Total execution time: 0.1082
INFO - 2025-08-19 07:03:42 --> Final output sent to browser
DEBUG - 2025-08-19 07:03:42 --> Total execution time: 0.1284
INFO - 2025-08-19 07:04:47 --> Config Class Initialized
INFO - 2025-08-19 07:04:47 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:04:47 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:04:47 --> Utf8 Class Initialized
INFO - 2025-08-19 07:04:47 --> URI Class Initialized
INFO - 2025-08-19 07:04:47 --> Router Class Initialized
INFO - 2025-08-19 07:04:47 --> Output Class Initialized
INFO - 2025-08-19 07:04:47 --> Security Class Initialized
INFO - 2025-08-19 07:04:47 --> Config Class Initialized
DEBUG - 2025-08-19 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:04:47 --> Hooks Class Initialized
INFO - 2025-08-19 07:04:47 --> Input Class Initialized
INFO - 2025-08-19 07:04:47 --> Language Class Initialized
DEBUG - 2025-08-19 07:04:47 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:04:47 --> Utf8 Class Initialized
INFO - 2025-08-19 07:04:47 --> URI Class Initialized
INFO - 2025-08-19 07:04:47 --> Router Class Initialized
INFO - 2025-08-19 07:04:47 --> Output Class Initialized
INFO - 2025-08-19 07:04:47 --> Security Class Initialized
DEBUG - 2025-08-19 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:04:47 --> Input Class Initialized
INFO - 2025-08-19 07:04:47 --> Language Class Initialized
INFO - 2025-08-19 07:04:47 --> Loader Class Initialized
INFO - 2025-08-19 07:04:47 --> Helper loaded: url_helper
INFO - 2025-08-19 07:04:47 --> Helper loaded: security_helper
INFO - 2025-08-19 07:04:47 --> Helper loaded: string_helper
INFO - 2025-08-19 07:04:47 --> Database Driver Class Initialized
INFO - 2025-08-19 07:04:47 --> Config Class Initialized
INFO - 2025-08-19 07:04:47 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:04:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 07:04:47 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:04:47 --> Utf8 Class Initialized
INFO - 2025-08-19 07:04:47 --> Helper loaded: form_helper
INFO - 2025-08-19 07:04:47 --> Form Validation Class Initialized
INFO - 2025-08-19 07:04:47 --> URI Class Initialized
INFO - 2025-08-19 07:04:47 --> Controller Class Initialized
INFO - 2025-08-19 07:04:47 --> Loader Class Initialized
INFO - 2025-08-19 07:04:47 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:04:47 --> Helper loaded: url_helper
INFO - 2025-08-19 07:04:47 --> Helper loaded: security_helper
INFO - 2025-08-19 07:04:47 --> Helper loaded: string_helper
INFO - 2025-08-19 07:04:47 --> Router Class Initialized
INFO - 2025-08-19 07:04:47 --> Output Class Initialized
INFO - 2025-08-19 07:04:47 --> Security Class Initialized
INFO - 2025-08-19 07:04:47 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:04:47 --> Input Class Initialized
INFO - 2025-08-19 07:04:47 --> Language Class Initialized
DEBUG - 2025-08-19 07:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:04:47 --> Helper loaded: form_helper
INFO - 2025-08-19 07:04:47 --> Form Validation Class Initialized
INFO - 2025-08-19 07:04:47 --> Controller Class Initialized
INFO - 2025-08-19 07:04:47 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Division_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Student_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Report_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Role_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:04:47 --> Final output sent to browser
DEBUG - 2025-08-19 07:04:47 --> Total execution time: 0.1841
INFO - 2025-08-19 07:04:47 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Division_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Student_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Report_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Role_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:04:47 --> Loader Class Initialized
INFO - 2025-08-19 07:04:47 --> Helper loaded: url_helper
INFO - 2025-08-19 07:04:47 --> Helper loaded: security_helper
INFO - 2025-08-19 07:04:47 --> Helper loaded: string_helper
INFO - 2025-08-19 07:04:47 --> Database Driver Class Initialized
INFO - 2025-08-19 07:04:47 --> Final output sent to browser
DEBUG - 2025-08-19 07:04:47 --> Total execution time: 0.2150
DEBUG - 2025-08-19 07:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:04:47 --> Helper loaded: form_helper
INFO - 2025-08-19 07:04:47 --> Form Validation Class Initialized
INFO - 2025-08-19 07:04:47 --> Controller Class Initialized
INFO - 2025-08-19 07:04:47 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Division_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Student_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Report_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Role_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:04:47 --> Final output sent to browser
DEBUG - 2025-08-19 07:04:47 --> Total execution time: 0.2805
INFO - 2025-08-19 07:04:47 --> Config Class Initialized
INFO - 2025-08-19 07:04:47 --> Hooks Class Initialized
INFO - 2025-08-19 07:04:47 --> Config Class Initialized
INFO - 2025-08-19 07:04:47 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:04:47 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:04:47 --> Utf8 Class Initialized
INFO - 2025-08-19 07:04:47 --> URI Class Initialized
INFO - 2025-08-19 07:04:47 --> Router Class Initialized
INFO - 2025-08-19 07:04:47 --> Output Class Initialized
INFO - 2025-08-19 07:04:47 --> Security Class Initialized
DEBUG - 2025-08-19 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:04:47 --> Input Class Initialized
INFO - 2025-08-19 07:04:47 --> Language Class Initialized
DEBUG - 2025-08-19 07:04:47 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:04:47 --> Utf8 Class Initialized
INFO - 2025-08-19 07:04:47 --> URI Class Initialized
INFO - 2025-08-19 07:04:47 --> Router Class Initialized
INFO - 2025-08-19 07:04:47 --> Loader Class Initialized
INFO - 2025-08-19 07:04:47 --> Helper loaded: url_helper
INFO - 2025-08-19 07:04:47 --> Output Class Initialized
INFO - 2025-08-19 07:04:47 --> Helper loaded: security_helper
INFO - 2025-08-19 07:04:47 --> Helper loaded: string_helper
INFO - 2025-08-19 07:04:47 --> Security Class Initialized
DEBUG - 2025-08-19 07:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:04:47 --> Input Class Initialized
INFO - 2025-08-19 07:04:47 --> Language Class Initialized
INFO - 2025-08-19 07:04:47 --> Database Driver Class Initialized
INFO - 2025-08-19 07:04:47 --> Loader Class Initialized
INFO - 2025-08-19 07:04:47 --> Helper loaded: url_helper
DEBUG - 2025-08-19 07:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:04:47 --> Helper loaded: security_helper
INFO - 2025-08-19 07:04:47 --> Helper loaded: form_helper
INFO - 2025-08-19 07:04:47 --> Form Validation Class Initialized
INFO - 2025-08-19 07:04:47 --> Controller Class Initialized
INFO - 2025-08-19 07:04:47 --> Helper loaded: string_helper
INFO - 2025-08-19 07:04:47 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:04:47 --> Database Driver Class Initialized
INFO - 2025-08-19 07:04:47 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Division_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Student_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Report_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Role_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:04:47 --> Final output sent to browser
DEBUG - 2025-08-19 07:04:47 --> Total execution time: 0.1056
INFO - 2025-08-19 07:04:47 --> Helper loaded: form_helper
INFO - 2025-08-19 07:04:47 --> Form Validation Class Initialized
INFO - 2025-08-19 07:04:47 --> Controller Class Initialized
INFO - 2025-08-19 07:04:47 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Division_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Student_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Report_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Role_model" initialized
INFO - 2025-08-19 07:04:47 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:04:47 --> Final output sent to browser
DEBUG - 2025-08-19 07:04:47 --> Total execution time: 0.1440
INFO - 2025-08-19 07:05:07 --> Config Class Initialized
INFO - 2025-08-19 07:05:07 --> Config Class Initialized
INFO - 2025-08-19 07:05:07 --> Config Class Initialized
INFO - 2025-08-19 07:05:07 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:07 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:07 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:07 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 07:05:07 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:07 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:07 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:05:07 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:07 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:07 --> URI Class Initialized
INFO - 2025-08-19 07:05:07 --> URI Class Initialized
INFO - 2025-08-19 07:05:07 --> URI Class Initialized
INFO - 2025-08-19 07:05:07 --> Router Class Initialized
INFO - 2025-08-19 07:05:07 --> Router Class Initialized
INFO - 2025-08-19 07:05:07 --> Router Class Initialized
INFO - 2025-08-19 07:05:07 --> Output Class Initialized
INFO - 2025-08-19 07:05:07 --> Output Class Initialized
INFO - 2025-08-19 07:05:07 --> Security Class Initialized
INFO - 2025-08-19 07:05:07 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:07 --> Input Class Initialized
INFO - 2025-08-19 07:05:07 --> Input Class Initialized
INFO - 2025-08-19 07:05:07 --> Language Class Initialized
INFO - 2025-08-19 07:05:07 --> Language Class Initialized
INFO - 2025-08-19 07:05:07 --> Loader Class Initialized
INFO - 2025-08-19 07:05:07 --> Loader Class Initialized
INFO - 2025-08-19 07:05:07 --> Output Class Initialized
INFO - 2025-08-19 07:05:07 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:07 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:07 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:07 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:07 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:07 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:07 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:07 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:07 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:07 --> Input Class Initialized
INFO - 2025-08-19 07:05:07 --> Language Class Initialized
DEBUG - 2025-08-19 07:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 07:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:07 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:07 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:07 --> Controller Class Initialized
INFO - 2025-08-19 07:05:07 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:07 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:07 --> Loader Class Initialized
INFO - 2025-08-19 07:05:07 --> Controller Class Initialized
INFO - 2025-08-19 07:05:07 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:07 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:07 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:07 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:07 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:07 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:07 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:07 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_structure_model" initialized
DEBUG - 2025-08-19 07:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:07 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:07 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:07 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:07 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:07 --> Controller Class Initialized
INFO - 2025-08-19 07:05:07 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:07 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:07 --> Total execution time: 0.1040
INFO - 2025-08-19 07:05:07 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:07 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:07 --> Total execution time: 0.1129
INFO - 2025-08-19 07:05:07 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:07 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:07 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:07 --> Total execution time: 0.1304
INFO - 2025-08-19 07:05:15 --> Config Class Initialized
INFO - 2025-08-19 07:05:15 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:15 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:15 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:15 --> URI Class Initialized
INFO - 2025-08-19 07:05:15 --> Router Class Initialized
INFO - 2025-08-19 07:05:15 --> Output Class Initialized
INFO - 2025-08-19 07:05:15 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:15 --> Input Class Initialized
INFO - 2025-08-19 07:05:15 --> Language Class Initialized
INFO - 2025-08-19 07:05:15 --> Loader Class Initialized
INFO - 2025-08-19 07:05:15 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:15 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:15 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:15 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:15 --> Config Class Initialized
INFO - 2025-08-19 07:05:15 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:15 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:15 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:15 --> URI Class Initialized
INFO - 2025-08-19 07:05:15 --> Router Class Initialized
INFO - 2025-08-19 07:05:15 --> Output Class Initialized
INFO - 2025-08-19 07:05:15 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:15 --> Input Class Initialized
INFO - 2025-08-19 07:05:15 --> Language Class Initialized
DEBUG - 2025-08-19 07:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:15 --> Config Class Initialized
INFO - 2025-08-19 07:05:15 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:15 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:15 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:15 --> Controller Class Initialized
INFO - 2025-08-19 07:05:15 --> Loader Class Initialized
INFO - 2025-08-19 07:05:15 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 07:05:15 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:15 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:15 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:15 --> URI Class Initialized
INFO - 2025-08-19 07:05:15 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:15 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:15 --> Router Class Initialized
INFO - 2025-08-19 07:05:15 --> Output Class Initialized
INFO - 2025-08-19 07:05:15 --> Security Class Initialized
INFO - 2025-08-19 07:05:15 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:15 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:15 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:15 --> Input Class Initialized
INFO - 2025-08-19 07:05:15 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:15 --> Language Class Initialized
INFO - 2025-08-19 07:05:15 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_category_model" initialized
DEBUG - 2025-08-19 07:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:15 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:15 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:15 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:15 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:15 --> Controller Class Initialized
INFO - 2025-08-19 07:05:15 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:15 --> Loader Class Initialized
INFO - 2025-08-19 07:05:15 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:15 --> Final output sent to browser
INFO - 2025-08-19 07:05:15 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:15 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 07:05:15 --> Total execution time: 0.1096
INFO - 2025-08-19 07:05:15 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:15 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:15 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:15 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:15 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:15 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:15 --> Total execution time: 0.1021
DEBUG - 2025-08-19 07:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:15 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:15 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:15 --> Controller Class Initialized
INFO - 2025-08-19 07:05:15 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:15 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:15 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:15 --> Total execution time: 0.1414
INFO - 2025-08-19 07:05:25 --> Config Class Initialized
INFO - 2025-08-19 07:05:25 --> Config Class Initialized
INFO - 2025-08-19 07:05:25 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:25 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 07:05:25 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:25 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:25 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:25 --> URI Class Initialized
INFO - 2025-08-19 07:05:25 --> URI Class Initialized
INFO - 2025-08-19 07:05:25 --> Router Class Initialized
INFO - 2025-08-19 07:05:25 --> Router Class Initialized
INFO - 2025-08-19 07:05:25 --> Output Class Initialized
INFO - 2025-08-19 07:05:25 --> Output Class Initialized
INFO - 2025-08-19 07:05:25 --> Security Class Initialized
INFO - 2025-08-19 07:05:25 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:25 --> Input Class Initialized
INFO - 2025-08-19 07:05:25 --> Input Class Initialized
INFO - 2025-08-19 07:05:25 --> Language Class Initialized
INFO - 2025-08-19 07:05:25 --> Language Class Initialized
INFO - 2025-08-19 07:05:25 --> Config Class Initialized
INFO - 2025-08-19 07:05:25 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:25 --> Loader Class Initialized
INFO - 2025-08-19 07:05:25 --> Loader Class Initialized
INFO - 2025-08-19 07:05:25 --> Helper loaded: url_helper
DEBUG - 2025-08-19 07:05:25 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:25 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:25 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:25 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:25 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:25 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:25 --> URI Class Initialized
INFO - 2025-08-19 07:05:25 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:25 --> Router Class Initialized
INFO - 2025-08-19 07:05:25 --> Output Class Initialized
INFO - 2025-08-19 07:05:25 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:25 --> Security Class Initialized
INFO - 2025-08-19 07:05:25 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:25 --> Input Class Initialized
INFO - 2025-08-19 07:05:25 --> Language Class Initialized
DEBUG - 2025-08-19 07:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 07:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:25 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:25 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:25 --> Controller Class Initialized
INFO - 2025-08-19 07:05:25 --> Loader Class Initialized
INFO - 2025-08-19 07:05:25 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:25 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:25 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:25 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:25 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:25 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:25 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:25 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:25 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:25 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:05:25 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 07:05:25 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:25 --> Controller Class Initialized
DEBUG - 2025-08-19 07:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 07:05:25 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 07:05:25 --> Grades API - Total count: 14
INFO - 2025-08-19 07:05:25 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:25 --> Total execution time: 0.1060
INFO - 2025-08-19 07:05:25 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:25 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:25 --> Controller Class Initialized
INFO - 2025-08-19 07:05:25 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:25 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:25 --> Total execution time: 0.1426
INFO - 2025-08-19 07:05:25 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:25 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:25 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:25 --> Total execution time: 0.1698
INFO - 2025-08-19 07:05:27 --> Config Class Initialized
INFO - 2025-08-19 07:05:27 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:27 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:27 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:27 --> URI Class Initialized
INFO - 2025-08-19 07:05:27 --> Router Class Initialized
INFO - 2025-08-19 07:05:27 --> Output Class Initialized
INFO - 2025-08-19 07:05:27 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:27 --> Input Class Initialized
INFO - 2025-08-19 07:05:27 --> Language Class Initialized
INFO - 2025-08-19 07:05:27 --> Loader Class Initialized
INFO - 2025-08-19 07:05:27 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:27 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:27 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:27 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:27 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:27 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:27 --> Controller Class Initialized
INFO - 2025-08-19 07:05:27 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:27 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:27 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:27 --> Total execution time: 0.1542
INFO - 2025-08-19 07:05:37 --> Config Class Initialized
INFO - 2025-08-19 07:05:37 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:37 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:37 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:37 --> URI Class Initialized
INFO - 2025-08-19 07:05:37 --> Router Class Initialized
INFO - 2025-08-19 07:05:37 --> Output Class Initialized
INFO - 2025-08-19 07:05:37 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:37 --> Input Class Initialized
INFO - 2025-08-19 07:05:37 --> Language Class Initialized
INFO - 2025-08-19 07:05:37 --> Loader Class Initialized
INFO - 2025-08-19 07:05:37 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:37 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:37 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:37 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:37 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:37 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:37 --> Controller Class Initialized
INFO - 2025-08-19 07:05:37 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:37 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:05:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 07:05:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 07:05:38 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:38 --> Total execution time: 0.0994
INFO - 2025-08-19 07:05:38 --> Config Class Initialized
INFO - 2025-08-19 07:05:38 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:38 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:38 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:38 --> Config Class Initialized
INFO - 2025-08-19 07:05:38 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:38 --> URI Class Initialized
DEBUG - 2025-08-19 07:05:38 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:38 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:38 --> URI Class Initialized
INFO - 2025-08-19 07:05:38 --> Router Class Initialized
INFO - 2025-08-19 07:05:38 --> Output Class Initialized
INFO - 2025-08-19 07:05:38 --> Router Class Initialized
INFO - 2025-08-19 07:05:38 --> Security Class Initialized
INFO - 2025-08-19 07:05:38 --> Output Class Initialized
DEBUG - 2025-08-19 07:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:38 --> Input Class Initialized
INFO - 2025-08-19 07:05:38 --> Security Class Initialized
INFO - 2025-08-19 07:05:38 --> Language Class Initialized
DEBUG - 2025-08-19 07:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:38 --> Input Class Initialized
INFO - 2025-08-19 07:05:38 --> Language Class Initialized
INFO - 2025-08-19 07:05:38 --> Config Class Initialized
INFO - 2025-08-19 07:05:38 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:38 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:38 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:38 --> URI Class Initialized
INFO - 2025-08-19 07:05:38 --> Router Class Initialized
INFO - 2025-08-19 07:05:38 --> Output Class Initialized
INFO - 2025-08-19 07:05:38 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:38 --> Input Class Initialized
INFO - 2025-08-19 07:05:38 --> Config Class Initialized
INFO - 2025-08-19 07:05:38 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:38 --> Config Class Initialized
INFO - 2025-08-19 07:05:38 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:38 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:38 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:05:38 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:38 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:38 --> URI Class Initialized
INFO - 2025-08-19 07:05:38 --> URI Class Initialized
INFO - 2025-08-19 07:05:38 --> Loader Class Initialized
INFO - 2025-08-19 07:05:38 --> Router Class Initialized
INFO - 2025-08-19 07:05:38 --> Router Class Initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:38 --> Output Class Initialized
INFO - 2025-08-19 07:05:38 --> Output Class Initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:38 --> Security Class Initialized
INFO - 2025-08-19 07:05:38 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:38 --> Input Class Initialized
INFO - 2025-08-19 07:05:38 --> Input Class Initialized
INFO - 2025-08-19 07:05:38 --> Language Class Initialized
INFO - 2025-08-19 07:05:38 --> Language Class Initialized
INFO - 2025-08-19 07:05:38 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:38 --> Language Class Initialized
INFO - 2025-08-19 07:05:38 --> Loader Class Initialized
INFO - 2025-08-19 07:05:38 --> Loader Class Initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:38 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:38 --> Loader Class Initialized
DEBUG - 2025-08-19 07:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:38 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:38 --> Loader Class Initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:38 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:38 --> Controller Class Initialized
INFO - 2025-08-19 07:05:38 --> Config Class Initialized
INFO - 2025-08-19 07:05:38 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 07:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:38 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:38 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:38 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:38 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:38 --> Controller Class Initialized
INFO - 2025-08-19 07:05:38 --> URI Class Initialized
DEBUG - 2025-08-19 07:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:38 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:38 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:38 --> Controller Class Initialized
INFO - 2025-08-19 07:05:38 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:38 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:38 --> Router Class Initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:38 --> Output Class Initialized
INFO - 2025-08-19 07:05:38 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:38 --> Security Class Initialized
INFO - 2025-08-19 07:05:38 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:38 --> Input Class Initialized
INFO - 2025-08-19 07:05:38 --> Language Class Initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:38 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:38 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:38 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:38 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:38 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_category_model" initialized
DEBUG - 2025-08-19 07:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:38 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:38 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:38 --> Controller Class Initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_model" initialized
DEBUG - 2025-08-19 07:05:38 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 07:05:38 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_structure_model" initialized
DEBUG - 2025-08-19 07:05:38 --> Grades API - Got grades: 14
INFO - 2025-08-19 07:05:38 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:38 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:38 --> Total execution time: 0.2815
INFO - 2025-08-19 07:05:38 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:38 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:38 --> Total execution time: 0.2882
INFO - 2025-08-19 07:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:38 --> Loader Class Initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:38 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:38 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:38 --> Controller Class Initialized
INFO - 2025-08-19 07:05:38 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:38 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:38 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:38 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:38 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:38 --> Controller Class Initialized
INFO - 2025-08-19 07:05:38 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Division_model" initialized
DEBUG - 2025-08-19 07:05:38 --> Grades API - Total count: 14
INFO - 2025-08-19 07:05:38 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:38 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:38 --> Total execution time: 0.3473
INFO - 2025-08-19 07:05:38 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:38 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:38 --> Total execution time: 0.3175
INFO - 2025-08-19 07:05:38 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:38 --> Final output sent to browser
INFO - 2025-08-19 07:05:38 --> Model "Complaint_model" initialized
DEBUG - 2025-08-19 07:05:38 --> Total execution time: 0.4417
INFO - 2025-08-19 07:05:38 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:38 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:38 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:38 --> Total execution time: 0.4530
INFO - 2025-08-19 07:05:42 --> Config Class Initialized
INFO - 2025-08-19 07:05:42 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:42 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:42 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:42 --> URI Class Initialized
INFO - 2025-08-19 07:05:42 --> Router Class Initialized
INFO - 2025-08-19 07:05:42 --> Output Class Initialized
INFO - 2025-08-19 07:05:42 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:42 --> Input Class Initialized
INFO - 2025-08-19 07:05:42 --> Language Class Initialized
INFO - 2025-08-19 07:05:42 --> Loader Class Initialized
INFO - 2025-08-19 07:05:42 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:42 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:42 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:42 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:42 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:42 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:42 --> Controller Class Initialized
INFO - 2025-08-19 07:05:42 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:42 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:42 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:42 --> Total execution time: 0.1199
INFO - 2025-08-19 07:05:44 --> Config Class Initialized
INFO - 2025-08-19 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:44 --> URI Class Initialized
INFO - 2025-08-19 07:05:44 --> Router Class Initialized
INFO - 2025-08-19 07:05:44 --> Output Class Initialized
INFO - 2025-08-19 07:05:44 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:44 --> Input Class Initialized
INFO - 2025-08-19 07:05:44 --> Language Class Initialized
INFO - 2025-08-19 07:05:44 --> Loader Class Initialized
INFO - 2025-08-19 07:05:44 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:44 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:44 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:44 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:44 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:44 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:44 --> Controller Class Initialized
INFO - 2025-08-19 07:05:44 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:44 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 07:05:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 07:05:44 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:44 --> Total execution time: 0.0956
INFO - 2025-08-19 07:05:44 --> Config Class Initialized
INFO - 2025-08-19 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:44 --> URI Class Initialized
INFO - 2025-08-19 07:05:44 --> Router Class Initialized
INFO - 2025-08-19 07:05:44 --> Config Class Initialized
INFO - 2025-08-19 07:05:44 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:44 --> Output Class Initialized
INFO - 2025-08-19 07:05:44 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:44 --> Input Class Initialized
INFO - 2025-08-19 07:05:44 --> Language Class Initialized
DEBUG - 2025-08-19 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:44 --> URI Class Initialized
INFO - 2025-08-19 07:05:44 --> Config Class Initialized
INFO - 2025-08-19 07:05:44 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:44 --> Router Class Initialized
INFO - 2025-08-19 07:05:44 --> Loader Class Initialized
INFO - 2025-08-19 07:05:44 --> Helper loaded: url_helper
DEBUG - 2025-08-19 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:44 --> Output Class Initialized
INFO - 2025-08-19 07:05:44 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:44 --> Config Class Initialized
INFO - 2025-08-19 07:05:44 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:44 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:44 --> Security Class Initialized
INFO - 2025-08-19 07:05:44 --> URI Class Initialized
INFO - 2025-08-19 07:05:44 --> Config Class Initialized
INFO - 2025-08-19 07:05:44 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:44 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:44 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:44 --> URI Class Initialized
INFO - 2025-08-19 07:05:44 --> URI Class Initialized
INFO - 2025-08-19 07:05:44 --> Router Class Initialized
INFO - 2025-08-19 07:05:44 --> Router Class Initialized
INFO - 2025-08-19 07:05:44 --> Output Class Initialized
INFO - 2025-08-19 07:05:44 --> Output Class Initialized
INFO - 2025-08-19 07:05:44 --> Security Class Initialized
INFO - 2025-08-19 07:05:44 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:44 --> Input Class Initialized
INFO - 2025-08-19 07:05:44 --> Input Class Initialized
INFO - 2025-08-19 07:05:44 --> Language Class Initialized
INFO - 2025-08-19 07:05:44 --> Language Class Initialized
DEBUG - 2025-08-19 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:44 --> Router Class Initialized
INFO - 2025-08-19 07:05:44 --> Input Class Initialized
INFO - 2025-08-19 07:05:44 --> Language Class Initialized
INFO - 2025-08-19 07:05:44 --> Config Class Initialized
INFO - 2025-08-19 07:05:44 --> Hooks Class Initialized
INFO - 2025-08-19 07:05:44 --> Output Class Initialized
DEBUG - 2025-08-19 07:05:44 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:44 --> URI Class Initialized
INFO - 2025-08-19 07:05:44 --> Loader Class Initialized
INFO - 2025-08-19 07:05:44 --> Router Class Initialized
INFO - 2025-08-19 07:05:44 --> Output Class Initialized
INFO - 2025-08-19 07:05:44 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:45 --> Security Class Initialized
INFO - 2025-08-19 07:05:45 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:45 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:45 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:45 --> Input Class Initialized
INFO - 2025-08-19 07:05:45 --> Input Class Initialized
INFO - 2025-08-19 07:05:45 --> Language Class Initialized
INFO - 2025-08-19 07:05:45 --> Language Class Initialized
INFO - 2025-08-19 07:05:45 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:45 --> Loader Class Initialized
INFO - 2025-08-19 07:05:45 --> Helper loaded: url_helper
DEBUG - 2025-08-19 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:45 --> Loader Class Initialized
INFO - 2025-08-19 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:45 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:45 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:45 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:45 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:45 --> Controller Class Initialized
DEBUG - 2025-08-19 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:45 --> Loader Class Initialized
INFO - 2025-08-19 07:05:45 --> Loader Class Initialized
INFO - 2025-08-19 07:05:45 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:45 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:45 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:45 --> Helper loaded: form_helper
DEBUG - 2025-08-19 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:45 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:45 --> Controller Class Initialized
INFO - 2025-08-19 07:05:45 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:45 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:45 --> Controller Class Initialized
INFO - 2025-08-19 07:05:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:45 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:45 --> Model "Grade_model" initialized
DEBUG - 2025-08-19 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:45 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:45 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:45 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:45 --> Database Driver Class Initialized
INFO - 2025-08-19 07:05:45 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:45 --> Controller Class Initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:45 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:45 --> Controller Class Initialized
INFO - 2025-08-19 07:05:45 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:45 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:45 --> Total execution time: 0.2125
INFO - 2025-08-19 07:05:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:45 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:45 --> Total execution time: 0.2300
INFO - 2025-08-19 07:05:45 --> Model "Academic_year_model" initialized
DEBUG - 2025-08-19 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:45 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:45 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:45 --> Controller Class Initialized
INFO - 2025-08-19 07:05:45 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:45 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:45 --> Total execution time: 0.2440
INFO - 2025-08-19 07:05:45 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Fee_collection_model" initialized
DEBUG - 2025-08-19 07:05:45 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 07:05:45 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:05:45 --> Grades API - Got grades: 14
INFO - 2025-08-19 07:05:45 --> Model "Complaint_model" initialized
DEBUG - 2025-08-19 07:05:45 --> Grades API - Total count: 14
INFO - 2025-08-19 07:05:45 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:45 --> Total execution time: 0.2294
INFO - 2025-08-19 07:05:45 --> Final output sent to browser
INFO - 2025-08-19 07:05:45 --> Model "Report_model" initialized
DEBUG - 2025-08-19 07:05:45 --> Total execution time: 0.2848
INFO - 2025-08-19 07:05:45 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:45 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:45 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:45 --> Total execution time: 0.2826
INFO - 2025-08-19 07:05:50 --> Config Class Initialized
INFO - 2025-08-19 07:05:50 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:05:50 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:05:50 --> Utf8 Class Initialized
INFO - 2025-08-19 07:05:50 --> URI Class Initialized
INFO - 2025-08-19 07:05:50 --> Router Class Initialized
INFO - 2025-08-19 07:05:50 --> Output Class Initialized
INFO - 2025-08-19 07:05:50 --> Security Class Initialized
DEBUG - 2025-08-19 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:05:50 --> Input Class Initialized
INFO - 2025-08-19 07:05:50 --> Language Class Initialized
INFO - 2025-08-19 07:05:50 --> Loader Class Initialized
INFO - 2025-08-19 07:05:50 --> Helper loaded: url_helper
INFO - 2025-08-19 07:05:50 --> Helper loaded: security_helper
INFO - 2025-08-19 07:05:50 --> Helper loaded: string_helper
INFO - 2025-08-19 07:05:50 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:05:50 --> Helper loaded: form_helper
INFO - 2025-08-19 07:05:50 --> Form Validation Class Initialized
INFO - 2025-08-19 07:05:50 --> Controller Class Initialized
INFO - 2025-08-19 07:05:50 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Division_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Student_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Report_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Role_model" initialized
INFO - 2025-08-19 07:05:50 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:05:50 --> Final output sent to browser
DEBUG - 2025-08-19 07:05:50 --> Total execution time: 0.1362
INFO - 2025-08-19 07:07:38 --> Config Class Initialized
INFO - 2025-08-19 07:07:38 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:07:38 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:07:38 --> Utf8 Class Initialized
INFO - 2025-08-19 07:07:38 --> URI Class Initialized
INFO - 2025-08-19 07:07:38 --> Router Class Initialized
INFO - 2025-08-19 07:07:38 --> Output Class Initialized
INFO - 2025-08-19 07:07:38 --> Security Class Initialized
DEBUG - 2025-08-19 07:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:07:38 --> Input Class Initialized
INFO - 2025-08-19 07:07:38 --> Language Class Initialized
INFO - 2025-08-19 07:07:38 --> Loader Class Initialized
INFO - 2025-08-19 07:07:38 --> Helper loaded: url_helper
INFO - 2025-08-19 07:07:38 --> Helper loaded: security_helper
INFO - 2025-08-19 07:07:38 --> Helper loaded: string_helper
INFO - 2025-08-19 07:07:38 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:07:39 --> Helper loaded: form_helper
INFO - 2025-08-19 07:07:39 --> Form Validation Class Initialized
INFO - 2025-08-19 07:07:39 --> Controller Class Initialized
INFO - 2025-08-19 07:07:39 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Division_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Student_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Report_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Role_model" initialized
INFO - 2025-08-19 07:07:39 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:07:39 --> Final output sent to browser
DEBUG - 2025-08-19 07:07:39 --> Total execution time: 0.1618
INFO - 2025-08-19 07:07:41 --> Config Class Initialized
INFO - 2025-08-19 07:07:41 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:07:41 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:07:41 --> Utf8 Class Initialized
INFO - 2025-08-19 07:07:41 --> URI Class Initialized
INFO - 2025-08-19 07:07:41 --> Router Class Initialized
INFO - 2025-08-19 07:07:41 --> Output Class Initialized
INFO - 2025-08-19 07:07:41 --> Security Class Initialized
DEBUG - 2025-08-19 07:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:07:41 --> Input Class Initialized
INFO - 2025-08-19 07:07:41 --> Language Class Initialized
INFO - 2025-08-19 07:07:41 --> Loader Class Initialized
INFO - 2025-08-19 07:07:41 --> Helper loaded: url_helper
INFO - 2025-08-19 07:07:41 --> Helper loaded: security_helper
INFO - 2025-08-19 07:07:41 --> Helper loaded: string_helper
INFO - 2025-08-19 07:07:41 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:07:41 --> Helper loaded: form_helper
INFO - 2025-08-19 07:07:41 --> Form Validation Class Initialized
INFO - 2025-08-19 07:07:41 --> Controller Class Initialized
INFO - 2025-08-19 07:07:41 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Division_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Student_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Report_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Role_model" initialized
INFO - 2025-08-19 07:07:41 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:07:41 --> Final output sent to browser
DEBUG - 2025-08-19 07:07:41 --> Total execution time: 0.1149
INFO - 2025-08-19 07:07:58 --> Config Class Initialized
INFO - 2025-08-19 07:07:58 --> Hooks Class Initialized
INFO - 2025-08-19 07:07:58 --> Config Class Initialized
INFO - 2025-08-19 07:07:58 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:07:58 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:07:58 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:07:58 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:07:58 --> Utf8 Class Initialized
INFO - 2025-08-19 07:07:58 --> URI Class Initialized
INFO - 2025-08-19 07:07:58 --> URI Class Initialized
INFO - 2025-08-19 07:07:58 --> Router Class Initialized
INFO - 2025-08-19 07:07:58 --> Output Class Initialized
INFO - 2025-08-19 07:07:58 --> Security Class Initialized
DEBUG - 2025-08-19 07:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:07:58 --> Router Class Initialized
INFO - 2025-08-19 07:07:58 --> Input Class Initialized
INFO - 2025-08-19 07:07:58 --> Language Class Initialized
INFO - 2025-08-19 07:07:58 --> Output Class Initialized
INFO - 2025-08-19 07:07:58 --> Security Class Initialized
DEBUG - 2025-08-19 07:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:07:58 --> Input Class Initialized
INFO - 2025-08-19 07:07:58 --> Language Class Initialized
INFO - 2025-08-19 07:07:58 --> Loader Class Initialized
INFO - 2025-08-19 07:07:58 --> Loader Class Initialized
INFO - 2025-08-19 07:07:58 --> Helper loaded: url_helper
INFO - 2025-08-19 07:07:58 --> Helper loaded: security_helper
INFO - 2025-08-19 07:07:58 --> Helper loaded: url_helper
INFO - 2025-08-19 07:07:58 --> Helper loaded: string_helper
INFO - 2025-08-19 07:07:58 --> Helper loaded: security_helper
INFO - 2025-08-19 07:07:58 --> Helper loaded: string_helper
INFO - 2025-08-19 07:07:58 --> Database Driver Class Initialized
INFO - 2025-08-19 07:07:58 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 07:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:07:58 --> Helper loaded: form_helper
INFO - 2025-08-19 07:07:58 --> Helper loaded: form_helper
INFO - 2025-08-19 07:07:58 --> Form Validation Class Initialized
INFO - 2025-08-19 07:07:58 --> Form Validation Class Initialized
INFO - 2025-08-19 07:07:58 --> Controller Class Initialized
INFO - 2025-08-19 07:07:58 --> Controller Class Initialized
INFO - 2025-08-19 07:07:58 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Division_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Division_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Student_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Student_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Report_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Report_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Role_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Role_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:07:58 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:07:58 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
DEBUG - 2025-08-19 07:07:58 --> Grades API - Got grades: 14
INFO - 2025-08-19 07:07:58 --> Final output sent to browser
DEBUG - 2025-08-19 07:07:58 --> Grades API - Total count: 14
DEBUG - 2025-08-19 07:07:58 --> Total execution time: 0.1287
INFO - 2025-08-19 07:07:58 --> Final output sent to browser
DEBUG - 2025-08-19 07:07:58 --> Total execution time: 0.1298
INFO - 2025-08-19 07:08:59 --> Config Class Initialized
INFO - 2025-08-19 07:08:59 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:08:59 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:08:59 --> Utf8 Class Initialized
INFO - 2025-08-19 07:08:59 --> URI Class Initialized
INFO - 2025-08-19 07:08:59 --> Config Class Initialized
INFO - 2025-08-19 07:08:59 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:08:59 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:08:59 --> Utf8 Class Initialized
INFO - 2025-08-19 07:08:59 --> URI Class Initialized
INFO - 2025-08-19 07:08:59 --> Router Class Initialized
INFO - 2025-08-19 07:08:59 --> Router Class Initialized
INFO - 2025-08-19 07:08:59 --> Output Class Initialized
INFO - 2025-08-19 07:08:59 --> Security Class Initialized
DEBUG - 2025-08-19 07:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:08:59 --> Input Class Initialized
INFO - 2025-08-19 07:08:59 --> Language Class Initialized
INFO - 2025-08-19 07:08:59 --> Output Class Initialized
INFO - 2025-08-19 07:08:59 --> Security Class Initialized
DEBUG - 2025-08-19 07:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:08:59 --> Input Class Initialized
INFO - 2025-08-19 07:08:59 --> Loader Class Initialized
INFO - 2025-08-19 07:08:59 --> Language Class Initialized
INFO - 2025-08-19 07:08:59 --> Helper loaded: url_helper
INFO - 2025-08-19 07:08:59 --> Helper loaded: security_helper
INFO - 2025-08-19 07:08:59 --> Helper loaded: string_helper
INFO - 2025-08-19 07:08:59 --> Loader Class Initialized
INFO - 2025-08-19 07:08:59 --> Helper loaded: url_helper
INFO - 2025-08-19 07:08:59 --> Database Driver Class Initialized
INFO - 2025-08-19 07:08:59 --> Helper loaded: security_helper
INFO - 2025-08-19 07:08:59 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:08:59 --> Database Driver Class Initialized
INFO - 2025-08-19 07:08:59 --> Helper loaded: form_helper
INFO - 2025-08-19 07:08:59 --> Form Validation Class Initialized
INFO - 2025-08-19 07:08:59 --> Controller Class Initialized
DEBUG - 2025-08-19 07:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:08:59 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:08:59 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Division_model" initialized
INFO - 2025-08-19 07:08:59 --> Helper loaded: form_helper
INFO - 2025-08-19 07:08:59 --> Form Validation Class Initialized
INFO - 2025-08-19 07:08:59 --> Controller Class Initialized
INFO - 2025-08-19 07:08:59 --> Model "Student_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Division_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Student_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Report_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Role_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:08:59 --> Final output sent to browser
INFO - 2025-08-19 07:08:59 --> Model "Report_model" initialized
DEBUG - 2025-08-19 07:08:59 --> Total execution time: 0.1141
INFO - 2025-08-19 07:08:59 --> Model "Role_model" initialized
INFO - 2025-08-19 07:08:59 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:08:59 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
DEBUG - 2025-08-19 07:08:59 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 07:08:59 --> Grades API - Total count: 14
INFO - 2025-08-19 07:08:59 --> Final output sent to browser
DEBUG - 2025-08-19 07:08:59 --> Total execution time: 0.1322
INFO - 2025-08-19 07:09:11 --> Config Class Initialized
INFO - 2025-08-19 07:09:11 --> Hooks Class Initialized
INFO - 2025-08-19 07:09:11 --> Config Class Initialized
INFO - 2025-08-19 07:09:11 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:09:11 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:09:11 --> Utf8 Class Initialized
INFO - 2025-08-19 07:09:12 --> URI Class Initialized
DEBUG - 2025-08-19 07:09:12 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:09:12 --> Router Class Initialized
INFO - 2025-08-19 07:09:12 --> Utf8 Class Initialized
INFO - 2025-08-19 07:09:12 --> URI Class Initialized
INFO - 2025-08-19 07:09:12 --> Output Class Initialized
INFO - 2025-08-19 07:09:12 --> Router Class Initialized
INFO - 2025-08-19 07:09:12 --> Security Class Initialized
INFO - 2025-08-19 07:09:12 --> Output Class Initialized
DEBUG - 2025-08-19 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:09:12 --> Input Class Initialized
INFO - 2025-08-19 07:09:12 --> Language Class Initialized
INFO - 2025-08-19 07:09:12 --> Security Class Initialized
DEBUG - 2025-08-19 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:09:12 --> Input Class Initialized
INFO - 2025-08-19 07:09:12 --> Language Class Initialized
INFO - 2025-08-19 07:09:12 --> Loader Class Initialized
INFO - 2025-08-19 07:09:12 --> Helper loaded: url_helper
INFO - 2025-08-19 07:09:12 --> Helper loaded: security_helper
INFO - 2025-08-19 07:09:12 --> Loader Class Initialized
INFO - 2025-08-19 07:09:12 --> Helper loaded: url_helper
INFO - 2025-08-19 07:09:12 --> Helper loaded: security_helper
INFO - 2025-08-19 07:09:12 --> Helper loaded: string_helper
INFO - 2025-08-19 07:09:12 --> Helper loaded: string_helper
INFO - 2025-08-19 07:09:12 --> Database Driver Class Initialized
INFO - 2025-08-19 07:09:12 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:09:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 07:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:09:12 --> Helper loaded: form_helper
INFO - 2025-08-19 07:09:12 --> Form Validation Class Initialized
INFO - 2025-08-19 07:09:12 --> Controller Class Initialized
INFO - 2025-08-19 07:09:12 --> Helper loaded: form_helper
INFO - 2025-08-19 07:09:12 --> Form Validation Class Initialized
INFO - 2025-08-19 07:09:12 --> Controller Class Initialized
INFO - 2025-08-19 07:09:12 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Division_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Student_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Division_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Student_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Report_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Role_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Report_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Role_model" initialized
INFO - 2025-08-19 07:09:12 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:09:12 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 07:09:12 --> Final output sent to browser
DEBUG - 2025-08-19 07:09:12 --> Total execution time: 0.1676
DEBUG - 2025-08-19 07:09:12 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 07:09:12 --> Grades API - Total count: 14
INFO - 2025-08-19 07:09:12 --> Final output sent to browser
DEBUG - 2025-08-19 07:09:12 --> Total execution time: 0.1717
INFO - 2025-08-19 07:09:22 --> Config Class Initialized
INFO - 2025-08-19 07:09:22 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:09:22 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:09:22 --> Utf8 Class Initialized
INFO - 2025-08-19 07:09:22 --> URI Class Initialized
INFO - 2025-08-19 07:09:22 --> Router Class Initialized
INFO - 2025-08-19 07:09:22 --> Output Class Initialized
INFO - 2025-08-19 07:09:22 --> Security Class Initialized
DEBUG - 2025-08-19 07:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:09:22 --> Input Class Initialized
INFO - 2025-08-19 07:09:22 --> Language Class Initialized
INFO - 2025-08-19 07:09:22 --> Loader Class Initialized
INFO - 2025-08-19 07:09:22 --> Config Class Initialized
INFO - 2025-08-19 07:09:22 --> Hooks Class Initialized
INFO - 2025-08-19 07:09:22 --> Helper loaded: url_helper
INFO - 2025-08-19 07:09:22 --> Helper loaded: security_helper
INFO - 2025-08-19 07:09:22 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:09:22 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:09:22 --> Utf8 Class Initialized
INFO - 2025-08-19 07:09:22 --> URI Class Initialized
INFO - 2025-08-19 07:09:22 --> Router Class Initialized
INFO - 2025-08-19 07:09:22 --> Database Driver Class Initialized
INFO - 2025-08-19 07:09:22 --> Output Class Initialized
INFO - 2025-08-19 07:09:22 --> Security Class Initialized
DEBUG - 2025-08-19 07:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:09:22 --> Input Class Initialized
INFO - 2025-08-19 07:09:22 --> Language Class Initialized
DEBUG - 2025-08-19 07:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:09:22 --> Helper loaded: form_helper
INFO - 2025-08-19 07:09:22 --> Form Validation Class Initialized
INFO - 2025-08-19 07:09:22 --> Controller Class Initialized
INFO - 2025-08-19 07:09:22 --> Loader Class Initialized
INFO - 2025-08-19 07:09:22 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:09:22 --> Helper loaded: url_helper
INFO - 2025-08-19 07:09:22 --> Helper loaded: security_helper
INFO - 2025-08-19 07:09:22 --> Helper loaded: string_helper
INFO - 2025-08-19 07:09:22 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Division_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Student_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:09:22 --> Database Driver Class Initialized
INFO - 2025-08-19 07:09:22 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Announcement_model" initialized
DEBUG - 2025-08-19 07:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:09:22 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:09:22 --> Model "Report_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Role_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:09:22 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 07:09:22 --> Helper loaded: form_helper
INFO - 2025-08-19 07:09:22 --> Form Validation Class Initialized
INFO - 2025-08-19 07:09:22 --> Controller Class Initialized
INFO - 2025-08-19 07:09:22 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 07:09:22 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 07:09:22 --> Grades API - Total count: 14
INFO - 2025-08-19 07:09:22 --> Final output sent to browser
DEBUG - 2025-08-19 07:09:22 --> Total execution time: 0.1001
INFO - 2025-08-19 07:09:22 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Division_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Student_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Report_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Role_model" initialized
INFO - 2025-08-19 07:09:22 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:09:22 --> Final output sent to browser
DEBUG - 2025-08-19 07:09:22 --> Total execution time: 0.0894
INFO - 2025-08-19 07:09:56 --> Config Class Initialized
INFO - 2025-08-19 07:09:56 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:09:56 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:09:56 --> Utf8 Class Initialized
INFO - 2025-08-19 07:09:56 --> URI Class Initialized
INFO - 2025-08-19 07:09:56 --> Router Class Initialized
INFO - 2025-08-19 07:09:56 --> Output Class Initialized
INFO - 2025-08-19 07:09:56 --> Security Class Initialized
DEBUG - 2025-08-19 07:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:09:56 --> Input Class Initialized
INFO - 2025-08-19 07:09:56 --> Language Class Initialized
INFO - 2025-08-19 07:09:56 --> Loader Class Initialized
INFO - 2025-08-19 07:09:56 --> Helper loaded: url_helper
INFO - 2025-08-19 07:09:56 --> Helper loaded: security_helper
INFO - 2025-08-19 07:09:56 --> Helper loaded: string_helper
INFO - 2025-08-19 07:09:56 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:09:56 --> Helper loaded: form_helper
INFO - 2025-08-19 07:09:56 --> Form Validation Class Initialized
INFO - 2025-08-19 07:09:56 --> Controller Class Initialized
INFO - 2025-08-19 07:09:56 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Division_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Student_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Report_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Role_model" initialized
INFO - 2025-08-19 07:09:56 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:09:56 --> Final output sent to browser
DEBUG - 2025-08-19 07:09:56 --> Total execution time: 0.0856
INFO - 2025-08-19 07:10:19 --> Config Class Initialized
INFO - 2025-08-19 07:10:19 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:19 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:19 --> URI Class Initialized
INFO - 2025-08-19 07:10:19 --> Router Class Initialized
INFO - 2025-08-19 07:10:19 --> Output Class Initialized
INFO - 2025-08-19 07:10:19 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:19 --> Input Class Initialized
INFO - 2025-08-19 07:10:19 --> Language Class Initialized
INFO - 2025-08-19 07:10:19 --> Loader Class Initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:19 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:19 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:19 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:19 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:19 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:19 --> Controller Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:10:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 07:10:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 07:10:19 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:19 --> Total execution time: 0.1078
INFO - 2025-08-19 07:10:19 --> Config Class Initialized
INFO - 2025-08-19 07:10:19 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:19 --> Config Class Initialized
INFO - 2025-08-19 07:10:19 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:19 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:19 --> URI Class Initialized
INFO - 2025-08-19 07:10:19 --> Config Class Initialized
INFO - 2025-08-19 07:10:19 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:19 --> Router Class Initialized
INFO - 2025-08-19 07:10:19 --> Output Class Initialized
INFO - 2025-08-19 07:10:19 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:19 --> Input Class Initialized
INFO - 2025-08-19 07:10:19 --> Language Class Initialized
DEBUG - 2025-08-19 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:19 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:19 --> URI Class Initialized
DEBUG - 2025-08-19 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:19 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:19 --> Router Class Initialized
INFO - 2025-08-19 07:10:19 --> URI Class Initialized
INFO - 2025-08-19 07:10:19 --> Output Class Initialized
INFO - 2025-08-19 07:10:19 --> Router Class Initialized
INFO - 2025-08-19 07:10:19 --> Security Class Initialized
INFO - 2025-08-19 07:10:19 --> Output Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:19 --> Input Class Initialized
INFO - 2025-08-19 07:10:19 --> Config Class Initialized
INFO - 2025-08-19 07:10:19 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:19 --> Security Class Initialized
INFO - 2025-08-19 07:10:19 --> Language Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:19 --> Input Class Initialized
INFO - 2025-08-19 07:10:19 --> Language Class Initialized
INFO - 2025-08-19 07:10:19 --> Loader Class Initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:19 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:19 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:19 --> Loader Class Initialized
INFO - 2025-08-19 07:10:19 --> Loader Class Initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:19 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:19 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:19 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:19 --> Config Class Initialized
INFO - 2025-08-19 07:10:19 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:19 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:19 --> URI Class Initialized
INFO - 2025-08-19 07:10:19 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:19 --> Router Class Initialized
INFO - 2025-08-19 07:10:19 --> Output Class Initialized
INFO - 2025-08-19 07:10:19 --> Config Class Initialized
INFO - 2025-08-19 07:10:19 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:19 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:19 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:19 --> URI Class Initialized
DEBUG - 2025-08-19 07:10:19 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:19 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:19 --> Router Class Initialized
INFO - 2025-08-19 07:10:19 --> URI Class Initialized
INFO - 2025-08-19 07:10:19 --> Output Class Initialized
INFO - 2025-08-19 07:10:19 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:19 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:19 --> Input Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:19 --> Language Class Initialized
INFO - 2025-08-19 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:19 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:19 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:19 --> Controller Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:19 --> Loader Class Initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:19 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:19 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:19 --> Input Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:19 --> Language Class Initialized
DEBUG - 2025-08-19 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:19 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:19 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:19 --> Router Class Initialized
INFO - 2025-08-19 07:10:19 --> Controller Class Initialized
INFO - 2025-08-19 07:10:19 --> Output Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:19 --> Security Class Initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:19 --> Model "Grade_model" initialized
DEBUG - 2025-08-19 07:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:19 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:19 --> Input Class Initialized
INFO - 2025-08-19 07:10:19 --> Language Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:19 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:19 --> Loader Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:19 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:19 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:19 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:19 --> Final output sent to browser
INFO - 2025-08-19 07:10:19 --> Helper loaded: form_helper
DEBUG - 2025-08-19 07:10:19 --> Total execution time: 0.1592
INFO - 2025-08-19 07:10:19 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:19 --> Controller Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:19 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Division_model" initialized
DEBUG - 2025-08-19 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:19 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:19 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:19 --> Controller Class Initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:19 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:19 --> Controller Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:19 --> Final output sent to browser
INFO - 2025-08-19 07:10:19 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:19 --> Total execution time: 0.2054
DEBUG - 2025-08-19 07:10:19 --> Total execution time: 0.1778
INFO - 2025-08-19 07:10:19 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:19 --> Loader Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:19 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:19 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:19 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_collection_model" initialized
DEBUG - 2025-08-19 07:10:19 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 07:10:19 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:19 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:10:19 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 07:10:19 --> Grades API - Total count: 14
INFO - 2025-08-19 07:10:19 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:19 --> Total execution time: 0.1845
INFO - 2025-08-19 07:10:19 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:19 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:19 --> Total execution time: 0.2626
DEBUG - 2025-08-19 07:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:19 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:19 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:19 --> Controller Class Initialized
INFO - 2025-08-19 07:10:19 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:19 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:19 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:19 --> Total execution time: 0.2497
INFO - 2025-08-19 07:10:33 --> Config Class Initialized
INFO - 2025-08-19 07:10:33 --> Config Class Initialized
INFO - 2025-08-19 07:10:33 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:33 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:10:33 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:33 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:10:33 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:33 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:33 --> URI Class Initialized
INFO - 2025-08-19 07:10:33 --> URI Class Initialized
INFO - 2025-08-19 07:10:33 --> Router Class Initialized
INFO - 2025-08-19 07:10:33 --> Router Class Initialized
INFO - 2025-08-19 07:10:33 --> Output Class Initialized
INFO - 2025-08-19 07:10:33 --> Output Class Initialized
INFO - 2025-08-19 07:10:33 --> Security Class Initialized
INFO - 2025-08-19 07:10:33 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:33 --> Input Class Initialized
DEBUG - 2025-08-19 07:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:33 --> Input Class Initialized
INFO - 2025-08-19 07:10:33 --> Language Class Initialized
INFO - 2025-08-19 07:10:33 --> Language Class Initialized
INFO - 2025-08-19 07:10:33 --> Loader Class Initialized
INFO - 2025-08-19 07:10:33 --> Loader Class Initialized
INFO - 2025-08-19 07:10:33 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:33 --> Config Class Initialized
INFO - 2025-08-19 07:10:33 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:33 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:33 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:33 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:33 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:33 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:10:33 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:33 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:33 --> URI Class Initialized
INFO - 2025-08-19 07:10:33 --> Router Class Initialized
INFO - 2025-08-19 07:10:33 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:33 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:33 --> Output Class Initialized
INFO - 2025-08-19 07:10:33 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:33 --> Input Class Initialized
DEBUG - 2025-08-19 07:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:33 --> Language Class Initialized
DEBUG - 2025-08-19 07:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:33 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:33 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:33 --> Controller Class Initialized
INFO - 2025-08-19 07:10:33 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:33 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:33 --> Controller Class Initialized
INFO - 2025-08-19 07:10:33 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:33 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:33 --> Total execution time: 0.0965
INFO - 2025-08-19 07:10:33 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:33 --> Loader Class Initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:33 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:33 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:33 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:33 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:33 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:33 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:33 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:33 --> Total execution time: 0.1136
INFO - 2025-08-19 07:10:33 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:33 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:33 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:33 --> Controller Class Initialized
INFO - 2025-08-19 07:10:33 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:33 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:33 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:33 --> Total execution time: 0.1494
INFO - 2025-08-19 07:10:40 --> Config Class Initialized
INFO - 2025-08-19 07:10:40 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:10:40 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:40 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:40 --> URI Class Initialized
INFO - 2025-08-19 07:10:40 --> Router Class Initialized
INFO - 2025-08-19 07:10:40 --> Output Class Initialized
INFO - 2025-08-19 07:10:40 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:40 --> Input Class Initialized
INFO - 2025-08-19 07:10:40 --> Language Class Initialized
INFO - 2025-08-19 07:10:40 --> Loader Class Initialized
INFO - 2025-08-19 07:10:40 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:40 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:40 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:40 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:40 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:40 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:40 --> Controller Class Initialized
INFO - 2025-08-19 07:10:40 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:40 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:40 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:40 --> Total execution time: 0.1310
INFO - 2025-08-19 07:10:42 --> Config Class Initialized
INFO - 2025-08-19 07:10:42 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:10:42 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:42 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:42 --> URI Class Initialized
INFO - 2025-08-19 07:10:42 --> Router Class Initialized
INFO - 2025-08-19 07:10:42 --> Output Class Initialized
INFO - 2025-08-19 07:10:42 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:42 --> Input Class Initialized
INFO - 2025-08-19 07:10:42 --> Language Class Initialized
INFO - 2025-08-19 07:10:42 --> Loader Class Initialized
INFO - 2025-08-19 07:10:42 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:42 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:42 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:42 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:42 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:42 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:42 --> Controller Class Initialized
INFO - 2025-08-19 07:10:42 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:42 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:10:42 --> Semester fees request - grade_id: 1, division_id: 1, academic_year_id: 1
INFO - 2025-08-19 07:10:42 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:42 --> Total execution time: 0.0892
INFO - 2025-08-19 07:10:55 --> Config Class Initialized
INFO - 2025-08-19 07:10:55 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:10:55 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:55 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:55 --> Config Class Initialized
INFO - 2025-08-19 07:10:55 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:55 --> URI Class Initialized
INFO - 2025-08-19 07:10:55 --> Router Class Initialized
DEBUG - 2025-08-19 07:10:55 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:55 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:55 --> Output Class Initialized
INFO - 2025-08-19 07:10:55 --> URI Class Initialized
INFO - 2025-08-19 07:10:55 --> Security Class Initialized
INFO - 2025-08-19 07:10:55 --> Router Class Initialized
DEBUG - 2025-08-19 07:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:55 --> Input Class Initialized
INFO - 2025-08-19 07:10:55 --> Output Class Initialized
INFO - 2025-08-19 07:10:55 --> Language Class Initialized
INFO - 2025-08-19 07:10:55 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:55 --> Input Class Initialized
INFO - 2025-08-19 07:10:55 --> Language Class Initialized
INFO - 2025-08-19 07:10:55 --> Loader Class Initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:55 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:55 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:55 --> Config Class Initialized
INFO - 2025-08-19 07:10:55 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:10:55 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:55 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:55 --> URI Class Initialized
INFO - 2025-08-19 07:10:55 --> Router Class Initialized
INFO - 2025-08-19 07:10:55 --> Output Class Initialized
INFO - 2025-08-19 07:10:55 --> Security Class Initialized
DEBUG - 2025-08-19 07:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:55 --> Input Class Initialized
INFO - 2025-08-19 07:10:55 --> Language Class Initialized
INFO - 2025-08-19 07:10:55 --> Loader Class Initialized
INFO - 2025-08-19 07:10:55 --> Loader Class Initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:55 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:55 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:55 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:55 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:55 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:55 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2025-08-19 07:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:55 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:55 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:55 --> Controller Class Initialized
INFO - 2025-08-19 07:10:55 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:55 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:55 --> Controller Class Initialized
INFO - 2025-08-19 07:10:55 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:55 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:55 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Parent_model" initialized
DEBUG - 2025-08-19 07:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:55 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:55 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:55 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:55 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:55 --> Controller Class Initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:55 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:55 --> Total execution time: 0.2170
INFO - 2025-08-19 07:10:55 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:55 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:55 --> Total execution time: 0.2714
INFO - 2025-08-19 07:10:55 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:55 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:55 --> Total execution time: 0.2533
INFO - 2025-08-19 07:10:55 --> Config Class Initialized
INFO - 2025-08-19 07:10:55 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:10:55 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:55 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:55 --> URI Class Initialized
INFO - 2025-08-19 07:10:55 --> Router Class Initialized
INFO - 2025-08-19 07:10:55 --> Output Class Initialized
INFO - 2025-08-19 07:10:55 --> Security Class Initialized
INFO - 2025-08-19 07:10:55 --> Config Class Initialized
DEBUG - 2025-08-19 07:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:55 --> Hooks Class Initialized
INFO - 2025-08-19 07:10:55 --> Input Class Initialized
INFO - 2025-08-19 07:10:55 --> Language Class Initialized
DEBUG - 2025-08-19 07:10:55 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:10:55 --> Utf8 Class Initialized
INFO - 2025-08-19 07:10:55 --> URI Class Initialized
INFO - 2025-08-19 07:10:55 --> Router Class Initialized
INFO - 2025-08-19 07:10:55 --> Output Class Initialized
INFO - 2025-08-19 07:10:55 --> Loader Class Initialized
INFO - 2025-08-19 07:10:55 --> Security Class Initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: url_helper
INFO - 2025-08-19 07:10:55 --> Helper loaded: security_helper
DEBUG - 2025-08-19 07:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:10:55 --> Input Class Initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:55 --> Language Class Initialized
INFO - 2025-08-19 07:10:55 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:55 --> Loader Class Initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: url_helper
DEBUG - 2025-08-19 07:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:55 --> Helper loaded: security_helper
INFO - 2025-08-19 07:10:55 --> Helper loaded: string_helper
INFO - 2025-08-19 07:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:55 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:55 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:55 --> Controller Class Initialized
INFO - 2025-08-19 07:10:55 --> Database Driver Class Initialized
INFO - 2025-08-19 07:10:55 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Division_model" initialized
DEBUG - 2025-08-19 07:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:10:55 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:10:55 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:55 --> Helper loaded: form_helper
INFO - 2025-08-19 07:10:55 --> Form Validation Class Initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:55 --> Controller Class Initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:55 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:10:56 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
DEBUG - 2025-08-19 07:10:56 --> Grades API - Got grades: 14
DEBUG - 2025-08-19 07:10:56 --> Grades API - Total count: 14
INFO - 2025-08-19 07:10:56 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:56 --> Total execution time: 0.1047
INFO - 2025-08-19 07:10:56 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Division_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Student_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Report_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Role_model" initialized
INFO - 2025-08-19 07:10:56 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:10:56 --> Final output sent to browser
DEBUG - 2025-08-19 07:10:56 --> Total execution time: 0.2245
INFO - 2025-08-19 07:11:01 --> Config Class Initialized
INFO - 2025-08-19 07:11:01 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:11:01 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:01 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:01 --> URI Class Initialized
INFO - 2025-08-19 07:11:01 --> Router Class Initialized
INFO - 2025-08-19 07:11:01 --> Output Class Initialized
INFO - 2025-08-19 07:11:01 --> Security Class Initialized
DEBUG - 2025-08-19 07:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:01 --> Input Class Initialized
INFO - 2025-08-19 07:11:01 --> Language Class Initialized
INFO - 2025-08-19 07:11:01 --> Loader Class Initialized
INFO - 2025-08-19 07:11:01 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:01 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:01 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:01 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:01 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:01 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:01 --> Controller Class Initialized
INFO - 2025-08-19 07:11:01 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:01 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:11:01 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:01 --> Total execution time: 0.1671
INFO - 2025-08-19 07:11:04 --> Config Class Initialized
INFO - 2025-08-19 07:11:04 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:11:04 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:04 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:04 --> URI Class Initialized
INFO - 2025-08-19 07:11:04 --> Router Class Initialized
INFO - 2025-08-19 07:11:04 --> Output Class Initialized
INFO - 2025-08-19 07:11:04 --> Security Class Initialized
DEBUG - 2025-08-19 07:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:04 --> Input Class Initialized
INFO - 2025-08-19 07:11:04 --> Language Class Initialized
INFO - 2025-08-19 07:11:04 --> Loader Class Initialized
INFO - 2025-08-19 07:11:04 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:04 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:04 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:04 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:04 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:04 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:04 --> Controller Class Initialized
INFO - 2025-08-19 07:11:04 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:04 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:11:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-08-19 07:11:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-08-19 07:11:05 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:05 --> Total execution time: 0.1101
INFO - 2025-08-19 07:11:05 --> Config Class Initialized
INFO - 2025-08-19 07:11:05 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:11:05 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:05 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:05 --> URI Class Initialized
INFO - 2025-08-19 07:11:05 --> Router Class Initialized
INFO - 2025-08-19 07:11:05 --> Config Class Initialized
INFO - 2025-08-19 07:11:05 --> Output Class Initialized
INFO - 2025-08-19 07:11:05 --> Hooks Class Initialized
INFO - 2025-08-19 07:11:05 --> Security Class Initialized
DEBUG - 2025-08-19 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:05 --> Input Class Initialized
DEBUG - 2025-08-19 07:11:05 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:05 --> Language Class Initialized
INFO - 2025-08-19 07:11:05 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:05 --> URI Class Initialized
INFO - 2025-08-19 07:11:05 --> Router Class Initialized
INFO - 2025-08-19 07:11:05 --> Output Class Initialized
INFO - 2025-08-19 07:11:05 --> Loader Class Initialized
INFO - 2025-08-19 07:11:05 --> Security Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: url_helper
DEBUG - 2025-08-19 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:05 --> Input Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:05 --> Language Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:05 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:05 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:05 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:05 --> Controller Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:05 --> Config Class Initialized
INFO - 2025-08-19 07:11:05 --> Hooks Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_category_model" initialized
DEBUG - 2025-08-19 07:11:05 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:05 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:05 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:05 --> Config Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:05 --> Hooks Class Initialized
INFO - 2025-08-19 07:11:05 --> URI Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:05 --> Router Class Initialized
DEBUG - 2025-08-19 07:11:05 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:05 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:05 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:05 --> Output Class Initialized
INFO - 2025-08-19 07:11:05 --> URI Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:11:05 --> Security Class Initialized
INFO - 2025-08-19 07:11:05 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:05 --> Total execution time: 0.0934
INFO - 2025-08-19 07:11:05 --> Router Class Initialized
DEBUG - 2025-08-19 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:05 --> Input Class Initialized
INFO - 2025-08-19 07:11:05 --> Output Class Initialized
INFO - 2025-08-19 07:11:05 --> Language Class Initialized
INFO - 2025-08-19 07:11:05 --> Security Class Initialized
DEBUG - 2025-08-19 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:05 --> Input Class Initialized
INFO - 2025-08-19 07:11:05 --> Language Class Initialized
INFO - 2025-08-19 07:11:05 --> Config Class Initialized
INFO - 2025-08-19 07:11:05 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:11:05 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:05 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:05 --> Loader Class Initialized
INFO - 2025-08-19 07:11:05 --> URI Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:05 --> Router Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:05 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:05 --> Output Class Initialized
INFO - 2025-08-19 07:11:05 --> Security Class Initialized
DEBUG - 2025-08-19 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:05 --> Input Class Initialized
INFO - 2025-08-19 07:11:05 --> Language Class Initialized
INFO - 2025-08-19 07:11:05 --> Loader Class Initialized
INFO - 2025-08-19 07:11:05 --> Database Driver Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:05 --> Helper loaded: security_helper
DEBUG - 2025-08-19 07:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:05 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:05 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:05 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:05 --> Controller Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:05 --> Config Class Initialized
INFO - 2025-08-19 07:11:05 --> Hooks Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_model" initialized
DEBUG - 2025-08-19 07:11:05 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:05 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:05 --> URI Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:05 --> Loader Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:05 --> Router Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:05 --> Output Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:05 --> Security Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:05 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:05 --> Input Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:05 --> Database Driver Class Initialized
INFO - 2025-08-19 07:11:05 --> Language Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:05 --> Loader Class Initialized
INFO - 2025-08-19 07:11:05 --> Database Driver Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:05 --> Loader Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:05 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:05 --> Final output sent to browser
INFO - 2025-08-19 07:11:05 --> Helper loaded: string_helper
DEBUG - 2025-08-19 07:11:05 --> Total execution time: 0.1490
INFO - 2025-08-19 07:11:05 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:05 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:05 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:05 --> Database Driver Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:05 --> Form Validation Class Initialized
DEBUG - 2025-08-19 07:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:05 --> Controller Class Initialized
INFO - 2025-08-19 07:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:05 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 07:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:05 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:05 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:05 --> Controller Class Initialized
INFO - 2025-08-19 07:11:05 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:05 --> Total execution time: 0.2687
INFO - 2025-08-19 07:11:05 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:05 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:05 --> Controller Class Initialized
INFO - 2025-08-19 07:11:05 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:05 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:05 --> Controller Class Initialized
INFO - 2025-08-19 07:11:05 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:11:05 --> Grades API - Filters: {"academic_year_id":null,"search":null,"limit":"100","offset":0}
INFO - 2025-08-19 07:11:05 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Announcement_model" initialized
DEBUG - 2025-08-19 07:11:05 --> Grades API - Got grades: 14
INFO - 2025-08-19 07:11:05 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:05 --> Model "Role_model" initialized
DEBUG - 2025-08-19 07:11:05 --> Grades API - Total count: 14
INFO - 2025-08-19 07:11:05 --> Final output sent to browser
INFO - 2025-08-19 07:11:05 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:11:05 --> Total execution time: 0.2731
INFO - 2025-08-19 07:11:05 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:05 --> Total execution time: 0.2055
INFO - 2025-08-19 07:11:05 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:05 --> Total execution time: 0.2587
INFO - 2025-08-19 07:11:09 --> Config Class Initialized
INFO - 2025-08-19 07:11:09 --> Config Class Initialized
INFO - 2025-08-19 07:11:09 --> Hooks Class Initialized
INFO - 2025-08-19 07:11:09 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:11:09 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 07:11:09 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:09 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:09 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:09 --> URI Class Initialized
INFO - 2025-08-19 07:11:09 --> URI Class Initialized
INFO - 2025-08-19 07:11:09 --> Router Class Initialized
INFO - 2025-08-19 07:11:09 --> Router Class Initialized
INFO - 2025-08-19 07:11:09 --> Output Class Initialized
INFO - 2025-08-19 07:11:09 --> Output Class Initialized
INFO - 2025-08-19 07:11:09 --> Security Class Initialized
INFO - 2025-08-19 07:11:09 --> Security Class Initialized
DEBUG - 2025-08-19 07:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:09 --> Input Class Initialized
DEBUG - 2025-08-19 07:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:09 --> Input Class Initialized
INFO - 2025-08-19 07:11:09 --> Language Class Initialized
INFO - 2025-08-19 07:11:09 --> Language Class Initialized
INFO - 2025-08-19 07:11:09 --> Loader Class Initialized
INFO - 2025-08-19 07:11:09 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:09 --> Loader Class Initialized
INFO - 2025-08-19 07:11:09 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:09 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:09 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:09 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:09 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:09 --> Database Driver Class Initialized
INFO - 2025-08-19 07:11:09 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 07:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:09 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:09 --> Config Class Initialized
INFO - 2025-08-19 07:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:09 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:09 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:09 --> Hooks Class Initialized
INFO - 2025-08-19 07:11:09 --> Controller Class Initialized
INFO - 2025-08-19 07:11:09 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:09 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 07:11:09 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:09 --> Controller Class Initialized
INFO - 2025-08-19 07:11:09 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:09 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:09 --> URI Class Initialized
INFO - 2025-08-19 07:11:09 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:09 --> Router Class Initialized
INFO - 2025-08-19 07:11:09 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:09 --> Output Class Initialized
INFO - 2025-08-19 07:11:09 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:09 --> Security Class Initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Division_model" initialized
DEBUG - 2025-08-19 07:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:09 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:11:09 --> Input Class Initialized
INFO - 2025-08-19 07:11:09 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:09 --> Total execution time: 0.1667
INFO - 2025-08-19 07:11:09 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:09 --> Total execution time: 0.1676
INFO - 2025-08-19 07:11:09 --> Language Class Initialized
INFO - 2025-08-19 07:11:09 --> Loader Class Initialized
INFO - 2025-08-19 07:11:09 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:09 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:09 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:09 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:09 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:09 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:09 --> Controller Class Initialized
INFO - 2025-08-19 07:11:09 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:09 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:11:09 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:09 --> Total execution time: 0.1920
INFO - 2025-08-19 07:11:13 --> Config Class Initialized
INFO - 2025-08-19 07:11:13 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:11:13 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:13 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:13 --> URI Class Initialized
INFO - 2025-08-19 07:11:13 --> Router Class Initialized
INFO - 2025-08-19 07:11:13 --> Output Class Initialized
INFO - 2025-08-19 07:11:13 --> Security Class Initialized
DEBUG - 2025-08-19 07:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:13 --> Input Class Initialized
INFO - 2025-08-19 07:11:13 --> Language Class Initialized
INFO - 2025-08-19 07:11:13 --> Loader Class Initialized
INFO - 2025-08-19 07:11:13 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:13 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:13 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:13 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:13 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:13 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:13 --> Controller Class Initialized
INFO - 2025-08-19 07:11:13 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:13 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:11:13 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:13 --> Total execution time: 0.0908
INFO - 2025-08-19 07:11:15 --> Config Class Initialized
INFO - 2025-08-19 07:11:15 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:11:15 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:11:15 --> Utf8 Class Initialized
INFO - 2025-08-19 07:11:15 --> URI Class Initialized
INFO - 2025-08-19 07:11:15 --> Router Class Initialized
INFO - 2025-08-19 07:11:15 --> Output Class Initialized
INFO - 2025-08-19 07:11:15 --> Security Class Initialized
DEBUG - 2025-08-19 07:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:11:15 --> Input Class Initialized
INFO - 2025-08-19 07:11:15 --> Language Class Initialized
INFO - 2025-08-19 07:11:15 --> Loader Class Initialized
INFO - 2025-08-19 07:11:15 --> Helper loaded: url_helper
INFO - 2025-08-19 07:11:15 --> Helper loaded: security_helper
INFO - 2025-08-19 07:11:15 --> Helper loaded: string_helper
INFO - 2025-08-19 07:11:15 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:11:15 --> Helper loaded: form_helper
INFO - 2025-08-19 07:11:15 --> Form Validation Class Initialized
INFO - 2025-08-19 07:11:15 --> Controller Class Initialized
INFO - 2025-08-19 07:11:15 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Division_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Student_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Report_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Role_model" initialized
INFO - 2025-08-19 07:11:15 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:11:15 --> Semester fees request - grade_id: 1, division_id: 1, academic_year_id: 1
INFO - 2025-08-19 07:11:15 --> Final output sent to browser
DEBUG - 2025-08-19 07:11:15 --> Total execution time: 0.0912
INFO - 2025-08-19 07:19:34 --> Config Class Initialized
INFO - 2025-08-19 07:19:34 --> Hooks Class Initialized
INFO - 2025-08-19 07:19:34 --> Config Class Initialized
INFO - 2025-08-19 07:19:34 --> Config Class Initialized
INFO - 2025-08-19 07:19:34 --> Hooks Class Initialized
INFO - 2025-08-19 07:19:34 --> Hooks Class Initialized
INFO - 2025-08-19 07:19:34 --> Config Class Initialized
INFO - 2025-08-19 07:19:34 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:19:34 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 07:19:34 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:19:34 --> Utf8 Class Initialized
INFO - 2025-08-19 07:19:34 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:19:34 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:19:34 --> Utf8 Class Initialized
INFO - 2025-08-19 07:19:34 --> URI Class Initialized
INFO - 2025-08-19 07:19:34 --> URI Class Initialized
INFO - 2025-08-19 07:19:34 --> URI Class Initialized
INFO - 2025-08-19 07:19:34 --> Router Class Initialized
INFO - 2025-08-19 07:19:34 --> Router Class Initialized
INFO - 2025-08-19 07:19:34 --> Router Class Initialized
INFO - 2025-08-19 07:19:34 --> Output Class Initialized
INFO - 2025-08-19 07:19:34 --> Output Class Initialized
INFO - 2025-08-19 07:19:34 --> Output Class Initialized
INFO - 2025-08-19 07:19:34 --> Security Class Initialized
DEBUG - 2025-08-19 07:19:34 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:19:34 --> Security Class Initialized
INFO - 2025-08-19 07:19:34 --> Utf8 Class Initialized
INFO - 2025-08-19 07:19:34 --> Security Class Initialized
DEBUG - 2025-08-19 07:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:19:34 --> URI Class Initialized
INFO - 2025-08-19 07:19:34 --> Input Class Initialized
INFO - 2025-08-19 07:19:34 --> Input Class Initialized
DEBUG - 2025-08-19 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:19:34 --> Language Class Initialized
INFO - 2025-08-19 07:19:34 --> Language Class Initialized
INFO - 2025-08-19 07:19:34 --> Input Class Initialized
INFO - 2025-08-19 07:19:34 --> Router Class Initialized
INFO - 2025-08-19 07:19:34 --> Language Class Initialized
INFO - 2025-08-19 07:19:34 --> Output Class Initialized
INFO - 2025-08-19 07:19:34 --> Security Class Initialized
DEBUG - 2025-08-19 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:19:34 --> Input Class Initialized
INFO - 2025-08-19 07:19:34 --> Loader Class Initialized
INFO - 2025-08-19 07:19:34 --> Loader Class Initialized
INFO - 2025-08-19 07:19:34 --> Language Class Initialized
INFO - 2025-08-19 07:19:34 --> Loader Class Initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: url_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: url_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: url_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: security_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: security_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: security_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: string_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: string_helper
INFO - 2025-08-19 07:19:34 --> Loader Class Initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: url_helper
INFO - 2025-08-19 07:19:34 --> Database Driver Class Initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: security_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: string_helper
INFO - 2025-08-19 07:19:34 --> Helper loaded: string_helper
INFO - 2025-08-19 07:19:34 --> Database Driver Class Initialized
INFO - 2025-08-19 07:19:34 --> Config Class Initialized
INFO - 2025-08-19 07:19:34 --> Hooks Class Initialized
INFO - 2025-08-19 07:19:34 --> Database Driver Class Initialized
INFO - 2025-08-19 07:19:34 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:19:34 --> UTF-8 Support Enabled
DEBUG - 2025-08-19 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:19:34 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:19:34 --> URI Class Initialized
INFO - 2025-08-19 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:19:34 --> Helper loaded: form_helper
INFO - 2025-08-19 07:19:34 --> Form Validation Class Initialized
INFO - 2025-08-19 07:19:34 --> Controller Class Initialized
DEBUG - 2025-08-19 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:19:34 --> Router Class Initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: form_helper
INFO - 2025-08-19 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:19:34 --> Form Validation Class Initialized
INFO - 2025-08-19 07:19:34 --> Output Class Initialized
INFO - 2025-08-19 07:19:34 --> Controller Class Initialized
INFO - 2025-08-19 07:19:34 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:19:34 --> Security Class Initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: form_helper
INFO - 2025-08-19 07:19:34 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:19:34 --> Form Validation Class Initialized
DEBUG - 2025-08-19 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:19:34 --> Controller Class Initialized
INFO - 2025-08-19 07:19:34 --> Input Class Initialized
INFO - 2025-08-19 07:19:34 --> Model "Division_model" initialized
INFO - 2025-08-19 07:19:34 --> Language Class Initialized
INFO - 2025-08-19 07:19:34 --> Model "Student_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Division_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Student_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:19:34 --> Loader Class Initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: url_helper
INFO - 2025-08-19 07:19:34 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: security_helper
INFO - 2025-08-19 07:19:34 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Report_model" initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: string_helper
INFO - 2025-08-19 07:19:34 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Role_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:19:34 --> Final output sent to browser
DEBUG - 2025-08-19 07:19:34 --> Total execution time: 0.0959
INFO - 2025-08-19 07:19:34 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Auth_model" initialized
DEBUG - 2025-08-19 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:19:34 --> Model "Report_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Role_model" initialized
INFO - 2025-08-19 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:19:34 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Division_model" initialized
INFO - 2025-08-19 07:19:34 --> Database Driver Class Initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: form_helper
INFO - 2025-08-19 07:19:34 --> Form Validation Class Initialized
INFO - 2025-08-19 07:19:34 --> Model "Student_model" initialized
INFO - 2025-08-19 07:19:34 --> Controller Class Initialized
INFO - 2025-08-19 07:19:34 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Division_model" initialized
DEBUG - 2025-08-19 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:19:34 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:19:34 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Student_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Report_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Role_model" initialized
INFO - 2025-08-19 07:19:34 --> Helper loaded: form_helper
INFO - 2025-08-19 07:19:34 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:19:34 --> Form Validation Class Initialized
INFO - 2025-08-19 07:19:34 --> Controller Class Initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:19:34 --> Final output sent to browser
DEBUG - 2025-08-19 07:19:34 --> Total execution time: 0.1207
INFO - 2025-08-19 07:19:34 --> Final output sent to browser
DEBUG - 2025-08-19 07:19:34 --> Total execution time: 0.1238
INFO - 2025-08-19 07:19:34 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Division_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Report_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Student_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Role_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:19:34 --> Final output sent to browser
INFO - 2025-08-19 07:19:34 --> Model "Academic_year_model" initialized
DEBUG - 2025-08-19 07:19:34 --> Total execution time: 0.1381
INFO - 2025-08-19 07:19:34 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Report_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Role_model" initialized
INFO - 2025-08-19 07:19:34 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:19:34 --> Final output sent to browser
DEBUG - 2025-08-19 07:19:34 --> Total execution time: 0.1017
INFO - 2025-08-19 07:21:24 --> Config Class Initialized
INFO - 2025-08-19 07:21:24 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:21:24 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:24 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:24 --> URI Class Initialized
INFO - 2025-08-19 07:21:24 --> Router Class Initialized
INFO - 2025-08-19 07:21:24 --> Output Class Initialized
INFO - 2025-08-19 07:21:24 --> Security Class Initialized
DEBUG - 2025-08-19 07:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:21:24 --> Input Class Initialized
INFO - 2025-08-19 07:21:24 --> Language Class Initialized
INFO - 2025-08-19 07:21:24 --> Loader Class Initialized
INFO - 2025-08-19 07:21:24 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:24 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:24 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:24 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:24 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:24 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:24 --> Controller Class Initialized
INFO - 2025-08-19 07:21:24 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:24 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:24 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:25 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:25 --> Total execution time: 0.1460
INFO - 2025-08-19 07:21:25 --> Config Class Initialized
INFO - 2025-08-19 07:21:25 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:21:25 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:25 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:25 --> URI Class Initialized
INFO - 2025-08-19 07:21:25 --> Router Class Initialized
INFO - 2025-08-19 07:21:25 --> Output Class Initialized
INFO - 2025-08-19 07:21:25 --> Security Class Initialized
DEBUG - 2025-08-19 07:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:21:25 --> Input Class Initialized
INFO - 2025-08-19 07:21:25 --> Language Class Initialized
INFO - 2025-08-19 07:21:25 --> Loader Class Initialized
INFO - 2025-08-19 07:21:25 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:25 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:25 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:25 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:25 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:25 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:25 --> Controller Class Initialized
INFO - 2025-08-19 07:21:25 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:25 --> Model "Staff_wallet_model" initialized
DEBUG - 2025-08-19 07:21:25 --> Grades API - Filters: {"academic_year_id":"1","search":null,"limit":"10","offset":0}
DEBUG - 2025-08-19 07:21:26 --> Grades API - Got grades: 10
DEBUG - 2025-08-19 07:21:26 --> Grades API - Total count: 14
INFO - 2025-08-19 07:21:26 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:26 --> Total execution time: 0.1101
INFO - 2025-08-19 07:21:28 --> Config Class Initialized
INFO - 2025-08-19 07:21:28 --> Hooks Class Initialized
INFO - 2025-08-19 07:21:28 --> Config Class Initialized
INFO - 2025-08-19 07:21:28 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:21:28 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:28 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:21:28 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:28 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:28 --> URI Class Initialized
INFO - 2025-08-19 07:21:28 --> URI Class Initialized
INFO - 2025-08-19 07:21:28 --> Router Class Initialized
INFO - 2025-08-19 07:21:28 --> Router Class Initialized
INFO - 2025-08-19 07:21:28 --> Output Class Initialized
INFO - 2025-08-19 07:21:28 --> Output Class Initialized
INFO - 2025-08-19 07:21:28 --> Security Class Initialized
INFO - 2025-08-19 07:21:28 --> Security Class Initialized
DEBUG - 2025-08-19 07:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:21:28 --> Input Class Initialized
INFO - 2025-08-19 07:21:28 --> Input Class Initialized
INFO - 2025-08-19 07:21:28 --> Language Class Initialized
INFO - 2025-08-19 07:21:28 --> Language Class Initialized
INFO - 2025-08-19 07:21:28 --> Loader Class Initialized
INFO - 2025-08-19 07:21:28 --> Loader Class Initialized
INFO - 2025-08-19 07:21:28 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:28 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:28 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:28 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:28 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:28 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:28 --> Config Class Initialized
INFO - 2025-08-19 07:21:28 --> Hooks Class Initialized
INFO - 2025-08-19 07:21:28 --> Database Driver Class Initialized
INFO - 2025-08-19 07:21:28 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:21:28 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:28 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:28 --> URI Class Initialized
INFO - 2025-08-19 07:21:28 --> Router Class Initialized
DEBUG - 2025-08-19 07:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:28 --> Output Class Initialized
DEBUG - 2025-08-19 07:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:28 --> Security Class Initialized
INFO - 2025-08-19 07:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:28 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:28 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:28 --> Controller Class Initialized
DEBUG - 2025-08-19 07:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:21:28 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:28 --> Input Class Initialized
INFO - 2025-08-19 07:21:28 --> Language Class Initialized
INFO - 2025-08-19 07:21:28 --> Config Class Initialized
INFO - 2025-08-19 07:21:28 --> Hooks Class Initialized
INFO - 2025-08-19 07:21:28 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:28 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:28 --> Controller Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Grade_model" initialized
DEBUG - 2025-08-19 07:21:28 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:28 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:28 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:28 --> Loader Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:28 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:28 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:28 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:28 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:28 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:28 --> URI Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:28 --> Router Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:28 --> Database Driver Class Initialized
INFO - 2025-08-19 07:21:28 --> Output Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:28 --> Security Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:28 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:21:28 --> Total execution time: 0.1014
INFO - 2025-08-19 07:21:28 --> Model "Division_model" initialized
DEBUG - 2025-08-19 07:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:28 --> Input Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:28 --> Language Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:28 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:28 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:28 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:28 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:28 --> Controller Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:28 --> Loader Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:28 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:28 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:28 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:28 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:28 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:28 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:28 --> Total execution time: 0.1372
INFO - 2025-08-19 07:21:28 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:28 --> Database Driver Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Complaint_model" initialized
DEBUG - 2025-08-19 07:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:28 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:28 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:28 --> Final output sent to browser
INFO - 2025-08-19 07:21:28 --> Helper loaded: form_helper
DEBUG - 2025-08-19 07:21:28 --> Total execution time: 0.1276
INFO - 2025-08-19 07:21:28 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:28 --> Controller Class Initialized
INFO - 2025-08-19 07:21:28 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:28 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:28 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:28 --> Total execution time: 0.1292
INFO - 2025-08-19 07:21:29 --> Config Class Initialized
INFO - 2025-08-19 07:21:29 --> Config Class Initialized
INFO - 2025-08-19 07:21:29 --> Hooks Class Initialized
INFO - 2025-08-19 07:21:29 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:21:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:29 --> Utf8 Class Initialized
DEBUG - 2025-08-19 07:21:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:29 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:29 --> URI Class Initialized
INFO - 2025-08-19 07:21:29 --> URI Class Initialized
INFO - 2025-08-19 07:21:29 --> Router Class Initialized
INFO - 2025-08-19 07:21:29 --> Router Class Initialized
INFO - 2025-08-19 07:21:29 --> Output Class Initialized
INFO - 2025-08-19 07:21:29 --> Output Class Initialized
INFO - 2025-08-19 07:21:29 --> Security Class Initialized
INFO - 2025-08-19 07:21:29 --> Security Class Initialized
DEBUG - 2025-08-19 07:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-08-19 07:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:21:29 --> Input Class Initialized
INFO - 2025-08-19 07:21:29 --> Input Class Initialized
INFO - 2025-08-19 07:21:29 --> Language Class Initialized
INFO - 2025-08-19 07:21:29 --> Language Class Initialized
INFO - 2025-08-19 07:21:29 --> Loader Class Initialized
INFO - 2025-08-19 07:21:29 --> Loader Class Initialized
INFO - 2025-08-19 07:21:29 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:29 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:29 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:29 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:29 --> Database Driver Class Initialized
INFO - 2025-08-19 07:21:29 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-08-19 07:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:29 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:29 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:29 --> Controller Class Initialized
INFO - 2025-08-19 07:21:29 --> Controller Class Initialized
INFO - 2025-08-19 07:21:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:29 --> Total execution time: 0.1072
INFO - 2025-08-19 07:21:29 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:29 --> Total execution time: 0.1251
INFO - 2025-08-19 07:21:29 --> Config Class Initialized
INFO - 2025-08-19 07:21:29 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:21:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:29 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:29 --> URI Class Initialized
INFO - 2025-08-19 07:21:29 --> Router Class Initialized
INFO - 2025-08-19 07:21:29 --> Output Class Initialized
INFO - 2025-08-19 07:21:29 --> Security Class Initialized
DEBUG - 2025-08-19 07:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:21:29 --> Input Class Initialized
INFO - 2025-08-19 07:21:29 --> Language Class Initialized
INFO - 2025-08-19 07:21:29 --> Loader Class Initialized
INFO - 2025-08-19 07:21:29 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:29 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:29 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:29 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:29 --> Controller Class Initialized
INFO - 2025-08-19 07:21:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:29 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:29 --> Total execution time: 0.1005
INFO - 2025-08-19 07:21:30 --> Config Class Initialized
INFO - 2025-08-19 07:21:30 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:21:30 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:30 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:30 --> URI Class Initialized
INFO - 2025-08-19 07:21:30 --> Router Class Initialized
INFO - 2025-08-19 07:21:30 --> Output Class Initialized
INFO - 2025-08-19 07:21:30 --> Security Class Initialized
DEBUG - 2025-08-19 07:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:21:30 --> Input Class Initialized
INFO - 2025-08-19 07:21:30 --> Language Class Initialized
INFO - 2025-08-19 07:21:30 --> Loader Class Initialized
INFO - 2025-08-19 07:21:30 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:30 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:30 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:30 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:30 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:30 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:30 --> Controller Class Initialized
INFO - 2025-08-19 07:21:30 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Division_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Student_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Report_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Role_model" initialized
INFO - 2025-08-19 07:21:30 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:21:30 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:30 --> Total execution time: 0.1121
INFO - 2025-08-19 07:21:38 --> Config Class Initialized
INFO - 2025-08-19 07:21:38 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:21:38 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:21:38 --> Utf8 Class Initialized
INFO - 2025-08-19 07:21:38 --> URI Class Initialized
INFO - 2025-08-19 07:21:38 --> Router Class Initialized
INFO - 2025-08-19 07:21:38 --> Output Class Initialized
INFO - 2025-08-19 07:21:38 --> Security Class Initialized
DEBUG - 2025-08-19 07:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:21:38 --> Input Class Initialized
INFO - 2025-08-19 07:21:38 --> Language Class Initialized
INFO - 2025-08-19 07:21:38 --> Loader Class Initialized
INFO - 2025-08-19 07:21:38 --> Helper loaded: url_helper
INFO - 2025-08-19 07:21:38 --> Helper loaded: security_helper
INFO - 2025-08-19 07:21:38 --> Helper loaded: string_helper
INFO - 2025-08-19 07:21:38 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:21:38 --> Helper loaded: form_helper
INFO - 2025-08-19 07:21:38 --> Form Validation Class Initialized
INFO - 2025-08-19 07:21:38 --> Controller Class Initialized
INFO - 2025-08-19 07:21:38 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:21:38 --> Final output sent to browser
DEBUG - 2025-08-19 07:21:38 --> Total execution time: 0.0637
INFO - 2025-08-19 07:22:54 --> Config Class Initialized
INFO - 2025-08-19 07:22:54 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:22:54 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:22:54 --> Utf8 Class Initialized
INFO - 2025-08-19 07:22:54 --> URI Class Initialized
INFO - 2025-08-19 07:22:54 --> Router Class Initialized
INFO - 2025-08-19 07:22:54 --> Output Class Initialized
INFO - 2025-08-19 07:22:54 --> Security Class Initialized
DEBUG - 2025-08-19 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:22:54 --> Input Class Initialized
INFO - 2025-08-19 07:22:54 --> Language Class Initialized
INFO - 2025-08-19 07:22:54 --> Loader Class Initialized
INFO - 2025-08-19 07:22:54 --> Helper loaded: url_helper
INFO - 2025-08-19 07:22:54 --> Helper loaded: security_helper
INFO - 2025-08-19 07:22:54 --> Helper loaded: string_helper
INFO - 2025-08-19 07:22:54 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:22:54 --> Helper loaded: form_helper
INFO - 2025-08-19 07:22:54 --> Form Validation Class Initialized
INFO - 2025-08-19 07:22:54 --> Controller Class Initialized
INFO - 2025-08-19 07:22:54 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:22:54 --> Final output sent to browser
DEBUG - 2025-08-19 07:22:54 --> Total execution time: 0.1515
INFO - 2025-08-19 07:22:54 --> Config Class Initialized
INFO - 2025-08-19 07:22:54 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:22:54 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:22:54 --> Utf8 Class Initialized
INFO - 2025-08-19 07:22:54 --> URI Class Initialized
INFO - 2025-08-19 07:22:54 --> Router Class Initialized
INFO - 2025-08-19 07:22:54 --> Output Class Initialized
INFO - 2025-08-19 07:22:54 --> Security Class Initialized
DEBUG - 2025-08-19 07:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:22:54 --> Input Class Initialized
INFO - 2025-08-19 07:22:54 --> Language Class Initialized
INFO - 2025-08-19 07:22:54 --> Loader Class Initialized
INFO - 2025-08-19 07:22:54 --> Helper loaded: url_helper
INFO - 2025-08-19 07:22:54 --> Helper loaded: security_helper
INFO - 2025-08-19 07:22:54 --> Helper loaded: string_helper
INFO - 2025-08-19 07:22:54 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:22:55 --> Helper loaded: form_helper
INFO - 2025-08-19 07:22:55 --> Form Validation Class Initialized
INFO - 2025-08-19 07:22:55 --> Controller Class Initialized
INFO - 2025-08-19 07:22:55 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:22:55 --> Final output sent to browser
DEBUG - 2025-08-19 07:22:55 --> Total execution time: 0.0628
INFO - 2025-08-19 07:22:55 --> Config Class Initialized
INFO - 2025-08-19 07:22:55 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:22:55 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:22:55 --> Utf8 Class Initialized
INFO - 2025-08-19 07:22:55 --> URI Class Initialized
INFO - 2025-08-19 07:22:55 --> Router Class Initialized
INFO - 2025-08-19 07:22:55 --> Output Class Initialized
INFO - 2025-08-19 07:22:55 --> Security Class Initialized
DEBUG - 2025-08-19 07:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:22:55 --> Input Class Initialized
INFO - 2025-08-19 07:22:55 --> Language Class Initialized
INFO - 2025-08-19 07:22:55 --> Loader Class Initialized
INFO - 2025-08-19 07:22:55 --> Helper loaded: url_helper
INFO - 2025-08-19 07:22:55 --> Helper loaded: security_helper
INFO - 2025-08-19 07:22:55 --> Helper loaded: string_helper
INFO - 2025-08-19 07:22:55 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:22:55 --> Helper loaded: form_helper
INFO - 2025-08-19 07:22:55 --> Form Validation Class Initialized
INFO - 2025-08-19 07:22:55 --> Controller Class Initialized
INFO - 2025-08-19 07:22:55 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Grade_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Division_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Student_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Parent_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Staff_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Fee_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Academic_year_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Fee_category_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Fee_structure_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Fee_collection_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Announcement_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Complaint_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Report_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Role_model" initialized
INFO - 2025-08-19 07:22:55 --> Model "Staff_wallet_model" initialized
INFO - 2025-08-19 07:22:55 --> Final output sent to browser
DEBUG - 2025-08-19 07:22:55 --> Total execution time: 0.1587
INFO - 2025-08-19 07:22:59 --> Config Class Initialized
INFO - 2025-08-19 07:22:59 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:22:59 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:22:59 --> Utf8 Class Initialized
INFO - 2025-08-19 07:22:59 --> URI Class Initialized
INFO - 2025-08-19 07:22:59 --> Router Class Initialized
INFO - 2025-08-19 07:22:59 --> Output Class Initialized
INFO - 2025-08-19 07:22:59 --> Security Class Initialized
DEBUG - 2025-08-19 07:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:22:59 --> Input Class Initialized
INFO - 2025-08-19 07:22:59 --> Language Class Initialized
INFO - 2025-08-19 07:22:59 --> Loader Class Initialized
INFO - 2025-08-19 07:22:59 --> Helper loaded: url_helper
INFO - 2025-08-19 07:22:59 --> Helper loaded: security_helper
INFO - 2025-08-19 07:22:59 --> Helper loaded: string_helper
INFO - 2025-08-19 07:22:59 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:22:59 --> Helper loaded: form_helper
INFO - 2025-08-19 07:22:59 --> Form Validation Class Initialized
INFO - 2025-08-19 07:22:59 --> Controller Class Initialized
INFO - 2025-08-19 07:22:59 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:22:59 --> Final output sent to browser
DEBUG - 2025-08-19 07:22:59 --> Total execution time: 0.0874
INFO - 2025-08-19 07:24:42 --> Config Class Initialized
INFO - 2025-08-19 07:24:42 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:24:42 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:24:42 --> Utf8 Class Initialized
INFO - 2025-08-19 07:24:42 --> URI Class Initialized
INFO - 2025-08-19 07:24:42 --> Router Class Initialized
INFO - 2025-08-19 07:24:42 --> Output Class Initialized
INFO - 2025-08-19 07:24:42 --> Security Class Initialized
DEBUG - 2025-08-19 07:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:24:42 --> Input Class Initialized
INFO - 2025-08-19 07:24:42 --> Language Class Initialized
INFO - 2025-08-19 07:24:42 --> Loader Class Initialized
INFO - 2025-08-19 07:24:42 --> Helper loaded: url_helper
INFO - 2025-08-19 07:24:42 --> Helper loaded: security_helper
INFO - 2025-08-19 07:24:42 --> Helper loaded: string_helper
INFO - 2025-08-19 07:24:42 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:24:42 --> Helper loaded: form_helper
INFO - 2025-08-19 07:24:42 --> Form Validation Class Initialized
INFO - 2025-08-19 07:24:42 --> Controller Class Initialized
INFO - 2025-08-19 07:24:42 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:24:42 --> Final output sent to browser
DEBUG - 2025-08-19 07:24:42 --> Total execution time: 0.0768
INFO - 2025-08-19 07:27:04 --> Config Class Initialized
INFO - 2025-08-19 07:27:04 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:27:04 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:27:04 --> Utf8 Class Initialized
INFO - 2025-08-19 07:27:04 --> URI Class Initialized
INFO - 2025-08-19 07:27:04 --> Router Class Initialized
INFO - 2025-08-19 07:27:04 --> Output Class Initialized
INFO - 2025-08-19 07:27:04 --> Security Class Initialized
DEBUG - 2025-08-19 07:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:27:04 --> Input Class Initialized
INFO - 2025-08-19 07:27:04 --> Language Class Initialized
INFO - 2025-08-19 07:27:04 --> Loader Class Initialized
INFO - 2025-08-19 07:27:04 --> Helper loaded: url_helper
INFO - 2025-08-19 07:27:04 --> Helper loaded: security_helper
INFO - 2025-08-19 07:27:04 --> Helper loaded: string_helper
INFO - 2025-08-19 07:27:04 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:27:05 --> Helper loaded: form_helper
INFO - 2025-08-19 07:27:05 --> Form Validation Class Initialized
INFO - 2025-08-19 07:27:05 --> Controller Class Initialized
INFO - 2025-08-19 07:27:05 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:27:05 --> Final output sent to browser
DEBUG - 2025-08-19 07:27:05 --> Total execution time: 0.0845
INFO - 2025-08-19 07:27:16 --> Config Class Initialized
INFO - 2025-08-19 07:27:16 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:27:16 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:27:16 --> Utf8 Class Initialized
INFO - 2025-08-19 07:27:16 --> URI Class Initialized
INFO - 2025-08-19 07:27:16 --> Router Class Initialized
INFO - 2025-08-19 07:27:16 --> Output Class Initialized
INFO - 2025-08-19 07:27:16 --> Security Class Initialized
DEBUG - 2025-08-19 07:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:27:16 --> Input Class Initialized
INFO - 2025-08-19 07:27:16 --> Language Class Initialized
INFO - 2025-08-19 07:27:16 --> Loader Class Initialized
INFO - 2025-08-19 07:27:16 --> Helper loaded: url_helper
INFO - 2025-08-19 07:27:16 --> Helper loaded: security_helper
INFO - 2025-08-19 07:27:16 --> Helper loaded: string_helper
INFO - 2025-08-19 07:27:16 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:27:16 --> Helper loaded: form_helper
INFO - 2025-08-19 07:27:16 --> Form Validation Class Initialized
INFO - 2025-08-19 07:27:16 --> Controller Class Initialized
INFO - 2025-08-19 07:27:16 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:27:16 --> Final output sent to browser
DEBUG - 2025-08-19 07:27:16 --> Total execution time: 0.0667
INFO - 2025-08-19 07:27:24 --> Config Class Initialized
INFO - 2025-08-19 07:27:24 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:27:24 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:27:24 --> Utf8 Class Initialized
INFO - 2025-08-19 07:27:24 --> URI Class Initialized
INFO - 2025-08-19 07:27:24 --> Router Class Initialized
INFO - 2025-08-19 07:27:24 --> Output Class Initialized
INFO - 2025-08-19 07:27:24 --> Security Class Initialized
DEBUG - 2025-08-19 07:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:27:24 --> Input Class Initialized
INFO - 2025-08-19 07:27:24 --> Language Class Initialized
INFO - 2025-08-19 07:27:24 --> Loader Class Initialized
INFO - 2025-08-19 07:27:24 --> Helper loaded: url_helper
INFO - 2025-08-19 07:27:24 --> Helper loaded: security_helper
INFO - 2025-08-19 07:27:24 --> Helper loaded: string_helper
INFO - 2025-08-19 07:27:24 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:27:24 --> Helper loaded: form_helper
INFO - 2025-08-19 07:27:24 --> Form Validation Class Initialized
INFO - 2025-08-19 07:27:24 --> Controller Class Initialized
INFO - 2025-08-19 07:27:24 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:27:24 --> Final output sent to browser
DEBUG - 2025-08-19 07:27:24 --> Total execution time: 0.1270
INFO - 2025-08-19 07:27:45 --> Config Class Initialized
INFO - 2025-08-19 07:27:45 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:27:45 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:27:45 --> Utf8 Class Initialized
INFO - 2025-08-19 07:27:45 --> URI Class Initialized
INFO - 2025-08-19 07:27:45 --> Router Class Initialized
INFO - 2025-08-19 07:27:45 --> Output Class Initialized
INFO - 2025-08-19 07:27:45 --> Security Class Initialized
DEBUG - 2025-08-19 07:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:27:45 --> Input Class Initialized
INFO - 2025-08-19 07:27:45 --> Language Class Initialized
INFO - 2025-08-19 07:27:45 --> Loader Class Initialized
INFO - 2025-08-19 07:27:45 --> Helper loaded: url_helper
INFO - 2025-08-19 07:27:45 --> Helper loaded: security_helper
INFO - 2025-08-19 07:27:45 --> Helper loaded: string_helper
INFO - 2025-08-19 07:27:45 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:27:45 --> Helper loaded: form_helper
INFO - 2025-08-19 07:27:45 --> Form Validation Class Initialized
INFO - 2025-08-19 07:27:45 --> Controller Class Initialized
INFO - 2025-08-19 07:27:45 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:27:45 --> Final output sent to browser
DEBUG - 2025-08-19 07:27:45 --> Total execution time: 0.0836
INFO - 2025-08-19 07:31:39 --> Config Class Initialized
INFO - 2025-08-19 07:31:39 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:31:39 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:31:39 --> Utf8 Class Initialized
INFO - 2025-08-19 07:31:39 --> URI Class Initialized
INFO - 2025-08-19 07:31:39 --> Router Class Initialized
INFO - 2025-08-19 07:31:39 --> Output Class Initialized
INFO - 2025-08-19 07:31:39 --> Security Class Initialized
DEBUG - 2025-08-19 07:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:31:39 --> Input Class Initialized
INFO - 2025-08-19 07:31:39 --> Language Class Initialized
INFO - 2025-08-19 07:31:39 --> Loader Class Initialized
INFO - 2025-08-19 07:31:39 --> Helper loaded: url_helper
INFO - 2025-08-19 07:31:39 --> Helper loaded: security_helper
INFO - 2025-08-19 07:31:39 --> Helper loaded: string_helper
INFO - 2025-08-19 07:31:39 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:31:39 --> Helper loaded: form_helper
INFO - 2025-08-19 07:31:39 --> Form Validation Class Initialized
INFO - 2025-08-19 07:31:39 --> Controller Class Initialized
INFO - 2025-08-19 07:31:39 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:31:39 --> Final output sent to browser
DEBUG - 2025-08-19 07:31:39 --> Total execution time: 0.0726
INFO - 2025-08-19 07:31:43 --> Config Class Initialized
INFO - 2025-08-19 07:31:43 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:31:43 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:31:43 --> Utf8 Class Initialized
INFO - 2025-08-19 07:31:43 --> URI Class Initialized
INFO - 2025-08-19 07:31:43 --> Router Class Initialized
INFO - 2025-08-19 07:31:43 --> Output Class Initialized
INFO - 2025-08-19 07:31:43 --> Security Class Initialized
DEBUG - 2025-08-19 07:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:31:43 --> Input Class Initialized
INFO - 2025-08-19 07:31:43 --> Language Class Initialized
INFO - 2025-08-19 07:31:43 --> Loader Class Initialized
INFO - 2025-08-19 07:31:43 --> Helper loaded: url_helper
INFO - 2025-08-19 07:31:43 --> Helper loaded: security_helper
INFO - 2025-08-19 07:31:43 --> Helper loaded: string_helper
INFO - 2025-08-19 07:31:43 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:31:43 --> Helper loaded: form_helper
INFO - 2025-08-19 07:31:43 --> Form Validation Class Initialized
INFO - 2025-08-19 07:31:43 --> Controller Class Initialized
INFO - 2025-08-19 07:31:43 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:31:43 --> Final output sent to browser
DEBUG - 2025-08-19 07:31:43 --> Total execution time: 0.0569
INFO - 2025-08-19 07:35:07 --> Config Class Initialized
INFO - 2025-08-19 07:35:07 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:35:07 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:35:07 --> Utf8 Class Initialized
INFO - 2025-08-19 07:35:07 --> URI Class Initialized
INFO - 2025-08-19 07:35:07 --> Router Class Initialized
INFO - 2025-08-19 07:35:07 --> Output Class Initialized
INFO - 2025-08-19 07:35:07 --> Security Class Initialized
DEBUG - 2025-08-19 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:35:07 --> Input Class Initialized
INFO - 2025-08-19 07:35:07 --> Language Class Initialized
INFO - 2025-08-19 07:35:07 --> Loader Class Initialized
INFO - 2025-08-19 07:35:07 --> Helper loaded: url_helper
INFO - 2025-08-19 07:35:07 --> Helper loaded: security_helper
INFO - 2025-08-19 07:35:07 --> Helper loaded: string_helper
INFO - 2025-08-19 07:35:07 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:35:07 --> Helper loaded: form_helper
INFO - 2025-08-19 07:35:07 --> Form Validation Class Initialized
INFO - 2025-08-19 07:35:07 --> Controller Class Initialized
INFO - 2025-08-19 07:35:07 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:35:07 --> Final output sent to browser
DEBUG - 2025-08-19 07:35:07 --> Total execution time: 0.0649
INFO - 2025-08-19 07:35:12 --> Config Class Initialized
INFO - 2025-08-19 07:35:12 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:35:12 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:35:12 --> Utf8 Class Initialized
INFO - 2025-08-19 07:35:12 --> URI Class Initialized
INFO - 2025-08-19 07:35:12 --> Router Class Initialized
INFO - 2025-08-19 07:35:12 --> Output Class Initialized
INFO - 2025-08-19 07:35:12 --> Security Class Initialized
DEBUG - 2025-08-19 07:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:35:12 --> Input Class Initialized
INFO - 2025-08-19 07:35:12 --> Language Class Initialized
INFO - 2025-08-19 07:35:12 --> Loader Class Initialized
INFO - 2025-08-19 07:35:12 --> Helper loaded: url_helper
INFO - 2025-08-19 07:35:12 --> Helper loaded: security_helper
INFO - 2025-08-19 07:35:12 --> Helper loaded: string_helper
INFO - 2025-08-19 07:35:12 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:35:12 --> Helper loaded: form_helper
INFO - 2025-08-19 07:35:12 --> Form Validation Class Initialized
INFO - 2025-08-19 07:35:12 --> Controller Class Initialized
INFO - 2025-08-19 07:35:12 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:35:12 --> Final output sent to browser
DEBUG - 2025-08-19 07:35:12 --> Total execution time: 0.0618
INFO - 2025-08-19 07:35:29 --> Config Class Initialized
INFO - 2025-08-19 07:35:29 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:35:29 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:35:29 --> Utf8 Class Initialized
INFO - 2025-08-19 07:35:29 --> URI Class Initialized
INFO - 2025-08-19 07:35:29 --> Router Class Initialized
INFO - 2025-08-19 07:35:29 --> Output Class Initialized
INFO - 2025-08-19 07:35:29 --> Security Class Initialized
DEBUG - 2025-08-19 07:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:35:29 --> Input Class Initialized
INFO - 2025-08-19 07:35:29 --> Language Class Initialized
INFO - 2025-08-19 07:35:29 --> Loader Class Initialized
INFO - 2025-08-19 07:35:29 --> Helper loaded: url_helper
INFO - 2025-08-19 07:35:29 --> Helper loaded: security_helper
INFO - 2025-08-19 07:35:29 --> Helper loaded: string_helper
INFO - 2025-08-19 07:35:29 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:35:29 --> Helper loaded: form_helper
INFO - 2025-08-19 07:35:29 --> Form Validation Class Initialized
INFO - 2025-08-19 07:35:29 --> Controller Class Initialized
INFO - 2025-08-19 07:35:29 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:35:29 --> Final output sent to browser
DEBUG - 2025-08-19 07:35:29 --> Total execution time: 0.0666
INFO - 2025-08-19 07:35:33 --> Config Class Initialized
INFO - 2025-08-19 07:35:33 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:35:33 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:35:33 --> Utf8 Class Initialized
INFO - 2025-08-19 07:35:33 --> URI Class Initialized
INFO - 2025-08-19 07:35:33 --> Router Class Initialized
INFO - 2025-08-19 07:35:33 --> Output Class Initialized
INFO - 2025-08-19 07:35:33 --> Security Class Initialized
DEBUG - 2025-08-19 07:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:35:33 --> Input Class Initialized
INFO - 2025-08-19 07:35:33 --> Language Class Initialized
INFO - 2025-08-19 07:35:33 --> Loader Class Initialized
INFO - 2025-08-19 07:35:33 --> Helper loaded: url_helper
INFO - 2025-08-19 07:35:33 --> Helper loaded: security_helper
INFO - 2025-08-19 07:35:33 --> Helper loaded: string_helper
INFO - 2025-08-19 07:35:33 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:35:33 --> Helper loaded: form_helper
INFO - 2025-08-19 07:35:33 --> Form Validation Class Initialized
INFO - 2025-08-19 07:35:33 --> Controller Class Initialized
INFO - 2025-08-19 07:35:33 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:35:33 --> Final output sent to browser
DEBUG - 2025-08-19 07:35:33 --> Total execution time: 0.0600
INFO - 2025-08-19 07:35:37 --> Config Class Initialized
INFO - 2025-08-19 07:35:37 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:35:37 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:35:37 --> Utf8 Class Initialized
INFO - 2025-08-19 07:35:37 --> URI Class Initialized
INFO - 2025-08-19 07:35:37 --> Router Class Initialized
INFO - 2025-08-19 07:35:37 --> Output Class Initialized
INFO - 2025-08-19 07:35:37 --> Security Class Initialized
DEBUG - 2025-08-19 07:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:35:37 --> Input Class Initialized
INFO - 2025-08-19 07:35:37 --> Language Class Initialized
INFO - 2025-08-19 07:35:37 --> Loader Class Initialized
INFO - 2025-08-19 07:35:37 --> Helper loaded: url_helper
INFO - 2025-08-19 07:35:37 --> Helper loaded: security_helper
INFO - 2025-08-19 07:35:37 --> Helper loaded: string_helper
INFO - 2025-08-19 07:35:37 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:35:37 --> Helper loaded: form_helper
INFO - 2025-08-19 07:35:37 --> Form Validation Class Initialized
INFO - 2025-08-19 07:35:37 --> Controller Class Initialized
INFO - 2025-08-19 07:35:37 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:35:37 --> Final output sent to browser
DEBUG - 2025-08-19 07:35:37 --> Total execution time: 0.0664
INFO - 2025-08-19 07:39:25 --> Config Class Initialized
INFO - 2025-08-19 07:39:25 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:39:25 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:39:25 --> Utf8 Class Initialized
INFO - 2025-08-19 07:39:25 --> URI Class Initialized
INFO - 2025-08-19 07:39:25 --> Router Class Initialized
INFO - 2025-08-19 07:39:25 --> Output Class Initialized
INFO - 2025-08-19 07:39:25 --> Security Class Initialized
DEBUG - 2025-08-19 07:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:39:25 --> Input Class Initialized
INFO - 2025-08-19 07:39:25 --> Language Class Initialized
INFO - 2025-08-19 07:39:25 --> Loader Class Initialized
INFO - 2025-08-19 07:39:25 --> Helper loaded: url_helper
INFO - 2025-08-19 07:39:25 --> Helper loaded: security_helper
INFO - 2025-08-19 07:39:25 --> Helper loaded: string_helper
INFO - 2025-08-19 07:39:25 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:39:25 --> Helper loaded: form_helper
INFO - 2025-08-19 07:39:25 --> Form Validation Class Initialized
INFO - 2025-08-19 07:39:25 --> Controller Class Initialized
INFO - 2025-08-19 07:39:25 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:39:25 --> Final output sent to browser
DEBUG - 2025-08-19 07:39:25 --> Total execution time: 0.0636
INFO - 2025-08-19 07:39:27 --> Config Class Initialized
INFO - 2025-08-19 07:39:27 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:39:27 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:39:27 --> Utf8 Class Initialized
INFO - 2025-08-19 07:39:27 --> URI Class Initialized
INFO - 2025-08-19 07:39:27 --> Router Class Initialized
INFO - 2025-08-19 07:39:27 --> Output Class Initialized
INFO - 2025-08-19 07:39:27 --> Security Class Initialized
DEBUG - 2025-08-19 07:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:39:28 --> Input Class Initialized
INFO - 2025-08-19 07:39:28 --> Language Class Initialized
INFO - 2025-08-19 07:39:28 --> Loader Class Initialized
INFO - 2025-08-19 07:39:28 --> Helper loaded: url_helper
INFO - 2025-08-19 07:39:28 --> Helper loaded: security_helper
INFO - 2025-08-19 07:39:28 --> Helper loaded: string_helper
INFO - 2025-08-19 07:39:28 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:39:28 --> Helper loaded: form_helper
INFO - 2025-08-19 07:39:28 --> Form Validation Class Initialized
INFO - 2025-08-19 07:39:28 --> Controller Class Initialized
INFO - 2025-08-19 07:39:28 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:39:28 --> Final output sent to browser
DEBUG - 2025-08-19 07:39:28 --> Total execution time: 0.0729
INFO - 2025-08-19 07:39:30 --> Config Class Initialized
INFO - 2025-08-19 07:39:30 --> Hooks Class Initialized
DEBUG - 2025-08-19 07:39:30 --> UTF-8 Support Enabled
INFO - 2025-08-19 07:39:30 --> Utf8 Class Initialized
INFO - 2025-08-19 07:39:30 --> URI Class Initialized
INFO - 2025-08-19 07:39:30 --> Router Class Initialized
INFO - 2025-08-19 07:39:30 --> Output Class Initialized
INFO - 2025-08-19 07:39:30 --> Security Class Initialized
DEBUG - 2025-08-19 07:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-08-19 07:39:30 --> Input Class Initialized
INFO - 2025-08-19 07:39:30 --> Language Class Initialized
INFO - 2025-08-19 07:39:30 --> Loader Class Initialized
INFO - 2025-08-19 07:39:30 --> Helper loaded: url_helper
INFO - 2025-08-19 07:39:30 --> Helper loaded: security_helper
INFO - 2025-08-19 07:39:30 --> Helper loaded: string_helper
INFO - 2025-08-19 07:39:30 --> Database Driver Class Initialized
DEBUG - 2025-08-19 07:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-08-19 07:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-08-19 07:39:30 --> Helper loaded: form_helper
INFO - 2025-08-19 07:39:30 --> Form Validation Class Initialized
INFO - 2025-08-19 07:39:30 --> Controller Class Initialized
INFO - 2025-08-19 07:39:30 --> Model "Auth_model" initialized
INFO - 2025-08-19 07:39:30 --> Final output sent to browser
DEBUG - 2025-08-19 07:39:30 --> Total execution time: 0.0590
